CREATE TRIGGER [dbo].[IR_D_RateioDecTerc_DELETE] 
     ON [dbo].[RateioDecTerc] 
     FOR  DELETE 
     AS 
 -- ============================================= 
 -- Description: Não permitir excluir registros de DecimoTerceiro quando tiver registro em Parc_Proc. 
 -- ============================================= 
 DECLARE @NumErr        INT, 
         @MsgErr        VARCHAR(255) 
     IF EXISTS ( 
               SELECT PARC_PROC.Num_Proc AS QTDE 
               From Parc_Proc 
                      INNER JOIN DELETED ON  Parc_Proc.Empresa_proc = DELETED.Empresa_RatDecTerc 
                           AND Parc_Proc.Obra_Proc = DELETED.Obra_RatDecTerc 
                           AND Parc_Proc.Num_Proc = DELETED.NumProc_RatDecTerc) 
       BEGIN 
            SELECT @NumErr = 50009, 
              @MsgErr = 'Não será possível excluir o Calculo de Décimo Terceiro, uma vez que o processo não foi excluído do financeiro. Por favor, entre em contato com o suporte!' 
              GoTo ERRO 
       End 
    Return 
 ERRO: 
   RAISERROR (@MsgErr,18,1) 
   RollBack TRANSACTION
go

