CREATE TRIGGER [dbo].[IR_D_EMPRHENCOBRA_UPDATE]  
 ON [dbo].[EmpRhEncObra]  
 FOR  UPDATE AS  
 -- =============================================  
 -- Description: Não permitir alterar registros de Calculo de Encargos quando tiver registro em Parc_Proc.  
 -- =============================================  
 DECLARE @NumErr        INT,  
         @MsgErr        VARCHAR(255)  
     IF EXISTS ( SELECT PARC_PROC.Num_Proc AS QTDE  
                    From Parc_Proc  
                    INNER JOIN DELETED ON  Parc_Proc.Empresa_proc = Coalesce(DELETED.EmpPagadora_Enc,DELETED.EmpProcLot_Enc)  
                    AND Parc_Proc.Obra_Proc = Coalesce(DELETED.ObraPagadora_Enc,DELETED.ObraProcLot_Enc ) 
                    AND Parc_Proc.Num_Proc = DELETED.NumProc_Enc)    
      BEGIN  
      IF UPDATE(NumProc_Enc)  
     BEGIN  
        SELECT @NumErr = 50009,  
            @MsgErr = 'Não será possível alterar o cálculo de encargo, uma vez que o processo de pagamento não foi excluido. Por favor, entre em contato com o suporte!'  
            GoTo ERRO  
         END  
      END  
    Return  
 ERRO:  
   RAISERROR (@MsgErr,18,1)  
   RollBack TRANSACTION
go

