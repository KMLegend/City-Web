CREATE TRIGGER [dbo].[IR_IU_PESSOAS_INSERT] 
ON   [dbo].[Pessoas] 
FOR INSERT,UPDATE 
AS
 DECLARE @NumErr  INT, 
 @MsgErr  VARCHAR(255) 
-- =============================================
-- Author:  Juliana Oliveira Souza 
-- Create date: 15/10/2012 - Imediata 9.03 n° 120464
-- Description: Não permitir inserir ou alterar tabela Pessoas onde o campo Nome_Pes seja NUll.
-- =============================================
IF @@ROWCOUNT = 0
Return
IF EXISTS (SELECT * FROM INSERTED WHERE INSERTED.Nome_Pes  IS NULL OR INSERTED.Nome_Pes = '')
BEGIN 
         SELECT @NumErr = 50009, 
           @MsgErr = 'O nome da pessoa está vazio.'
         GoTo ERRO 
      END 
   RETURN 
ERRO: 
RAISERROR (@MsgErr,18,1) 
RollBack TRANSACTION
go

