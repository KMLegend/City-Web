 CREATE TRIGGER [dbo].[IR_IUD_AcompExecContrato]
    ON [dbo].[AcompExecContrato] 
    FOR INSERT, UPDATE 
    AS
-- =============================================
-- Description: Não permitir incluir/alterar AcompExecContrat.Qtde_aec fora do padrão de formatação do contrato .
-- =============================================
DECLARE @NumErr        INT,
        @MsgErr        VARCHAR(255)
    -- Verifica se o número de casas decimais para a 'quantidade' no contrato está de acordo 
    -- com o que está sendo inserido em AcompExecContrato.Qtde_aec 
 IF UPDATE(Qtde_aec)
 BEGIN 
    IF EXISTS (SELECT * FROM INSERTED INNER JOIN Contratos
          ON INSERTED.Empresa_aec = Contratos.Empresa_cont AND 
             INSERTED.Contrato_aec = Contratos.Cod_cont 
               WHERE str(INSERTED.Qtde_aec,20,CasaDecQtde_Cont) = INSERTED.Qtde_aec ) 
       RETURN --Se existir, quer dizer que o registro em AcompExecContrato pode ser inserido.
    ELSE 
       BEGIN
          -- se  chegar até aqui está tentando inserir um registro em AcompExecContrato, 
          -- onde o número de casas decimais para o campo Qtde_aec está diferente do que foi 
          -- definido como o máximo no contrato. 
          -- Exemplo: Qtde definida em contrato para casas decimais = 4       
          --          Valor inserido/alterado                       = 1,12345 
          --          Valor correto                                 = 1,1235  
         SELECT @NumErr = 50001 ,
            @MsgErr = ' A quantidade acompanhada não está formatada no padrão de casas decimais definido no contrato. Tente novamente e se persistir entre em contato com o suporte.'
         GOTO ERRO
      END
  END
RETURN   
ERRO:   
  raiserror  ( @Numerr , @MsgErr,1,1 )
  RollBack TRANSACTION
go

