 CREATE TRIGGER [dbo].[IR_D_EVENTOPENDENTE_DELETE]  
     ON [dbo].[EventoPendente] 
     FOR  DELETE AS 
 -- Description: Não permitir excluir registros de EventoPendente quando não for Situacao_evtp = (0-Não enviado e 4-Rejeitado). 
      BEGIN
        DECLARE @MsgErr        VARCHAR(255), 
                @NumErr        INT
         IF EXISTS(SELECT 1
                     FROM DELETED 
                    WHERE Situacao_evtp NOT IN(0, 4)
                      AND TipoAmbiente_evtP = 1
                      AND NOT EXISTS (SELECT 1 FROM EventoConfirmado WHERE NumSeq_evtc = NumSeq_evtp AND CodEmp_evtc = CodEmp_evtp))
          BEGIN 
             SELECT @NumErr = 50009, 
               @MsgErr = 'Eventos pendentes só poderão ser excluídos na situação: 0-Não enviado ou 4-Rejeitado!' 
               GoTo ERRO 
          End 
      End 
      RETURN
 ERRO: 
   RollBack TRANSACTION
   RAISERROR (@MsgErr,18,1) 
   INSERT INTO LogInconsistencia
        VALUES(123, 123, 'TRIGGER - IR_D_EVENTOPENDENTE_DELETE', 'SUPORTE'
              ,getdate(),'TRIGGER', 'TRIGGER', 'TRIGGER', HOST_NAME(), 'TRIGGER' ,'DELETE DA TRIGGER DE EVENTO PENDENTE - USUARIO: ' + SUSER_NAME(), 'FOLHA', '10.06.0000', 'TRIGGER', DEFAULT)
 go

