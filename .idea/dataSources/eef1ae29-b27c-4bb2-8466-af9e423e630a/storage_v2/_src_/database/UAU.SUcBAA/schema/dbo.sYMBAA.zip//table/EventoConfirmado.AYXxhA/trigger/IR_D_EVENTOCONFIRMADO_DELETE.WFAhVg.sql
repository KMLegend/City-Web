 CREATE TRIGGER [dbo].[IR_D_EVENTOCONFIRMADO_DELETE]  
     ON [dbo].[EventoConfirmado] 
     FOR  DELETE AS 
 -- Description: Não permitir excluir registros de EventoConfirmado quando TipoAmbiente_etc = (1-Ambiente de produção). 
      BEGIN
        DECLARE @MsgErr        VARCHAR(255), 
                @NumErr        INT
         IF EXISTS(SELECT 1
                     FROM DELETED 
                    WHERE TipoAmbiente_evtc = 1) 
          BEGIN 
             SELECT @NumErr = 50009, 
               @MsgErr = 'Eventos confirmados só poderão ser excluídos quando TipoAmbiente_etc for = (2-Ambiente de homologação)' 
               GoTo ERRO 
          End 
      End 
      RETURN
 ERRO: 
 RollBack TRANSACTION
   RAISERROR (@MsgErr,18,1) 
   INSERT INTO LogInconsistencia
        VALUES(123, 123, 'TRIGGER - IR_D_EVENTOCONFIRMADO_DELETE', 'SUPORTE'
              ,getdate(),'TRIGGER', 'TRIGGER', 'TRIGGER', HOST_NAME(), 'TRIGGER', 'DELETE DA TRIGGER DE EVENTO CONFIRMADO - USUARIO: ' + SUSER_NAME(), 'FOLHA', '10.06.0000', 'TRIGGER', DEFAULT)
 go

