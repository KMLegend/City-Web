 CREATE  TRIGGER [dbo].[IR_UI_ItemProcSI_UPDATEINSERT_1]  
     ON [dbo].[ItemProcSI]  
     FOR  INSERT, UPDATE  
     AS  
 -- =============================================  
 -- Description: Validar se o preço que esta sendo gravado em ItemProcSI é negativo 
 -- Ronis de Sousa       Data: 14/03/2014 
 -- =============================================  
 DECLARE @NumErr       INT,  
         @MsgErr       VARCHAR(255)           
         IF EXISTS(SELECT * FROM INSERTED WHERE INSERTED.Preco_itsi < 0)
            BEGIN
               SELECT @NumErr = 50009, @MsgErr = 'Esta operação está gerando preço negativo para a SI aprovada do processo. Tente novamente, e caso persista, entre em contato com o SUPORTE! '
               GoTo ERRO  
            END
         RETURN;  
 ERRO:  
   RAISERROR (@MsgErr, 18, 1)  
   RollBack TRANSACTION
 go

