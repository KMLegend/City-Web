 CREATE  TRIGGER [dbo].[IR_U_ItemProcSI_UPDATEINSERT]  
     ON [dbo].[ItemProcSI]  
     FOR  INSERT, UPDATE  
     AS  
 -- =============================================  
 -- Description: Validar se o preço que esta sendo gravado em ItemProcSI esta igual ao preço do insumo em CompIns 
 -- Danilo Bonifacio Teles      Data: 23/05/2013 
 -- =============================================  
 DECLARE @NumErr       INT,  
         @MsgErr       VARCHAR(255),           
         @PrecoItsi    NUMERIC(30,18), 
         @PrecoComp    NUMERIC(30,18),         
         @Empresa      SMALLINT,    
         @Obra         VARCHAR(5),    
         @ItemItsi     VARCHAR(50),  
         @Proditsi     INT, 
         @Contratoitsi INT, 
         @Compitsi     VARCHAR(10),  
         @InsumoPLitsi VARCHAR(10), 
         @InsumoProcitsi VARCHAR(10), 
         @PLMesitsi    DATETIME, 
         @NumProc      INT, 
         @TipoIns      INT, 
         @EncIns       INT; 
         SELECT @Empresa = INSERTED.Empresa_itsi, @Obra = INSERTED.Obra_itsi, @ItemItsi = INSERTED.Item_itsi,   
           @Proditsi = INSERTED.Prod_itsi, @Contratoitsi = INSERTED.Contrato_itsi, @Compitsi = INSERTED.Comp_itsi,  
           @InsumoPLitsi = INSERTED.InsumoPL_itsi, @PLMesitsi = INSERTED.PLMes_itsi, @NumProc = INSERTED.NumProc_itsi, 
           @PrecoItsi = INSERTED.Preco_itsi, @InsumoProcitsi = INSERTED.InsumoProc_itsi 
      FROM INSERTED           
    Select @TipoIns = TabProc.Tipo_ins, @EncIns = TabProc.Encargo_ins From (SELECT Distinct Insumos.Tipo_ins, Insumos.Encargo_ins FROM ItemProcSI 
  INNER JOIN Insumos ON ItemProcSI.InsumoPL_itsi =Insumos.Cod_ins 
  AND ItemProcSI.Empresa_itsi =Insumos.Empresa_ins 
  AND ItemProcSI.Obra_itsi =Insumos.Obra_ins 
  WHERE Tipo_ins = 1 AND Insumos.Encargo_ins = 0 
  AND Empresa_itsi = @Empresa 
  AND Obra_itsi = @Obra 
  AND InsumoProc_itsi = @InsumoProcitsi 
  AND Item_itsi = @ItemItsi 
  AND Prod_itsi = @Proditsi 
  AND Contrato_itsi = @Contratoitsi 
  AND Comp_itsi = @Compitsi 
  AND InsumoPL_itsi = @InsumoPLitsi 
  AND PLMes_itsi = @PLMesitsi 
  AND NumProc_itsi = @NumProc) As TabProc 
   IF ((@TipoIns = 1 AND @EncIns = 0) AND @PrecoItsi > 0)   
     SELECT @PrecoComp = preco_cins FROM CompIns  
     WHERE Empresa_cins  = @Empresa 
     AND Obra_cins = @Obra 
     AND Mes_cins = @PLMesitsi 
     AND Ins_cins = @InsumoPLitsi 
     AND Item_cins = @ItemItsi 
     AND Comp_cins = @Compitsi 
     AND Prod_cins = @Proditsi 
     AND Contrato_cins = @Contratoitsi 
     IF ABS(CAST(@PrecoComp AS NUMERIC(30,2)) - CAST(@PrecoItsi AS NUMERIC(30,2))) > 0.01  
      BEGIN  
        SELECT @NumErr = 50009, @MsgErr = 'O preço da SI que esta sendo gravado para o(s) item(s) do processo ' + 
              'está com valor divergente.'  + CHAR(13) + CHAR(10) +  
              'Item do Processo: ' + Cast(@PrecoItsi AS VARCHAR(50))+ CHAR(13) + CHAR(10) +  
              'Planejamento: ' + Cast(@PrecoComp AS VARCHAR(50))+ CHAR(13) + CHAR(10) +  
              'Por Favor entrar em contato com Suporte.'  + CHAR(13) +  CHAR(10)  
        GoTo ERRO  
      END         
    RETURN;  
 ERRO:  
   RAISERROR (@MsgErr, 18, 1)  
   RollBack TRANSACTION     
go

