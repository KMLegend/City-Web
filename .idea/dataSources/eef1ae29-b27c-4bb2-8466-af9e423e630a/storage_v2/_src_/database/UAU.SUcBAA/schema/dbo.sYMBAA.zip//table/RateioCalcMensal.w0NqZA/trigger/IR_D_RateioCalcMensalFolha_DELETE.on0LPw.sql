CREATE TRIGGER [dbo].[IR_D_RateioCalcMensalFolha_DELETE] 
     ON [dbo].[RateioCalcMensal] 
     FOR  DELETE 
     AS 
 -- ============================================= 
 -- Description: Não permitir excluir registros de Calculo quando tiver registro em Parc_Proc. 
 -- ============================================= 
 DECLARE @NumErr        INT, 
         @MsgErr        VARCHAR(255) 
       -- Insert statements for trigger here 
     IF EXISTS ( SELECT PARC_PROC.Num_Proc AS QTDE 
                 From Parc_Proc 
                      INNER JOIN DELETED 
                           ON  Parc_Proc.Empresa_proc = DELETED.Empresa_RatCalcM 
                           AND Parc_Proc.Obra_Proc = DELETED.Obra_RatCalcM 
                           AND Parc_Proc.Num_Proc = DELETED.NumProc_RatCalcM 
               ) 
       BEGIN          IF NOT EXISTS ( SELECT RateioCalculo.NumCapRH_RatCalc AS QTDE 
                          From RateioCalculo 
                               INNER JOIN DELETED 
                                  ON  RateioCalculo.NumCapRH_RatCalc = DELETED.NumCapRH_RatCalcM 
                                  AND RateioCalculo.DataFolha_RatCalc = DELETED.DataFolha_RatCalcM 
                                  AND RateioCalculo.TipoProcesso_RatCalc = DELETED.TipoProcesso_RatCalcM 
                                  AND RateioCalculo.Num_RatCalc = DELETED.Num_RatCalcM 
                         ) 
             BEGIN 
                SELECT @NumErr = 50009, 
                   @MsgErr = 'Não será possível excluir o Calculo de folha, uma vez que o processo não foi excluído do financeiro. Por favor, entre em contato com o suporte!' 
                GoTo ERRO 
             End 
       End 
    Return 
 ERRO: 
   RAISERROR (@MsgErr,18,1) 
   RollBack TRANSACTION
go

