CREATE TRIGGER [dbo].[IR_IU_ITENS_PROC_INSERT] 
ON   [dbo].[Itens_Proc] 
FOR INSERT,UPDATE 
AS
 DECLARE @NumErr  INT, 
 @MsgErr  VARCHAR(255) 
-- =============================================
-- Author:  André Alexandre Alves Carneiro
-- Create date: 21/09/2012
-- Description: Não permitir inserir ou alterar tabela Itens_proc o campo CapInsProc_Item = NUll.
-- =============================================
IF @@ROWCOUNT = 0
Return
IF EXISTS (SELECT * FROM INSERTED WHERE INSERTED.CapInsProc_Item  IS NULL)
BEGIN 
         SELECT @NumErr = 50009, 
           @MsgErr = 'O Processo foi interrompido pois CAP está vazio.'
         GoTo ERRO 
      END 
   RETURN 
ERRO: 
RAISERROR (@MsgErr,18,1) 
RollBack TRANSACTION
go

