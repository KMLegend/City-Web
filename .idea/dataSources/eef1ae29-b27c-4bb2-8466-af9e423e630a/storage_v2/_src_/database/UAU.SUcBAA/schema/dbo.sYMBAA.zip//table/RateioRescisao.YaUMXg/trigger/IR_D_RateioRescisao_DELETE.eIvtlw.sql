CREATE TRIGGER [dbo].[IR_D_RateioRescisao_DELETE] 
 ON [dbo].[RateioRescisao] 
 FOR  DELETE 
 AS 
-- ============================================= 
-- Description: Não permitir excluir registros de Rescisao quando tiver registro em Parc_Proc. 
-- ============================================= 
DECLARE @NumErr        INT, 
     @MsgErr        VARCHAR(255) 
 IF EXISTS (SELECT PARC_PROC.Num_Proc AS QTDE 
            From Parc_Proc 
            INNER JOIN DELETED ON Parc_Proc.Empresa_proc = DELETED.Empresa_RatRes 
            AND Parc_Proc.Obra_Proc = DELETED.Obra_RatRes 
            AND PARC_PROC.Num_Proc = DELETED.NumProc_RatRes) 
   BEGIN 
        SELECT @NumErr = 50009, 
          @MsgErr = 'Não será possível excluir o Calculo de rescisão, uma vez que o processo não foi excluído do financeiro. Por favor, entre em contato com o suporte!' 
          GoTo ERRO 
      End 
Return 
ERRO: 
RAISERROR (@MsgErr,18,1) 
RollBack TRANSACTION
go

