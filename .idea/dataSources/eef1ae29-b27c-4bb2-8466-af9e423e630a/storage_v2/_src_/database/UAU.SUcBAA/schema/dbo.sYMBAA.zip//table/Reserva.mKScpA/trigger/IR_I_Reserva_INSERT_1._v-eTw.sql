CREATE   TRIGGER [dbo].[IR_I_Reserva_INSERT_1]  
ON [dbo].[Reserva]  
FOR  INSERT  
 AS  
-- =============================================  
-- Description: Validar se a personalização da reserva está com o status disponível
-- Emerson Augusto de Oliveira       Data: 07/08/2014 
-- =============================================  
DECLARE @NumErr       INT,  
       @MsgErr       VARCHAR(255)    
IF EXISTS(
  SELECT Vendas.Empresa_ven, Vendas.Obra_ven, Vendas.Num_ven, Vendas.Status_Ven, 
  unidadeper.Empresa_unid, unidadeper.Prod_unid, unidadeper.NumPer_unid, unidadeper.Vendido_unid
  FROM ( 
   SELECT * FROM ItensVenda 
   UNION 
   SELECT * FROM ItensRecebidas  
  ) AS ItensVenda  
  INNER JOIN ( 
   SELECT Empresa_ven, Obra_ven, Num_ven, Data_Ven, ValorTot_ven, Cliente_ven, TipoVenda_Ven, Vendas.Status_Ven 
   FROM Vendas 
   UNION 
   SELECT Empresa_vrec, Obra_vrec, Num_vrec, Data_vrec, ValorTot_vrec, Cliente_vrec, TipoVenda_vrec, Status_VRec 
   FROM VendasRecebidas  
  ) AS Vendas 
   ON ItensVenda.Empresa_itv = Vendas.Empresa_ven 
   AND ItensVenda.Obra_Itv = Vendas.Obra_Ven 
   AND ItensVenda.NumVend_Itv = Vendas.Num_Ven  
  INNER JOIN UnidadePer 
   ON ItensVenda.Empresa_itv = UnidadePer.Empresa_unid 
   AND ItensVenda.Produto_Itv = UnidadePer.Prod_unid 
   AND ItensVenda.CodPerson_Itv = UnidadePer.NumPer_unid 
  INNER JOIN INSERTED 
   ON INSERTED.Empresa_rsv = UnidadePer.Empresa_unid 
   AND INSERTED.NumProd_rsv = UnidadePer.Prod_unid 
   AND INSERTED.NumPer_rsv = UnidadePer.NumPer_unid 
  WHERE Vendas.Status_Ven IN (3,0) 
  AND unidadeper.Vendido_unid = 0 
  AND Vendas.TipoVenda_Ven IN (0, 4)  
       ) 
          BEGIN 
             SELECT @NumErr = 50009, @MsgErr = 'Esta operação está gerando reserva para uma unidade com status diferente de disponível. Tente novamente, e caso persista, entre em contato com o SUPORTE! ' 
             GoTo ERRO   
          END 
         ELSE 
  RETURN;   
  ERRO:   
 RAISERROR ( @MsgErr, 18, 1)   
 RollBack TRANSACTION
go

