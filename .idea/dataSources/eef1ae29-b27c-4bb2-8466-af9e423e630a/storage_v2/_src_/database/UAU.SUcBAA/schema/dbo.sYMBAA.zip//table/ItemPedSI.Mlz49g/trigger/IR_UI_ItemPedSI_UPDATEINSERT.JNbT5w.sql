 CREATE  TRIGGER [dbo].[IR_UI_ItemPedSI_UPDATEINSERT]  
     ON [dbo].[ItemPedSI]  
     FOR  INSERT, UPDATE  
     AS  
 -- =============================================  
 -- Description: Validar se o Mês PL está com formato inválido 
 -- Ulisses Cardoso de Souza       Data: 22/02/2018 
 -- =============================================  
 DECLARE @NumErr       INT,  
         @MsgErr       VARCHAR(255)           
         IF EXISTS(SELECT * FROM INSERTED WHERE SUBSTRING(CONVERT(VARCHAR(10), INSERTED.PlMes_pedsi, 103), 1, 2) <> '01')
            BEGIN
               SELECT @NumErr = 50009, @MsgErr = 'Esta operação está gerando formato errado para o mês de planejamento da SI do pedido. Entre em contato com o SUPORTE! '
               GoTo ERRO  
            END
         RETURN;  
 ERRO:  
   RAISERROR (@MsgErr, 18, 1)  
   RollBack TRANSACTION
 go

