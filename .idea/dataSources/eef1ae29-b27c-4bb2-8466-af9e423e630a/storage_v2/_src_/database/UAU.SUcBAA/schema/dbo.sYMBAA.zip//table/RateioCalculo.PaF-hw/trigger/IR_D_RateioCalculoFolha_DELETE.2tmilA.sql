 CREATE TRIGGER [dbo].[IR_D_RateioCalculoFolha_DELETE]  
     ON [dbo].[RateioCalculo] 
     FOR  DELETE 
     AS 
 -- ============================================= 
 -- Description: Não permitir excluir registros de RateioCalculo quando tiver registro em Parc_Proc. 
 -- ============================================= 
 DECLARE @NumErr        INT, 
         @MsgErr        VARCHAR(255) 
     IF EXISTS ( SELECT PARC_PROC.Num_Proc AS QTDE 
                 From Parc_Proc 
                 INNER JOIN DELETED 
                    ON  Parc_Proc.Empresa_proc = DELETED.Empresa_RatCalc 
                    AND Parc_Proc.Obra_Proc = DELETED.Obra_RatCalc 
                    AND Parc_Proc.Num_Proc = DELETED.NumProc_RatCalc 
                    ) 
       BEGIN         IF NOT  EXISTS(SELECT RateioCalcMensal.NumCapRH_RatCalcM AS QTDE 
                        From RateioCalcMensal 
                               INNER JOIN DELETED 
                                    ON  RateioCalcMensal.NumCapRH_RatCalcM = DELETED.NumCapRH_RatCalc 
                                    AND RateioCalcMensal.DataFolha_RatCalcM = DELETED.DataFolha_RatCalc 
                                    AND RateioCalcMensal.TipoProcesso_RatCalcM = DELETED.TipoProcesso_RatCalc 
                                    AND RateioCalcMensal.Num_RatCalcM = DELETED.Num_RatCalc 
                ) 
          BEGIN 
             SELECT @NumErr = 50009, 
               @MsgErr = 'Não será possível excluir o Calculo de folha, uma vez que o processo não foi excluído do financeiro. Por favor, entre em contato com o suporte!' 
               GoTo ERRO 
          End 
       End 
    Return 
 ERRO: 
   RAISERROR (@MsgErr,18,1) 
   RollBack TRANSACTION
 go

