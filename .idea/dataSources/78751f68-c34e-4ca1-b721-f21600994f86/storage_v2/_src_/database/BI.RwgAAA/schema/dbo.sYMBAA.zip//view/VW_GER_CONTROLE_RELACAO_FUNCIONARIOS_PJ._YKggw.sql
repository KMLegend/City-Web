







CREATE VIEW [dbo].[VW_GER_CONTROLE_RELACAO_FUNCIONARIOS_PJ] AS 

WITH TELEFONE AS (
SELECT DISTINCT
	Base_Telefone.pes_tel,
	MAX(Base_Telefone.FoneRes) AS FoneRes,
	MAX(Base_Telefone.FoneCom) AS FoneCom,
	MAX(Base_Telefone.FoneCel) AS FoneCel
FROM (
	SELECT DISTINCT
		pes_tel,
		CASE tipo_tel
			WHEN 0 THEN
				CONCAT(ddd_tel , '-' ,fone_tel) 
		END AS FoneRes,
		CASE tipo_tel
			WHEN 1 THEN
				CONCAT(ddd_tel , '-' ,fone_tel) 
		END AS FoneCom,
		CASE tipo_tel
			WHEN 2 THEN
				CONCAT(ddd_tel , '-' ,fone_tel) 
		END AS FoneCel
	FROM UAU.dbo.pestel
	WHERE  tipo_tel < 3 
) AS Base_Telefone
GROUP BY pes_tel
)
, ENDERECO AS (
SELECT DISTINCT
    pesendereco.codpes_pend,
    --pesendereco.tipo_pend,
    pesendereco.cep_pend,
    CASE 
		WHEN pesendereco.numend_pend = ' ' THEN NULL
		ELSE pesendereco.numend_pend END AS numend_pend,
    CASE 
		WHEN Isnull(pesendereco.endereco_pend, '') + ' ' + Isnull(pesendereco.complendereco_pend, '') = ' ' THEN NULL
		ELSE Isnull(pesendereco.endereco_pend, '') + ' ' + Isnull(pesendereco.complendereco_pend, '') END AS Expr1,
    pesendereco.bairro_pend,
    pesendereco.cidade_pend,
    pesendereco.uf_pend
FROM UAU.dbo.pesendereco
WHERE  pesendereco.tipo_pend =0 
)
,CATEGORIA AS (
SELECT codpes_cp, codcat_cp, Origem_cp, Quem_cp, Desc_cger, Anexos_Cger 
FROM UAU.dbo.PesCateg LEFT JOIN UAU.dbo.CategPessoas ON(CodCat_cp = Codigo_cger) AND ((CASE Origem_cp WHEN 1 THEN 2 ELSE 3 END) = Tipo_cger) 
--WHERE CodPes_cp =20361
WHERE Desc_cger = 'PJ CITY'
)
,contas as (
SELECT DISTINCT
[Empresa_des]
,[Obra_des] 
,[COMPPL_DES]
,[DESCCOMPPL_DES]
,[INSUMOPL_DES]
,[DESCINSPL_DES]
,DtPgto_des
--,max([DtPgto_des]) as [DtPgto_des]
,[CodForn_Des]

  FROM [BI].[dbo].[VW_GER_CONTROLE_CONTA_PAGO]
  where DATEADD(DAY,1,DATEADD(MONTH,-2,EOMONTH(GETDATE()))) < DtPgto_des
--  AND CodForn_Des = '11756'

) 


SELECT DISTINCT
c.Empresa_des,
c.Obra_des,
c.DtPgto_des,
c.[INSUMOPL_DES],
c.[DESCINSPL_DES],
c.[COMPPL_DES],
c.[DESCCOMPPL_DES],
case 
	when c.DtPgto_des < DATEADD(MONTH,-2,EOMONTH(GETDATE())) then '1 - Demitido'
	else '0 - Ativo' end as [Status] ,
    P.cod_pes,
    P.nome_pes,
	CATEGORIA.Desc_cger,
    P.cpf_pes,
    P.tipo_pes,      --  0 fisica 1 Juridica
	p.dtcad_pes, 
	CASE 
		WHEN P.email_pes = ' ' THEN NULL
		ELSE P.email_pes END AS email_pes,
    P.dtnasc_pes,
	TEL.FoneRes,
	TEL.FoneCom,
	TEL.FoneCel,
    --E.codpes_pend,
    E.cep_pend,
    E.numend_pend,
    E.Expr1,
    E.bairro_pend,
    E.cidade_pend,
    E.uf_pend,
    PC.nome_pc AS [Nome Conjuge],
    PC.cpf_pc AS [CPF Conjuge],
    PC.fone_pc AS [Fone Conjuge],
    PC.doc_pc AS [Doc Conjuge],
    PC.profis_pc AS [Profissao Conjuge],
	PF.NumPro_pf,
    PR.Descr_pro AS ProfissaoCliente,
	PF.sexo_pf,        -- 0 Mas 1 Fem
	PF.estciv_pf,      --0 'Separado' 1 'Solteiro' 2 'Casado' 3 'Desquitado' 4 'Viúvo' 5 'Divorciado'
    SUM(SF.Renda_SalF)  AS Renda_SalF

FROM UAU.dbo.pessoas as P

LEFT JOIN ENDERECO AS E
	ON COALESCE(E.codpes_pend,'') = COALESCE(P.cod_pes,'')
LEFT JOIN TELEFONE AS TEL
	ON COALESCE(TEL.pes_tel,'') = COALESCE(P.cod_pes,'')
LEFT JOIN  UAU.dbo.pesconj AS PC
	ON COALESCE(PC.cod_pc,'') = COALESCE(P.cod_pes,'')
LEFT JOIN  UAU.dbo.pesfis AS PF
	ON COALESCE(PF.cod_pf,'') = COALESCE(P.cod_pes,'')
LEFT JOIN UAU.dbo.Profissao AS PR
    ON COALESCE(PF.NumPro_pf,'') = COALESCE(PR.Num_pro,'')
LEFT JOIN  UAU.dbo.salariofunc AS SF
    ON COALESCE(SF.CodPes_SalF,'') = COALESCE(P.cod_pes,'')
LEFT JOIN CATEGORIA
	ON  COALESCE(P.cod_pes,'') = COALESCE(CATEGORIA.codpes_cp,'')
LEFT JOIN contas as c 
  on COALESCE(c.CodForn_Des,'') = COALESCE(p.[cod_pes],'')

	where CATEGORIA.Desc_cger = 'PJ CITY'
	--and nome_pes like 'san%'
	--and Obra_des like '%C'
GROUP BY     
	P.cod_pes,
    P.nome_pes,
	CATEGORIA.Desc_cger,
    P.cpf_pes,
    P.tipo_pes,      --  0 fisica 1 Juridica
    P.email_pes,
    P.dtnasc_pes,
	TEL.FoneRes,
	TEL.FoneCom,
	TEL.FoneCel,
    E.codpes_pend,
    E.cep_pend,
    E.numend_pend,
    E.Expr1,
    E.bairro_pend,
    E.cidade_pend,
    E.uf_pend,
    PC.nome_pc,
    PC.cpf_pc,
    PC.fone_pc,
    PC.doc_pc,
    PC.profis_pc,
	PF.NumPro_pf,
    PR.Descr_pro,
	PF.sexo_pf,        -- 0 Mas 1 Fem
	PF.estciv_pf,     --0 'Separado' 1 'Solteiro' 2 'Casado' 3 'Desquitado' 4 'Viúvo' 5 'Divorciado'
	P.dtcad_pes,
	c.Empresa_des,
	c.Obra_des,
	c.DtPgto_des,
	c.[INSUMOPL_DES],
	c.[DESCINSPL_DES],
	c.[COMPPL_DES],
	c.[DESCCOMPPL_DES],

	case 
		when c.DtPgto_des < DATEADD(MONTH,-2,EOMONTH(GETDATE())) then '1 - Demitido'
		else '0 - Ativo' end 




		--ORDER BY nome_pes
go

