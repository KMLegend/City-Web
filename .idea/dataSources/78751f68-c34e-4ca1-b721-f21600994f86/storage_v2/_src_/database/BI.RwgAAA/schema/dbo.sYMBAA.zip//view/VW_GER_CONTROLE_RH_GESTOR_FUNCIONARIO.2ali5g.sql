


CREATE VIEW [dbo].[VW_GER_CONTROLE_RH_GESTOR_FUNCIONARIO] AS 

WITH PESSOA_DOC AS (
SELECT	
	CodPes_Doc,
	Tipo_Doc,
	Registro_Doc
FROM UAU.dbo.PessoasDoc
WHERE Tipo_Doc = 1
)

,SINDICATO_F AS (
SELECT 
	PS.nome_pes AS NomeSindicato,
	PS.cod_pes AS CodPesSindicato
FROM  UAU.dbo.Pessoas AS PS
)

, TELEFONE AS (
SELECT DISTINCT
	Base_Telefone.pes_tel,
	MAX(Base_Telefone.FoneRes) AS FoneRes,
	MAX(Base_Telefone.FoneCel) AS FoneCel
FROM (
	SELECT DISTINCT
		pes_tel,
		CASE tipo_tel
			WHEN 0 THEN
				CONCAT('(',ddd_tel , ') ' ,fone_tel) 
		END AS FoneRes,
		CASE tipo_tel
			WHEN 2 THEN
				CONCAT('(',ddd_tel , ') ' ,fone_tel) 
		END AS FoneCel
	FROM UAU.dbo.pestel
	WHERE  tipo_tel < 3 
) AS Base_Telefone
GROUP BY pes_tel
)



SELECT		
	E.Codigo_emp AS [Emp.], 
	UPPER(E.Desc_emp) AS [Desc. Empresa],
	UPPER(O.Descr_Obr) AS [Desc. Obra],
	P.Cod_pes AS [Código],
	UPPER(P.Nome_Pes) AS [Nome],
	COALESCE(
	CASE 
		WHEN P.cpf_pes <> '' 
			THEN
				CASE P.Tipo_Pes
					WHEN 0 THEN SUBSTRING(P.cpf_pes,1,3) + '.' + SUBSTRING(P.cpf_pes,4,3) + '.' + SUBSTRING(P.cpf_pes,7,3) + '-' + SUBSTRING(P.cpf_pes,10,2)
					WHEN 1 THEN SUBSTRING(P.cpf_pes,1,2) + '.' + SUBSTRING(P.cpf_pes,3,3) + '.' + SUBSTRING(P.cpf_pes,6,3) + '/' + SUBSTRING(P.cpf_pes,7,4) + '-' + SUBSTRING(P.cpf_pes,11,2)
				END 
		END, '') AS [CPF],
	CASE 
		WHEN CAP.Estagiario_CapRH = 1 THEN 'ESTAGIO'
		ELSE 'CLT' END AS [REGIME],
	CAP.MatFunc_CapRH AS [Matricula],
	CAP.DtAdimissao_capRH AS [DataAdmissao], 
	CAP.DtDemissao_CapRH AS [DataDemissao],
	UPPER(SF.Descricao_SitF) AS [Situacao], 
	UPPER(F.Descricao_Func) AS [Funcao], 
	UPPER(F.CodCbo_Func) AS [CBO],
	UPPER(COALESCE(C.Descr_cad, 'SEM CARGO')) AS [CargoFunc],
	C.Cod_cad AS [Código Função],
	--COALESCE(SL.renda_SalF,0) AS [Salario], 
	--CHARINDEX ('.', COALESCE(SL.renda_SalF,0), 0),
	--SUBSTRING(CAST(COALESCE(SL.renda_SalF,0) AS VARCHAR),0,(CHARINDEX ('.', COALESCE(SL.renda_SalF,0), 0))) AS Salario_A,
	--SUBSTRING(CAST(COALESCE(SL.renda_SalF,0) AS VARCHAR),(CHARINDEX ('.', COALESCE(SL.renda_SalF,0), 0))+1,2) AS Salario_B,
	CONCAT(SUBSTRING(CAST(COALESCE(SL.renda_SalF,0) AS VARCHAR),0,(CHARINDEX ('.', COALESCE(SL.renda_SalF,0), 0))),',',SUBSTRING(CAST(COALESCE(SL.renda_SalF,0) AS VARCHAR),(CHARINDEX ('.', COALESCE(SL.renda_SalF,0), 0))+1,2)) AS [Salario],

	P.DtNasc_pes AS DtNasc_pes,
	CAP.CartTrab_CapRh AS [CTPS_Func],
	CAP.SerieCT_CapRh AS [SerieCT_Func],
	CAP.PisPasep_CapRh AS PisPasep_CapRh,
	CAP.HoraTrabSem_CapRh AS HoraTrabSem_CapRh,
	PD.Registro_Doc AS [Rg],
	PF.Sexo_pf AS Sexo_pf,
	PF.mae_pf AS mae_pf,
	PF.naturalid_pf AS naturalid_pf,
	P.Email_pes AS Email_pes,
	S.CodPes_Sind  AS CodigoSindicato,
	SI.NomeSindicato AS NomeSindicato,
	D.Cod_cad AS cod_departamento,
	D.Descr_cad AS departamento,
	ISNULL(PE.Endereco_pend, '') + ' ' + ISNULL(ComplEndereco_pend, '') AS Endereco_pend,
	PE.NumEnd_pend AS NumEnd_pend,
	PE.Bairro_pend AS Bairro_pend,
	PE.Cidade_pend AS Cidade_pend,
	PE.UF_pend AS UF_pend,
	PE.CEP_pend AS CEP_pend,
	'1 - Mensal' AS 'Tipo Salario',
	T.FoneRes AS Telefone,
	T.FoneCel AS Celular
		
FROM UAU.dbo.CapacitacaoRH AS CAP

LEFT JOIN UAU.dbo.Pessoas AS P
	ON COALESCE(CAP.CodPes_CapRH,'') = COALESCE(P.Cod_Pes,'')
LEFT JOIN UAU.dbo.Empresas AS E 
	ON COALESCE(CAP.Empresa_CapRH,'') = COALESCE(E.Codigo_Emp,'')
LEFT JOIN UAU.dbo.Obras AS O
	ON COALESCE(CAP.Obra_CapRH,'') = COALESCE(O.Cod_Obr,'') 
	AND COALESCE(CAP.Empresa_CapRH,'') = COALESCE(O.Empresa_Obr,'')
LEFT JOIN UAU.dbo.SituacaoFunc AS SF 
	ON COALESCE(CAP.CodSitF_CapRH,'') = COALESCE(SF.Codigo_SitF,'')
LEFT JOIN UAU.dbo.Cargos AS C
	ON COALESCE(CAP.CodCargo_CapRH,'') = COALESCE(C.Cod_Cad,'')
LEFT JOIN UAU.dbo.Funcao AS F
	ON COALESCE(CAP.NumFunc_CapRH,'') = COALESCE(F.Num_Func,'')
LEFT JOIN UAU.dbo.PesFis AS PF
	ON COALESCE(CAP.CodPes_Caprh,'') = COALESCE(PF.cod_pf,'')
LEFT JOIN PESSOA_DOC AS PD
	ON COALESCE(PD.CodPes_Doc,'') = COALESCE(PF.cod_pf,'')
LEFT JOIN UAU.dbo.SalarioFunc AS SL
	ON COALESCE(SL.CodPes_SalF,'') = COALESCE(CAP.CodPes_CapRH,'') 
	AND COALESCE(SL.NumCapRH_SalF,'') = COALESCE(CAP.Num_CapRH,'')
LEFT JOIN UAU.dbo.Sindicato AS S
	ON  COALESCE(S.CodPes_Sind,'') = COALESCE(CAP.CodPesSind_CapRh,'')
LEFT JOIN SINDICATO_F AS SI
    ON  COALESCE(S.CodPes_Sind,'') = COALESCE(SI.CodPesSindicato,'')
LEFT JOIN UAU.dbo.trechofuncionario AS TF
    ON  COALESCE(TF.NumCapRH_TrecFunc,'') = COALESCE(CAP.Num_CapRH,'')
    AND COALESCE(TF.NumTrec_trecfunc,'') = '0'
LEFT JOIN UAU.dbo.PesEndereco AS PE
    ON  COALESCE(PE.CodPes_pend,'') = COALESCE(P.cod_pes,'')
    AND COALESCE(PE.Tipo_pend,'') = 0 /* 0-Endereço principal */
LEFT JOIN UAU.dbo.Departamentos AS D
    ON  COALESCE(CAP.codDep_CapRH,'') = COALESCE(D.Cod_cad,'')
LEFT JOIN TELEFONE AS T
	ON COALESCE(T.pes_tel,'') = COALESCE(P.Cod_Pes,'')



WHERE 
CAP.Funcionario_CapRh = 1
--AND E.Codigo_emp IN (1,4,62,91)
--ORDER BY 1,3
go

