
CREATE VIEW [dbo].[VW_GER_CONTROLE_NOTAS_FISCAIS_ENTRADA] AS 

SELECT *
FROM
(
    SELECT anexos_nfe,
           empresa_nfe,
           num_nfe,
           numnfaux_nfe,
           nfeletronica_nfe,
           especie_nfe,
           serie_nfe,
           tipo_nfe,
           ufnf_nfe AS [UFDest_nfee],
           ufpgto_nfe,
           datacad_nfe,
           usuario_nfe,
           dataemis_nfe,
           datasaient_nfe,
           status_nfe,
           datacadstatus_nfe,
           usrcadstatus_nfe,
           iesubst_nfe,
           pracapgto_nfe,
           codservaux_nfe,
           especieaux_nfe,
           serieaux_nfe,
           empresaescr_nfe,
           empresas.desc_emp,
           codmodelo_mnf,
           obs_nfe,
           codpes_nfe,
           nome_pes,
           NotasFiscaisEntEndereco.cnpj AS [CNPJ_nfee],
           NotasFiscaisEntEndereco.inscestadual AS [InscEstadual_nfee],
           NotasFiscaisEntEndereco.inscmunicipal AS [InscMunicipal_nfee],
           NotasFiscaisEntEndereco.tipopes AS [TipoPes_nfee],
           NotasFiscaisEntEndereco.uf AS [UFEmitente_nfee],
           chavenfe_nfe,
           spedpiscofins_nfe,
           nfepropria_nfe,
           numapd_nfe,
           enviarspedreinf_nfe,
           codigottsr_nfe,
           descr_ttsr,
           obra_nfe,
           origem_nfe,
           COALESCE(notasfiscaisent.valortotnota_nfe, 0) AS ValorTotNota_nfe,
           COALESCE(notafiscalenttotalproduto.valtotprod_nfetp, 0) AS ValTotProd_nfetp,
           COALESCE(notafiscalenttotalproduto.valbaseicms_nfetp, 0) AS ValBaseIcms_nfetp,
           COALESCE(notafiscalenttotalproduto.valicms_nfetp, 0) AS ValIcms_nfetp,
           COALESCE(notafiscalenttotalproduto.valbaseipi_nfetp, 0) AS ValBaseIPI_nfetp,
           COALESCE(notafiscalenttotalproduto.valipi_nfetp, 0) AS ValIpi_nfetp,
           COALESCE(notafiscalenttotalproduto.valbaseicmssub_nfetp, 0) AS ValBaseIcmsSub_nfetp,
           COALESCE(notafiscalenttotalproduto.valicmssub_nfetp, 0) AS ValIcmsSub_nfetp,
           COALESCE(valisentasicms, 0) AS [ValIsentasICMS_nfetp],
           COALESCE(valoutrasicms, 0) AS [ValOutrasICMS_nfetp],
           COALESCE(valisentasipi, 0) AS [ValIsentasIPI_nfetp],
           COALESCE(valoutrasipi, 0) AS [ValOutrasIPI_nfetp],
           COALESCE(notafiscalenttotalproduto.valfrete_nfetp, 0) AS ValFrete_nfetp,
           COALESCE(notafiscalenttotalproduto.valseguro_nfetp, 0) AS ValSeguro_nfetp,
           COALESCE(notafiscalenttotalproduto.valdespacess_nfetp, 0) AS ValDespAcess_nfetp,
           COALESCE(notafiscalenttotalproduto.valdesconto_nfetp, 0) AS ValDesconto_nfetp,
           COALESCE(notafiscalenttotalservico.valtotserv_nfets, 0) AS ValTotServ_nfets,
           COALESCE(notafiscalenttotalservico.valbasecalculoiss_nfets, 0) AS ValBaseCalculoISS_nfets,
           COALESCE(notafiscalenttotalservico.valiss_nfets, 0) AS ValISS_nfets,
           COALESCE(notafiscalenttotalservico.valbasecalculoirrf_nfets, 0) AS ValBaseCalculoIRRF_nfets,
           COALESCE(notafiscalenttotalservico.valirrf_nfets, 0) AS ValIRRF_nfets,
           COALESCE(notafiscalenttotalservico.valbasecalculopis_nfets, 0) AS ValBaseCalculoPIS_nfets,
           COALESCE(notafiscalenttotalservico.valpis_nfets, 0) AS ValPIS_nfets,
           COALESCE(notafiscalenttotalservico.valbasecalculocofins_nfets, 0) AS ValBaseCalculoCOFINS_nfets,
           COALESCE(notafiscalenttotalservico.valcofins_nfets, 0) AS ValCOFINS_nfets,
           COALESCE(notafiscalenttotalservico.valbasecalculocssl_nfets, 0) AS ValBaseCalculoCSSL_nfets,
           COALESCE(notafiscalenttotalservico.valcssl_nfets, 0) AS ValCSSL_nfets,
           COALESCE(notafiscalenttotalservico.valbasecalculoinss_nfets, 0) AS ValBaseCalculoINSS_nfets,
           COALESCE(notafiscalenttotalservico.valinss_nfets, 0) AS ValINSS_nfets,
           COALESCE(notafiscalenttotalservico.valbasecalculoinssadicional_nfets, 0) AS ValBaseCalculoINSSAdicional_nfets,
           COALESCE(notafiscalenttotalservico.valinssadicional_nfets, 0) AS ValINSSAdicional_nfets,
           COALESCE(notafiscalenttotalservico.valbensociais_nfets, 0) AS ValBenSociais_nfets,
           Empresas_1.desc_emp AS DescEmpNFe
    FROM UAU.dbo.notasfiscaisent
        LEFT JOIN UAU.dbo.notafiscalenttotalproduto
            ON notasfiscaisent.empresa_nfe = notafiscalenttotalproduto.empresa_nfetp
               AND notasfiscaisent.num_nfe = notafiscalenttotalproduto.numnfe_nfetp
        LEFT JOIN UAU.dbo.notafiscalenttotalservico
            ON notasfiscaisent.empresa_nfe = notafiscalenttotalservico.empresa_nfets
               AND notasfiscaisent.num_nfe = notafiscalenttotalservico.numnfe_nfets
        LEFT JOIN
        (
            SELECT empresa_infep,
                   numnfe_infep,
                   (Sum(valtotisenta_infep)) AS ValIsentasICMS,
                   (Sum(valtotoutras_infep)) AS ValOutrasICMS,
                   Sum(valtotisentaipi_infep) AS ValIsentasIPI,
                   Sum(valtotoutrasipi_infep) AS ValOutrasIPI
            FROM UAU.dbo.notasfiscaisent
                INNER JOIN UAU.dbo.itensnotafiscalentproduto
                    ON itensnotafiscalentproduto.empresa_infep = notasfiscaisent.empresa_nfe
                       AND itensnotafiscalentproduto.numnfe_infep = notasfiscaisent.num_nfe
            --WHERE notasfiscaisent.empresa_nfe = 28
            GROUP BY empresa_infep,
                     numnfe_infep
        ) AS ItensNotaFiscalEntProduto
            ON notasfiscaisent.empresa_nfe = ItensNotaFiscalEntProduto.empresa_infep
               AND notasfiscaisent.num_nfe = ItensNotaFiscalEntProduto.numnfe_infep
        INNER JOIN  UAU.dbo.pessoas
            ON notasfiscaisent.codpes_nfe = pessoas.cod_pes
        INNER JOIN  UAU.dbo.empresas
            ON notasfiscaisent.empresaescr_nfe = empresas.codigo_emp
        LEFT JOIN UAU.dbo.modelonf
            ON notasfiscaisent.nummnf_nfe = modelonf.num_mnf
        LEFT JOIN
        (
            SELECT notasfiscaisentendereco.empresa_nfee,
                   notasfiscaisentendereco.numnfe_nfee,
                   notasfiscaisentendereco.tipopes_nfee AS TipoPes,
                   notasfiscaisentendereco.cnpj_nfee AS CNPJ,
                   notasfiscaisentendereco.inscrest_nfee AS InscEstadual,
                   notasfiscaisentendereco.inscrmunic_nfee AS InscMunicipal,
                   notasfiscaisentendereco.numend_nfee AS NumEndereco,
                   notasfiscaisentendereco.compl_nfee AS Complemento,
                   notasfiscaisentendereco.numbrrlogbrr_nfee AS NumBairro,
                   notasfiscaisentendereco.numlogrlogbrr_nfee AS NumLogradouro,
                   notasfiscaisent.codpes_nfe AS CodPessoa,
                   COALESCE(logradouro.desc_logr, pesendereco.endereco_pend) AS Endereco,
                   COALESCE(logradouro.cep_logr, cep_pend) AS CEP,
                   COALESCE(bairro.desc_brr, bairro_pend) AS Bairro,
                   COALESCE(cidades.desc_cid, cidade_pend) AS Cidade,
                   COALESCE(cidades.descuf_cid, uf_pend) AS UF,
                   COALESCE(cidades.num_cid, CidadesPessoas.num_cid) AS NumCidade,
                   COALESCE(cidades.codibge_cid, CidadesPessoas.codibge_cid) AS CodIBGE,
                   COALESCE(cidades.codmunicipio_cid, CidadesPessoas.codmunicipio_cid) AS CodMunicipio,
                   COALESCE(nacao.codigo_nacao, NacaoPessoas.codigo_nacao) AS CodNacao,
                   COALESCE(nacao.descr_nacao, NacaoPessoas.descr_nacao) AS DescrNacao,
                   COALESCE(nacao.codbancocentral_nacao, NacaoPessoas.codbancocentral_nacao) AS CodNacaoBACEN,
                   COALESCE(pessoas.dtcad_pes, '') AS DataCadPes,
                   COALESCE(pessoas.nome_pes, '') AS NomePessoa
            FROM UAU.dbo.notasfiscaisent
                INNER JOIN UAU.dbo.pessoas
                    ON notasfiscaisent.codpes_nfe = pessoas.cod_pes
                LEFT JOIN UAU.dbo.pesendereco
                    ON pesendereco.codpes_pend = pessoas.cod_pes
                       AND pesendereco.tipo_pend = 0
                /* 0-Endereço principal */
                LEFT JOIN UAU.dbo.cidades AS CidadesPessoas
                    ON pesendereco.numcid_pend = CidadesPessoas.num_cid
                LEFT JOIN UAU.dbo.nacao AS NacaoPessoas
                    ON NacaoPessoas.codigo_nacao = CidadesPessoas.codnacao_cid
                INNER JOIN UAU.dbo.notasfiscaisentendereco
                    ON notasfiscaisentendereco.empresa_nfee = notasfiscaisent.empresa_nfe
                       AND notasfiscaisentendereco.numnfe_nfee = notasfiscaisent.num_nfe
                LEFT JOIN UAU.dbo.logbairro
                    ON notasfiscaisentendereco.numbrrlogbrr_nfee = logbairro.numbrr_logbrr
                       AND notasfiscaisentendereco.numlogrlogbrr_nfee = logbairro.numlogr_logbrr
                LEFT JOIN UAU.dbo.logradouro
                    ON logbairro.numlogr_logbrr = logradouro.num_logr
                LEFT JOIN UAU.dbo.bairro
                    ON logbairro.numbrr_logbrr = bairro.num_brr
                LEFT JOIN UAU.dbo.cidades
                    ON bairro.numcid_brr = cidades.num_cid
                LEFT JOIN UAU.dbo.nacao
                    ON cidades.codnacao_cid = nacao.codigo_nacao
            WHERE notasfiscaisentendereco.tipo_nfee = 0
                  --AND notasfiscaisentendereco.empresa_nfee = 28
        ) AS NotasFiscaisEntEndereco
            ON notasfiscaisent.empresa_nfe = NotasFiscaisEntEndereco.empresa_nfee
               AND notasfiscaisent.num_nfe = NotasFiscaisEntEndereco.numnfe_nfee
        INNER JOIN UAU.dbo.empresas AS Empresas_1
            ON notasfiscaisent.empresa_nfe = Empresas_1.codigo_emp
        LEFT JOIN UAU.dbo.tabtiposervicoreinf
            ON codigottsr_nfe = codigo_ttsr
    --WHERE notasfiscaisent.empresa_nfe in ( 28 )
    --      AND notasfiscaisent.datasaient_nfe
    --      BETWEEN '07/01/2024' AND '07/31/2024'
) AS NotasFiscaisEntrada
WHERE Status_nfe = 1
      AND Tipo_nfe = 1
--ORDER BY NotasFiscaisEntrada.datasaient_nfe

go

