

CREATE VIEW [dbo].[VW_GER_CONTROLE_VLR_QNT_PEDIDO_COMPRA] AS 


with subConsultaPrecoItensContrato as (
SELECT
	im.Ins_Item CodigoInsumo,
	im.PrecoUnit_Item Preco,
	im.Unid_Item Unid,
	DATEADD(day, 1, EOMONTH(m.DataAprov_med)) dia,
	1 Linha,
	'0- Contrato' Origem,
	m.DataAprov_med
FROM UAU.dbo.ItensMedicao im
inner join UAU.dbo.Medicoes m
	on im.Empresa_Item = m.Empresa_med
		and im.Contrato_Item = m.Contrato_med
		and im.CodMed_Item = m.Cod_med
inner join UAU.dbo.Contratos c
	on m.Empresa_med = c.Empresa_cont
		and m.Contrato_med = c.Cod_cont
inner join (
	select distinct
		ic1.Empresa_itens,
		ic1.Contrato_itens,
		ic1.Serv_itens
	from UAU.dbo.ItensContrato ic1
) ic
	on im.Empresa_Item = ic.Empresa_itens
		and im.Contrato_Item = ic.Contrato_itens
		and im.Ins_Item = ic.Serv_itens
   ),

subConsultaPrecosUAU as (
SELECT 
	pic.CodigoInsumo,
	pic.Preco,
	pic.Unid,
	pic.dia,
	pic.Linha,
	pic.Origem
FROM subConsultaPrecoItensContrato pic
--where  pic.DataAprov_med >= :InicioDaBusca 

union all

SELECT 
	up.CodigoInsumo,
	up.Preco,
	up.Unid,
	up.Dia,
	up.Linha,
	up.Origem
from (
	select distinct
		isc.CodIns_Simc CodigoInsumo,
		isc.Preco_Simc Preco,
		pd.Unid_temp Unid,
		DATEADD(day, 1, EOMONTH(sc.Data_Smlc, -1)) Dia,
		ROW_NUMBER() over (PARTITION by isc.CodIns_Simc, Unid_temp order by sc.Data_Smlc desc) Linha,
		'1- Pedido' Origem
	from UAU.dbo.ItensSimuladosConf isc
	inner join UAU.dbo.ItensCot_temp pd
		on isc.Empresa_Simc = pd.Empresa_temp
			and isc.Obra_Simc = pd.Obra_temp
			and isc.CodIns_Simc = pd.Insumo_temp
	inner join UAU.dbo.SimulacoesConf sc
		on isc.Empresa_Simc = sc.Empresa_Smlc
			and isc.Cotacao_simc = sc.Numcot_Smlc
			and isc.NumSimu_Simc = sc.Numero_Smlc
	--where sc.Data_Smlc>= :InicioDaBusca
	
	union all
	
	select distinct
		ict.CodIns_Sim CodigoInsumo,
		ict.Preco_Sim Preco,
		pd.Unid_temp Unid,
		DATEADD(day, 1, EOMONTH(s.Data_Sml, -1)) Dia,
		ROW_NUMBER() over (PARTITION by ict.CodIns_Sim, Unid_temp order by s.Data_Sml desc) Linha,
		'1- Pedido' Origem
	from UAU.dbo.ItensSimulados ict
	inner join UAU.dbo.ItensCot_temp pd
		on ict.Empresa_sim = pd.Empresa_temp
			and ict.CodIns_Sim = pd.Insumo_temp
	inner join UAU.dbo.Simulacoes s
		on ict.empresa_sim = s.Empresa_sml
			and ict.cotacao_sim = s.NumCot_sml
			and ict.NumSimu_sim = s.Numero_sml
	where ict.CodIns_Sim not in (
		select 
			isc1.CodIns_Simc 
		from UAU.dbo.ItensSimuladosConf isc1
	)
) up
)
SELECT
	P.Empresa_temp,
	P.Obra_temp,
	P.Insumo_temp,
	P.Insumo,
	P.Qtde,
	P.Localizacao,
	pu.unid,
	iif((p.Localizacao = '0- Não cotato' or p.preco = 0), pu.preco, p.preco) Preco,
	iif((p.Localizacao = '0- Não cotato' or p.preco = 0), pu.preco, p.preco) * P.Qtde Valor,
	iif((p.Localizacao = '0- Não cotato' or p.preco = 0), pu.Dia, null) DiaDaCotacao
FROM (
	select 
		s.Empresa_ServTemp Empresa_temp,
		s.Obra_ServTemp Obra_temp,
		s.Serv_ServTemp Insumo_temp,
		c.Descr_comp Insumo,
		s.Qtde_ServTemp Qtde,
		'0- Não cotato' Localizacao,
		s.Unid_ServTemp Unid_temp,
		'0- Contrato' Origem,
		0.00000 Preco
	from UAU.dbo.ItensCotServ_temp s
	inner join UAU.dbo.Composicoes c
		on s.Serv_ServTemp = c.Cod_comp
	where s.Excluido_Servtemp = 0
		and coalesce(s.Cotacao_ServTemp, 0) = 0
		--and s.Obra_ServTemp  = :obrauau 
		--and s.Empresa_ServTemp  = :empresa

	UNION ALL
  
	select
		s.Empresa_ServTemp Empresa_temp,
		s.Obra_ServTemp Obra_temp,
		s.Serv_ServTemp Insumo_temp,
		c.Descr_comp Insumo,
		ics.QtdeCot_ItemServ Qtde,
		'1 - Cotado' Localizacao,
		ics.Unid_ItemServ Unid_temp,
		'0- Contrato' Origem,
		COALESCE(ics.Preco_ItemServ, 0) Preco
	from UAU.dbo.ItensCotServ_temp s
	inner join UAU.dbo.Composicoes c
		on s.Serv_ServTemp = c.Cod_comp
	INNER JOIN UAU.dbo.Cotacao c2
		on s.Empresa_ServTemp = c2.Empresa_cot
			and c2.Num_cot = s.Cotacao_ServTemp
	inner join UAU.dbo.ItensCotacaoServ ics
		on s.Serv_ServTemp = ics.serv_itemserv
			and s.Empresa_ServTemp = ics.Empresa_ItemServ
			and s.Cotacao_ServTemp = ics.NumCot_ItemServ
	left join UAU.dbo.ItensSimuladosConfServ iscs
		on s.Empresa_ServTemp = iscs.Empresa_SimcServ
			and s.Serv_ServTemp = iscs.Serv_SimcServ
			and s.Cotacao_ServTemp = iscs.Cotacao_SimcServ
	where iscs.Empresa_SimcServ is null
		and coalesce(s.Cotacao_ServTemp, 0) > 0
		--and s.Obra_ServTemp  = :obrauau 
		--and s.Empresa_ServTemp  = :empresa

	union all
    
	select
		s.Empresa_temp Empresa_temp,
		s.Obra_Temp Obra_temp,
		s.Insumo_temp Insumo_temp,
		c.Descr_ins Insumo,
		ics.QtdeCot_item Qtde,
		'1 - Cotado' Localizacao,
		ics.Unid_item Unid_temp,
		'1- Pedido' Origem,
		COALESCE(ics.Preco_item, 0) Preco
	from UAU.dbo.ItensCot_temp s
	inner join UAU.dbo.InsumosGeral c
		on s.Insumo_temp = c.Cod_ins
	INNER JOIN UAU.dbo.Cotacao c2
		on s.Empresa_temp = c2.Empresa_cot
			and c2.Num_cot = s.Cotacao_temp
	inner join UAU.dbo.ItensCotacao ics
		on s.Insumo_temp = ics.CodIns_item
			and s.Empresa_temp = ics.Empresa_item
			and s.Cotacao_temp = ics.NumCot_item
	left join UAU.dbo.ItensSimuladosConf iscs
		on s.Empresa_Temp = iscs.Empresa_Simc
			and s.Insumo_temp = iscs.CodIns_Simc
			and s.Cotacao_temp = iscs.Condicao_Simc
	left join UAU.dbo.OrdemCompra oc
		on s.Empresa_temp = oc.Empresa_Ocp
			and s.Obra_temp = oc.Obra_Ocp
			and s.Cotacao_temp = oc.NumCot_Ocp
	where s.Estagio_temp <= 4
		and iscs.Empresa_Simc is null
		and COALESCE(s.Cotacao_temp, 0) > 0
		and oc.Empresa_Ocp is null
		--and s.Obra_Temp =:obrauau 
		--and s.Empresa_temp =  :empresa

	union all
    
	select 
		s.Empresa_temp Empresa_temp,
		s.Obra_Temp Obra_temp,
		s.Insumo_temp Insumo_temp,
		c.Descr_ins Insumo,
		s.Qtde_temp Qtde,
		'0 - Não cotado' Localizacao,
		s.Unid_temp Unid_temp,
		'1- Pedido' Origem,
		0.00000 Preco_item
	from UAU.dbo.ItensCot_temp s
	inner join UAU.dbo.InsumosGeral c
		on s.Insumo_temp = c.Cod_ins
	where coalesce(s.Cotacao_temp, 0) = 0
		--and s.Obra_temp  = :obrauau 
		--and s.Empresa_temp = :empresa
) P
left join subConsultaPrecosUAU pu
    on P.Insumo_temp = pu.CodigoInsumo
        and P.Unid_temp = pu.Unid
        and p.Origem = Pu.origem
where (pu.Linha = 1
			and p.Origem = '1- Pedido')
    OR (pu.Linha is null
            and p.Origem = '0- Contrato')
--ORDER BY 
--	Empresa_temp,
--    Obra_temp,
--    Insumo
go

