
CREATE VIEW [dbo].[VW_GER_CONTROLE_FISCAL_DESPESA_PAGAS_LANCAMENTOS] AS 

SELECT *
FROM
(
    SELECT ResumoFiscal.*
         , Bancos.Nome_banco                                  AS NomeBanco
         , COALESCE(NOME_PES, 'Fornececedor não cadastrado!') AS Nome_Pes
         , Desc_cmf
    FROM UAU.dbo.ResumoFiscal
        INNER JOIN UAU.dbo.Bancos
            ON ResumoFiscal.BancoProc_Ref = Bancos.Numero_banco
        LEFT JOIN UAU.dbo.CategoriasDeMovFin
            ON ResumoFiscal.CategMovFin_Ref = CategoriasDeMovFin.Codigo_cmf
        LEFT JOIN UAU.dbo.Pessoas
            ON Pessoas.Cod_pes = ResumoFiscal.CodForn_Ref
    WHERE (NOT EXISTS
    (
        SELECT BancoContaUsuarios.Banco_BcoCont
        FROM UAU.dbo.BancoContaUsuarios WITH (NOLOCK)
        WHERE Usuario_BcoCont = 'KEICY'
              AND ResumoFiscal.Empresa_ref = BancoContaUsuarios.Empresa_BcoCont
              AND ResumoFiscal.BancoProc_ref = BancoContaUsuarios.Banco_BcoCont
              AND ResumoFiscal.Conta_ref = BancoContaUsuarios.Conta_BcoCont
    )
              )
          --AND Empresa_ref = 54 
          --AND DataEmissao_Ref
          --BETWEEN '09/01/2024' And '09/30/2024'
) AS ResumoFiscal
--ORDER BY ValorProc_Ref
go

