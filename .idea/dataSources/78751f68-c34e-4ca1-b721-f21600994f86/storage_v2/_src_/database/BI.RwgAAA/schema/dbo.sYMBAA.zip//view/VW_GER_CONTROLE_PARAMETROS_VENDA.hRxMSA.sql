

CREATE view [dbo].[VW_GER_CONTROLE_PARAMETROS_VENDA] AS

SELECT VendasLogParc.* FROM (
   SELECT * FROM UAU.dbo.VendasLogParc WITH(NOLOCK) 
   UNION
   SELECT * FROM UAU.dbo.VendRecLogParc WITH(NOLOCK) 
 ) AS VendasLogParc 

go

