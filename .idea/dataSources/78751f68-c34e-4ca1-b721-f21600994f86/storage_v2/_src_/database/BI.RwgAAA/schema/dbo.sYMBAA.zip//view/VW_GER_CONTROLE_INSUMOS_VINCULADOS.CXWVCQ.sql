
-- INSUMOS VINCULADOS

 CREATE VIEW [dbo].[VW_GER_CONTROLE_INSUMOS_VINCULADOS]
AS 

select 
	ip.Empresa_pedsi, 
	ip.Obra_pedsi , 
	ip.Contrato_pedsi , 
	ip.Produto_pedsi,
	ip.Item_pedsi, 
	ip.Servico_pedsi, 
	ip.InsVinc_pedsi InsumoPlanejamento, 
	ip.Qtde_pedsi,
	ip.Insumo_pedsi , 
	ict.Insumo_temp, 
	ict.Unid_temp  , 
	i.Unid_ins UnidadePlanejamento  ,
	null  Fator, 
	ip.Qtde_pedsi * 1 QtdePedido, 
	i.Descr_ins  
from UAU.dbo.ItensCot_temp ict 
inner join UAU.dbo.Pedidos p 
	on ict.Empresa_temp  = p.Empresa_ped 
		and ict.Obra_temp = p.Obra_ped
		and ict.NumPedido_temp  = p.cod_ped 
inner join UAU.dbo.ItemPedSi ip 
	on ict.Empresa_temp = ip.Empresa_pedsi 
		and ict.Obra_temp  = ip.Obra_pedsi 
		and ict.NumPedido_temp  = ip.NumPedido_pedsi 
		and ict.ItemPed_Temp = ip.ItemPed_pedsi 
		and ict.Insumo_temp  = ip.Insumo_pedsi                               
inner join UAU.dbo.Insumos i 
	on ip.Empresa_pedsi = i.Empresa_ins 
		and ip.Obra_pedsi  = i.Obra_ins 
		and ip.InsVinc_pedsi = i.Cod_ins 
where ict.Unid_temp = i.Unid_ins                

union ALL

select 
	ip.Empresa_pedsi, 
	ip.Obra_pedsi , 
	ip.Contrato_pedsi , 
	ip.Produto_pedsi,
	ip.Item_pedsi, 
	ip.Servico_pedsi, 
	ip.InsVinc_pedsi InsumoPlanejamento, 
	ip.Qtde_pedsi,
	ip.Insumo_pedsi , 
	ict.Insumo_temp, 
	ict.Unid_temp  , 
	i.Unid_ins UnidadePlanejamento , 
	(
		select 
			cu.Fator_cu 
		from UAU.dbo.ConversaoUnid cu 
		where cu.UnidPL_cu = i.Unid_ins 
			and cu.UnidConvertida_cu  = ict.Unid_temp 
	)  Fator, 
	ip.Qtde_pedsi * (
		select 
			cu.Fator_cu 
		from UAU.dbo.ConversaoUnid cu 
		where cu.UnidPL_cu = i.Unid_ins 
			and cu.UnidConvertida_cu  = ict.Unid_temp ) QtdePedido,
	i.Descr_ins  
from UAU.dbo.ItensCot_temp ict 
inner join UAU.dbo.Pedidos p 
	on ict.Empresa_temp  = p.Empresa_ped 
		and ict.Obra_temp = p.Obra_ped
		and ict.NumPedido_temp  = p.cod_ped 
inner join UAU.dbo.ItemPedSi ip 
	on ict.Empresa_temp = ip.Empresa_pedsi 
		and ict.Obra_temp  = ip.Obra_pedsi 
		and ict.NumPedido_temp  = ip.NumPedido_pedsi 
		and ict.ItemPed_Temp = ip.ItemPed_pedsi 
		and ict.Insumo_temp  = ip.Insumo_pedsi                               
inner join UAU.dbo.Insumos i 
	on ip.Empresa_pedsi  = i.Empresa_ins 
		and ip.Obra_pedsi  = i.Obra_ins 
		and ip.InsVinc_pedsi = i.Cod_ins 
where ict.Unid_temp <> i.Unid_ins                
	--and ict.Empresa_temp= 28 --:empresa
	--and ict.Obra_temp = '2801C'--:obraUAU
go

