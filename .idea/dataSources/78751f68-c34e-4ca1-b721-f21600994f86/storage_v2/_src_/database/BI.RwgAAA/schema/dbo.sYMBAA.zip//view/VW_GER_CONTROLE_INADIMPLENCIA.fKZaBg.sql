

CREATE VIEW [dbo].[VW_GER_CONTROLE_INADIMPLENCIA] AS 

WITH PESSOAS AS (
SELECT 
	cod_pes, 
	nome_pes, 
	cpf_pes, 
	dtnasc_pes, 
	Email_pes
FROM UAU.dbo.Pessoas 
)
, EMPRESA AS (
SELECT Empresas.Codigo_emp AS CODEMP,
       Empresas.Desc_emp AS EMPRESA,
	   CASE 
			WHEN Obras.cod_obr = '0001' then '001'
			WHEN Obras.cod_obr = '0002' then '002'
			WHEN Obras.cod_obr = '0003' then '003'
			WHEN Obras.cod_obr = '0004' then '004'
			WHEN Obras.cod_obr = '0005' then '005'
			else Obras.cod_obr end AS CODOBR,
       Obras.descr_obr AS OBRA,
       CAST(Empresas.Codigo_emp AS varchar(5)) + '-' + CAST(Obras.cod_obr AS VARCHAR(5)) AS CHAVE,
       Obras.CodGrupo_obr,
	   concat(Empresas.Codigo_emp,'-',Empresas.Desc_emp) as [Cod-NomeEmpresa],
	   concat(Obras.cod_obr,'-',Obras.descr_obr) as [Cod_NomeObra]
FROM UAU.dbo.Obras
    INNER JOIN UAU.dbo.Empresas
        ON Obras.Empresa_obr = Empresas.Codigo_emp
)
, VENDAS AS (
SELECT * FROM BI.dbo.VW_GER_CONTROLE_VENDAS)

SELECT 
	INADIMPLENCIA.*
FROM (
SELECT 

	EMPRESA.[Cod-NomeEmpresa],
	VENDAS.Identificador_unid,
	VENDAS.nome_pes,
    BSE.[Num Parc],
    BSE.Tipo,
    BSE.[Data Vencimento],
	DATEDIFF(DAY,BSE.[Data Vencimento],GETDATE()) AS [Dias Em Aberto],
    BSE.[VLR Parcela],
    BSE.[VLR Principal],
    BSE.[VLR Juros por atraso],
    BSE.[VLR Multa por atraso],
    BSE.[VLR Correção],
    BSE.[VLR Correção por atraso],
	VENDAS.Data_Ven
	
	--BSE.CHAVE,
    --BSE.CHAVE_VENDA,
    --BSE.Empresa,
    --BSE.Obra,
    --BSE.Cliente,
    --BSE.Venda,
    --BSE.Tipo_Prc,
    --BSE.[Num Parc Geral],
    --BSE.[Data Prorrogação],
    --BSE.[VLR Juros compensatorios],
	--BSE.ValDescontoCusta_crc,
    --BSE.ValDescontoImposto_crc,
    --BSE.[VLR Taxa de boleto],
    --BSE.ValParcelaAntec_crc,
    --BSE.ValJurosCompAntec_crc,
    --BSE.ValDescontoCusta_Prc,
    --BSE.TotParc_Prc,
    --BSE.DtParc_Prc,
    --BSE.DataCalc_crc

FROM (
SELECT CAST(ContasReceber.Empresa_prc AS varchar(5)) + '-' + CAST(ContasReceber.Obra_Prc AS VARCHAR(5)) AS CHAVE,
       CAST(ContasReceber.Empresa_prc AS varchar(5)) + '-' + CAST(ContasReceber.Obra_Prc AS VARCHAR(5)) + '-'
       + CAST(ContasReceber.NumVend_prc AS VARCHAR(5)) AS CHAVE_VENDA,
       ContasReceber.Empresa_prc AS Empresa,
       ContasReceber.Obra_Prc AS Obra,
       ContasReceber.Cliente_Prc AS Cliente,
       ContasReceber.NumVend_prc AS Venda,
       ContasReceber.Tipo_Prc,
       Parcelas.Descricao_par AS Tipo,
       ContasReceber.NumParc_Prc AS [Num Parc],
       ContasReceber.NumParcGer_Prc AS [Num Parc Geral],
       crc.ValParcela_crc AS [VLR Parcela],
       ContasReceber.Data_Prc AS [Data Vencimento],
       ContasReceber.DataPror_Prc AS [Data Prorrogação],
       crc.ValPrincipal_crc AS [VLR Principal],
       crc.ValJurosComp_crc AS [VLR Juros compensatorios],
       crc.ValCorrecao_crc AS [VLR Correção],
       crc.ValJuroAtraso_crc AS [VLR Juros por atraso],
       crc.ValMultaAtraso_crc AS [VLR Multa por atraso],
       crc.ValCorrecaoAtraso_crc AS [VLR Correção por atraso],
       crc.ValDescontoCusta_crc,
       crc.ValDescontoImposto_crc,
       crc.ValTaxaBol_crc AS [VLR Taxa de boleto],
       crc.ValParcelaAntec_crc,
       crc.ValJurosCompAntec_crc,
       crc.ValCorrecaoAntec_crc AS ValDescontoCusta_Prc,
       ContasReceber.TotParc_Prc,
       ContasReceber.DtParc_Prc,
       crc.DataCalc_crc
FROM UAU.dbo.ContasReceber
    INNER JOIN UAU.dbo.ContasReceberCalc AS crc
        ON ContasReceber.Empresa_prc = crc.Empresa_crc
           AND ContasReceber.Obra_Prc = crc.Obra_crc
           AND ContasReceber.NumVend_prc = crc.NumVend_crc
           AND ContasReceber.NumParc_Prc = crc.NumParc_crc
           AND ContasReceber.NumParcGer_Prc = crc.NumParcGer_crc
           AND ContasReceber.Tipo_Prc = crc.Tipo_crc
    INNER JOIN UAU.dbo.Parcelas
        ON ContasReceber.Tipo_Prc = Parcelas.Tipo_par
    INNER JOIN UAU.dbo.Obras
        ON ContasReceber.Empresa_prc = Obras.Empresa_obr
           AND ContasReceber.Obra_Prc = Obras.cod_obr

WHERE CAST(ContasReceber.Empresa_prc AS varchar(5)) + '-' + CAST(ContasReceber.Obra_Prc AS VARCHAR(5)) IS NOT NULL 
OR CAST(ContasReceber.Empresa_prc AS varchar(5)) + '-' + CAST(ContasReceber.Obra_Prc AS VARCHAR(5)) <> ''

) AS BSE

LEFT JOIN VENDAS
	ON BSE.CHAVE_VENDA = VENDAS.CHAVE_VENDA

LEFT JOIN EMPRESA
	ON BSE.CHAVE = EMPRESA.CHAVE

WHERE BSE.Obra NOT LIKE '%F%'
AND BSE.Empresa > 0

) AS INADIMPLENCIA

WHERE INADIMPLENCIA.[Dias Em Aberto] > 0
AND INADIMPLENCIA.Identificador_unid IS NOT NULL



go

