

CREATE VIEW [dbo].[VW_GER_CONTROLE_COMENTARIOS] AS 


SELECT 
	Comentario.Empresa_Com,
	CASE
		WHEN LEN(Comentario.NumDoc_Com) - LEN(REPLACE(Comentario.NumDoc_Com, '-', '')) = 1 THEN
			SUBSTRING(Comentario.NumDoc_Com,(CHARINDEX('-',Comentario.NumDoc_Com,0)+1),((LEN(Comentario.NumDoc_Com))-(CHARINDEX('-',Comentario.NumDoc_Com,0))))
		ELSE SUBSTRING(REPLACE(Comentario.NumDoc_Com,' -','+'),(CHARINDEX('-',REPLACE(Comentario.NumDoc_Com,' -','+'),0)+1),((LEN(REPLACE(Comentario.NumDoc_Com,' -','+')))-(CHARINDEX('-',REPLACE(Comentario.NumDoc_Com,' -','+'),0)))) 
		END AS Obra_Com,
	CASE
		WHEN LEN(Comentario.NumDoc_Com) - LEN(REPLACE(Comentario.NumDoc_Com, '-', '')) = 1 THEN
			SUBSTRING(Comentario.NumDoc_Com,1,(CHARINDEX(' ',Comentario.NumDoc_Com,0)-1))
			ELSE SUBSTRING(REPLACE(Comentario.NumDoc_Com,' -','+'),1,(CHARINDEX('+',REPLACE(Comentario.NumDoc_Com,' -','+'),0)-1)) 
			END AS Documento_Com,
	CASE
		WHEN LEN(Comentario.NumDoc_Com) - LEN(REPLACE(Comentario.NumDoc_Com, '-', '')) = 1 THEN
			SUBSTRING(Comentario.NumDoc_Com,(CHARINDEX(' ',Comentario.NumDoc_Com,0)+1),((CHARINDEX('-',Comentario.NumDoc_Com,0))-(CHARINDEX(' ',Comentario.NumDoc_Com,0)))-1)
		ELSE SUBSTRING(REPLACE(Comentario.NumDoc_Com,' -','+'),(CHARINDEX('+',REPLACE(Comentario.NumDoc_Com,' -','+'),0)+1),((CHARINDEX('-',REPLACE(Comentario.NumDoc_Com,' -','+'),0))-(CHARINDEX('+',REPLACE(Comentario.NumDoc_Com,' -','+'),0)))-1) 
		END AS NumDocProc_Com,
	--Comentario.NumDoc_Com,
	Comentario.User_Com,
	Comentario.DataHora_Com,
	--Comentario.Tipo_Com,
	--Comentario.UsrLogin_Com,
	--Comentario.CodGrupo_Com,
	Comentario.Comentario_Com,
	--Comentario.Excluido_Com, -- (0 = Não , 1 = Sim)
	CASE 
		WHEN Comentario.Excluido_Com = 0 THEN '0 - Não'
		WHEN Comentario.Excluido_Com = 1 THEN '1 - Sim'
		END AS ComentarioExcluido,
	CASE 
		WHEN Comentario.Tipo_Com = 0 THEN '0 - Público'
		WHEN Comentario.Tipo_Com = 1 THEN '1 - Privado'
		WHEN Comentario.Tipo_Com = 2 THEN '2 - Interno'
		END AS DescrTipoComentario,
	--COALESCE(Comentario.Categoria_Com, '-') AS Categoria_Com,
	COALESCE(CategoriasDeComentario.Desc_cger, 'Sem categoria') AS Desc_cger

FROM UAU.dbo.Comentario
    LEFT OUTER JOIN UAU.dbo.CategoriasDeComentario
        ON Comentario.Categoria_Com = CategoriasDeComentario.Codigo_cger
    LEFT JOIN (
        SELECT 
			t.NumDoc_Com,
            r.Empresa_Com,
            r.MaxTime --,t.Tipo_Com
        FROM (
            SELECT 
				NumDoc_Com,
                Empresa_com,
                MIN(DataHora_Com) as MaxTime
            FROM UAU.dbo.Comentario
            WHERE Tipo_Com = 0
            GROUP BY 
				NumDoc_Com,
                Empresa_com
        ) AS r
            INNER JOIN UAU.dbo.Comentario t
                ON t.NumDoc_Com = r.NumDoc_Com
                   AND t.DataHora_Com = r.MaxTime
        WHERE t.NumDoc_Com LIKE ('PROCESSO%')
              AND (t.Tipo_Com IN ( 0 ))
    ) AS unico
        ON unico.NumDoc_Com = Comentario.NumDoc_Com
           AND unico.MaxTime = Comentario.DataHora_Com


WHERE Comentario.NumDoc_Com LIKE ('PROCESSO%')
	AND (Comentario.Excluido_Com = 0)
	AND unico.NumDoc_Com is not null
	--AND Comentario.User_Com IN ('karol.sa','karollin')
	--AND LEN(Comentario.NumDoc_Com) - LEN(REPLACE(Comentario.NumDoc_Com, '-', '')) > 1

go

