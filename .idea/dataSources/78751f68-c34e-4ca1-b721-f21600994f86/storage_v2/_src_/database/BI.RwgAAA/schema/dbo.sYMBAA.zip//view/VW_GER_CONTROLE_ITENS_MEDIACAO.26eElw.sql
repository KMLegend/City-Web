

 CREATE VIEW [dbo].[VW_GER_CONTROLE_ITENS_MEDIACAO] AS 
 
 SELECT 
        c.Empresa_cont,
        c.Cod_cont,
        c.Objeto_cont,
        m.Status_med,
        ic.Serv_itens,
        im.Unid_Item,
        im.Qtde_Item,
        im.PrecoUnit_Item
        --im.Qtde_Item * im.PrecoUnit_Item ValorSemMedicao
    FROM UAU.dbo.ItensMedicao im
    inner join UAU.dbo.Medicoes m
        on im.Empresa_Item = m.Empresa_med
            and im.Contrato_Item = m.Contrato_med
            and im.CodMed_Item = m.Cod_med
    inner join UAU.dbo.Contratos c
        on m.Empresa_med = c.Empresa_cont
            and m.Contrato_med = c.Cod_cont
    inner join (
        select distinct
            ic1.Empresa_itens,
            ic1.Contrato_itens,
            ic1.Serv_itens
        from UAU.dbo.ItensContrato ic1
        where ic1.tipoServMat_itens = 1
    ) ic
        on im.Empresa_Item = ic.Empresa_itens
            and im.Contrato_Item = ic.Contrato_itens
            and im.Ins_Item = ic.Serv_itens
    where m.Status_med = 3
    --and m.Empresa_med  = 12 --:empresa
    --and c.Obra_cont = '0501C'--:obraUAU

    union all

    SELECT 
        c.Empresa_cont,
        c.Cod_cont,
        c.Objeto_cont,
        m.Status_med,
        ic.Serv_itens,
        im.Unid_Item,
        im.Qtde_Item,
        im.PrecoUnit_Item
        --im.Qtde_Item * im.PrecoUnit_Item ValorSemMedicao
    FROM UAU.dbo.ItensMedicao im
    inner join UAU.dbo.Medicoes m
        on im.Empresa_Item = m.Empresa_med
            and im.Contrato_Item = m.Contrato_med
            and im.CodMed_Item = m.Cod_med
    inner join UAU.dbo.Contratos c
        on m.Empresa_med = c.Empresa_cont
            and m.Contrato_med = c.Cod_cont
    inner join (
        select distinct
            ic1.Empresa_itens,
            ic1.Contrato_itens,
            ic1.Serv_itens
        from UAU.dbo.ItensContrato ic1
        where ic1.tipoServMat_itens = 0
    ) ic
        on im.Empresa_Item = ic.Empresa_itens
            and im.Contrato_Item = ic.Contrato_itens
            and im.Ins_Item = ic.Serv_itens
    where m.Status_med < 2
    --and m.Empresa_med = 12 --:empresa
    --and c.Obra_cont = '0501C'--:obraUAU
go

