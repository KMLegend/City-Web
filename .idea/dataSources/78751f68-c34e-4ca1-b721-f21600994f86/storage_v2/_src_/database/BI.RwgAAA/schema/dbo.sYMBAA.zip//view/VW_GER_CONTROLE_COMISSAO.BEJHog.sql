



CREATE VIEW [dbo].[VW_GER_CONTROLE_COMISSAO] AS (

SELECT    
	V.Empresa_Ctrc,      --smallint 
	--V.Desc_emp,       
	V.Obra_Ctrc,       --varchar(5)
	--V.descr_obr,        
	V.NumVend_ctrc,     --int  
	V.Data_Ven,      --datetime 
	--V.Cargo,       
	V.CodPes_Ctrc,       
	V.Corretor,       
	--V.ValorTot_Ven,       
	--V.PorcentComissao_itv,      
	--V.ComissaoDistribuir,       
	--V.Status_ctrc,       
	--V.Cliente,       
	V.TipoPgto, 
	V.Identificador_unid,     --varchar(30)  
	V.StatusCom,
	--V.Pers01,       
	--V.Pers02,   
	--V.PercentualCorretor,
	SUM(V.ValComissao_ctrc) AS Total,      
	--V.ComissaoVenda,  
	--V.ValAcrescimo_ctrc,        
	--V.ValDesconto_ctrc,   
	SUM(V.ValorLiq) AS ValorLiq   --numeric(18,6) 
	--V.TotProduto,      
	--V.QtdeParcelas,      
	--V.CHAVE,     
	--V.Chave2    

FROM (

SELECT    
	ControleComissao.Empresa_Ctrc,       
	Empresas.Desc_emp,       
	ControleComissao.Obra_Ctrc,       
	Obras.descr_obr,        
	ControleComissao.NumVend_ctrc,       
	Vendas.Data_Ven,        
	Cargos.Descr_cad AS Cargo,       
	ControleComissao.CodPes_Ctrc,       
	Corretor.nome_pes AS Corretor,       
	Vendas.ValorTot_Ven,       
	ItensVenda.PorcentComissao_itv,      
	((ItensVenda.PrecoProc_itv * ItensVenda.Qtde_itv ) * (ItensVenda.PorcentComissao_itv / 100)) AS ComissaoDistribuir,       
	ControleComissao.Status_ctrc,       
	Cliente.nome_pes AS Cliente,       
	UnidadePer.Identificador_unid,       
	UnidadePer.C1_unid AS Pers01,       
	UnidadePer.C2_unid AS Pers02,   
	((ControleComissao.ValComissao_ctrc) / ((ItensVenda.PrecoProc_itv * ItensVenda.Qtde_itv ) * (ItensVenda.PorcentComissao_itv / 100)) * 100) AS PercentualCorretor,    
	(ControleComissao.ValComissao_ctrc * ItensVenda.PorcentItem_itv) AS ValComissao_ctrc,      
	ControleComissao.ValComissao_ctrc / Vendas.ValorTot_Ven * 100 AS ComissaoVenda,  
	(ControleComissao.ValAcrescimo_ctrc * ItensVenda.PorcentItem_itv) AS ValAcrescimo_ctrc,        
	(ControleComissao.ValDesconto_ctrc * ItensVenda.PorcentItem_itv) AS ValDesconto_ctrc,   
	(ControleComissao.ValComissao_ctrc + ControleComissao.ValAcrescimo_ctrc - ControleComissao.ValDesconto_ctrc) * ItensVenda.PorcentItem_itv AS ValorLiq,    
	CASE    
		WHEN ControleComissao.PgtoDireto_ctrc = 0 THEN '0 - DIRETO'         
		ELSE '1 - INDIRETO' END AS TipoPgto,   
	CASE ControleComissao.Status_ctrc         
		WHEN 0 THEN '0 - NÃO LIBERADA'         
		WHEN 1 THEN '1 - LIBERADA'         
		WHEN 2 THEN '2 - PAGA'         
		WHEN 3 THEN '3 - CANCELADA'         
		WHEN 4 THEN '4 - BLOQUEADA'    
		END AS StatusCom,     
	(ItensVenda.PrecoProc_itv * ItensVenda.Qtde_itv ) AS TotProduto,      
	MAX(ParametrosVenda.NumParc_Vlp) AS QtdeParcelas,      
	CONCAT(CAST(ControleComissao.Empresa_Ctrc AS VARCHAR),(ControleComissao.Obra_Ctrc),CAST(ControleComissao.NumVend_Ctrc AS VARCHAR)) AS CHAVE,     
	CONCAT(CAST(ControleComissao.Empresa_Ctrc AS VARCHAR),ControleComissao.Obra_Ctrc,(CAST(ControleComissao.NumVend_Ctrc AS VARCHAR)),(CAST(ControleComissao.NumComissao_Ctrc AS VARCHAR)),(CAST(ControleComissao.CodPes_Ctrc AS VARCHAR)),(CAST(UnidadePer.Identificador_unid AS VARCHAR))) AS Chave2    

FROM  UAU.dbo.ControleComissao  

LEFT JOIN UAU.dbo.Cargos    
	ON Cargos.Cod_cad = ControleComissao.CodCargo_ctrc  

INNER JOIN (     
	SELECT      
		V.Empresa_ven,     
		V.Obra_Ven,     
		V.Num_Ven,     
		V.Data_Ven,    
		V.ValorTot_Ven,     
		V.Cliente_Ven           
	FROM  UAU.dbo.Vendas AS V          

	UNION            

	SELECT    
		VR.Empresa_VRec,    
		VR.Obra_VRec,    
		VR.Num_VRec,    
		VR.Data_VRec,    
		VR.ValorTot_VRec,    
		VR.Cliente_VRec            
	FROM  UAU.dbo.VendasRecebidas AS VR  
) AS Vendas 
	ON ControleComissao.Empresa_ctrc = Vendas.Empresa_ven        
	AND ControleComissao.Obra_ctrc = Vendas.Obra_Ven        
	AND ControleComissao.NumVend_ctrc = Vendas.Num_Ven       

INNER JOIN (       
	SELECT          
		IV.Empresa_itv,         
		IV.Obra_Itv,         
		IV.NumVend_Itv,         
		IV.Produto_Itv,         
		IV.CodPerson_Itv,         
		IV.PorcentComissao_itv,         
		IV.PrecoProc_itv,         
		IV.Qtde_itv,         
		IV.PorcentItem_itv                
	FROM  UAU.dbo.ItensVenda AS IV                

	UNION             

	SELECT          
		IR.Empresa_itr,         
		IR.Obra_Itr,        
		IR.NumVend_Itr,         
		IR.Produto_Itr,         
		IR.CodPerson_Itr,         
		IR.PorcentComissao_itr,         
		IR.PrecoProc_itr,        
		IR.Qtde_itr,         
		IR.PorcentItem_itr            
	FROM  UAU.dbo.ItensRecebidas AS IR 
) AS ItensVenda       
	ON ItensVenda.Empresa_itv = Vendas.Empresa_ven        
	AND ItensVenda.Obra_Itv = Vendas.Obra_Ven        
	AND ItensVenda.NumVend_Itv = Vendas.Num_Ven       

LEFT JOIN  (  
	SELECT     
		VLP.Empresa_vlp,    
		VLP.Obra_vlp,    
		VLP.NumVen_vlp,    
		SUM(VLP.NumParc_vlp) AS NumParc_vlp         
	FROM  UAU.dbo.VendasLogParc AS VLP       
	GROUP BY     
		VLP.Empresa_vlp,     
		VLP.Obra_vlp,    
		VLP.NumVen_vlp   

	UNION         

	SELECT    
		VRL.Empresa_vrl,    
		VRL.Obra_vrl,    
		VRL.NumVen_vrl,    
		SUM(VRL.NumParc_vrl) AS NumParc_vrl        
	FROM  UAU.dbo.VendRecLogParc AS VRL    
	GROUP BY    
		VRL.Empresa_vrl,    
		VRL.Obra_vrl,    
		VRL.NumVen_vrl     
) AS ParametrosVenda       
	ON ControleComissao.Empresa_Ctrc = ParametrosVenda.Empresa_Vlp       
	AND ControleComissao.Obra_Ctrc = ParametrosVenda.Obra_Vlp        
	AND ControleComissao.NumVend_Ctrc = ParametrosVenda.NumVen_Vlp       

INNER JOIN UAU.dbo.Empresas       
	ON ControleComissao.Empresa_ctrc = Empresas.Codigo_emp      

INNER JOIN UAU.dbo.Obras   
	ON ControleComissao.Obra_ctrc = Obras.cod_obr       
	AND ControleComissao.Empresa_ctrc = Obras.Empresa_obr       

INNER JOIN UAU.dbo.Pessoas AS Cliente    
	ON Vendas.Cliente_Ven = Cliente.cod_pes      

INNER JOIN UAU.dbo.Pessoas AS Corretor       
	ON ControleComissao.CodPes_ctrc = Corretor.cod_pes       

LEFT OUTER JOIN UAU.dbo.UnidadePer   
	ON ItensVenda.Empresa_itv = UnidadePer.Empresa_unid       
	AND ItensVenda.Produto_Itv = UnidadePer.Prod_unid       
	AND ItensVenda.CodPerson_Itv = UnidadePer.NumPer_unid      

WHERE (ItensVenda.PorcentComissao_itv <> 0)       

GROUP BY   
	ControleComissao.Empresa_Ctrc,   
	Empresas.Desc_Emp,   
	ControleComissao.Obra_Ctrc,   
	Obras.Descr_Obr,   
	ControleComissao.NumVend_Ctrc,   
	Vendas.Data_Ven,   
	Cargos.Descr_Cad,   
	ControleComissao.CodPes_Ctrc,   
	Corretor.Nome_Pes,   
	Vendas.ValorTot_Ven,       
	ItensVenda.PorcentComissao_Itv,   
	ItensVenda.PrecoProc_Itv,   
	ItensVenda.Qtde_Itv,   
	ControleComissao.Status_Ctrc,   
	Cliente.Nome_Pes,   
	UnidadePer.Identificador_Unid,  
	UnidadePer.C1_Unid,   
	UnidadePer.C2_Unid,   
	ControleComissao.ValComissao_Ctrc,       
	ControleComissao.ValAcrescimo_Ctrc,   
	ControleComissao.ValDesconto_Ctrc,   
	ControleComissao.PgtoDireto_Ctrc,   
	ControleComissao.NumComissao_ctrc,   
	ItensVenda.PorcentItem_itv    

--ORDER BY   
--	ControleComissao.Empresa_ctrc,   
--	ControleComissao.CodPes_Ctrc,   
--	ControleComissao.Obra_ctrc,   
--	Vendas.Data_Ven     

) AS V

--WHERE
----V.TipoPgto = '0 - DIRETO'
----AND V.Obra_Ctrc LIKE '%I' AND
--V.Data_Ven >= DATEADD(DAY,1,EOMONTH(GETDATE(),-MONTH(GETDATE())))

GROUP BY 
	V.Empresa_Ctrc,       
	V.Obra_Ctrc,       
	V.NumVend_ctrc,       
	V.Data_Ven,        
	V.Identificador_unid,       
	V.TipoPgto,   
	V.StatusCom,
	V.CodPes_Ctrc,       
	V.Corretor

)

go

