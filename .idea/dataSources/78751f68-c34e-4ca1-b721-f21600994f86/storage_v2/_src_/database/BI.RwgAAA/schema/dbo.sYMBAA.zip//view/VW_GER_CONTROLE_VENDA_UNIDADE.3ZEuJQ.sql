






CREATE VIEW [dbo].[VW_GER_CONTROLE_VENDA_UNIDADE] AS

WITH BASE AS (
	SELECT DISTINCT 
		CONCAT(CAST(ItensVenda.Empresa_itv AS varchar),'-',CAST(ItensVenda.Obra_Itv AS varchar), '-',CAST(ItensVenda.NumVend_Itv AS varchar)) AS Chave,  
		ItensVenda.Empresa_itv,    
		ItensVenda.Obra_Itv,    
		ItensVenda.NumVend_Itv,    
		ItensVenda.Produto_Itv,    
		ItensVenda.CodPerson_Itv,
		UnidadePer.Identificador_unid 
	FROM (  
		SELECT DISTINCT     
			Empresa_itv AS Empresa_itv,    
			Obra_Itv AS Obra_Itv,    
			NumVend_Itv AS NumVend_Itv,    
			Produto_Itv AS Produto_Itv,    
			CodPerson_Itv AS CodPerson_Itv  
		FROM UAU.dbo.ItensVenda 

		UNION     

		SELECT DISTINCT     
			Empresa_itr AS Empresa_itv,    
			Obra_Itr AS Obra_Itv,  
			 NumVend_Itr AS NumVend_Itv,    
			 Produto_Itr AS Produto_Itv,    
			 CodPerson_Itr AS CodPerson_Itv 
		FROM   UAU.dbo.ItensRecebidas 
	) AS ItensVenda   

	LEFT JOIN UAU.dbo.UnidadePer   
		ON  UnidadePer.Empresa_unid = ItensVenda.Empresa_itv       
		AND UnidadePer.Prod_unid    = ItensVenda.Produto_Itv       
		AND UnidadePer.NumPer_unid  = ItensVenda.CodPerson_Itv   

--	WHERE NOT (UnidadePer.Identificador_unid = '' OR UnidadePer.Identificador_unid IS NULL)      
)   


--select top 5 base_ven.* from (
SELECT DISTINCT    
	--CONCAT(CAST(V.Empresa_ven AS varchar),'-',CAST(V.Obra_Ven AS varchar), '-',CAST(V.Num_Ven AS varchar)) AS CHAVE_BASE,   
	CONCAT(CAST(V.Empresa_ven AS varchar),'-',CAST(V.Obra_Ven AS varchar)) AS CHAVE,   
	CONCAT(CAST(V.Empresa_ven AS varchar),'-',CAST(V.Obra_Ven AS varchar),'-',CAST(V.Num_Ven AS varchar)) AS CHAVE_VENDA,   
	CONCAT(CAST(V.Empresa_ven AS varchar) , '-' , CAST(V.Obra_Ven AS varchar) , '-' , CAST(V.Produto_Itv AS varchar)) AS CHAVE_PROD,   
	CONCAT(CAST(V.Empresa_ven AS varchar) , '-' , CAST(V.Obra_Ven AS varchar) , '-' , UP.Identificador_unid) AS ChaveUnid,   
	V.Empresa_ven,   
	V.Obra_Ven,   
	V.Num_Ven,   
	V.Vendedor_Ven,   
	V.Cliente_Ven,   
	V.ValorTot_Ven,   
	V.Acrescimo_Ven,   
	V.Desconto_Ven,   
	V.Data_Ven,   
	V.DataCessao_Ven,  
	V.DataCancel_Ven, 
    VendaDistrato.DataAssinatura_vdd AS DataAssinatura_Distrato,
	V.DataCad_Ven,	
	V.Produto_Itv,   
	PS.Descricao_psc AS NomeProduto,   
	V.CodPerson_Itv,   
	UP.FracaoIdeal_unid,   
	UP.Identificador_unid,   
	UP.Qtde_unid,   
	V.Status_Ven,                           
	CASE    
		WHEN UP.Vendido_unid = 0 THEN 'Disponível'    
		WHEN UP.Vendido_unid = 1 THEN     
			(CASE WHEN UD.TipoContrato_udt IN (1, 2, 5) THEN 'Locada' ELSE 'Vendida' END)    
		WHEN UP.Vendido_unid = 2 THEN 'Reservado'    
		WHEN UP.Vendido_unid = 3 THEN 'Proposta'    
		WHEN UP.Vendido_unid = 4 THEN 'Quitado'    
		WHEN UP.Vendido_unid = 5 THEN 'Escriturado'    
		WHEN UP.Vendido_unid = 6 THEN 'Em venda'    
		WHEN UP.Vendido_unid = 7 THEN 'Suspenso'    
		WHEN UP.Vendido_unid = 8 THEN 'Fora de venda'    
		WHEN UP.Vendido_unid = 9 THEN 'Em acerto'    
		WHEN UP.Vendido_unid = 10 THEN 'Dação' END AS Status_Unid,   
	V.Status_Venda,   
	V.ValProvisaoCurto_Ven,   
	V.ValProvisaoLongo_Ven,  
	V.ValProvisaoCurtoBaixa_ven,   
	V.ValProvisaoLongoBaixa_ven,  
	V.ValProvisaoCurtoCessao_ven,   
	V.ValProvisaoLongoCessao_ven,   
	UP.CodTipProd_unid,  
	V.PrecoProc_Itv,  
	V.ValComissaoDir,  
	B.Identificador_unid AS ConcatIdentificador_unid,  
    V.Juros_Ven,
    V.Multa_Ven
FROM (   
	SELECT    
        Juros_Ven AS Juros_Ven,
        Multa_Ven AS Multa_Ven,	
		ItensVenda.Produto_Itv AS Produto_Itv,    
		ItensVenda.CodPerson_Itv AS CodPerson_Itv,    
		Vendas.Empresa_ven AS Empresa_ven,    
		Vendas.Obra_Ven AS Obra_Ven,    
		Vendas.Num_Ven AS Num_Ven,    
		Vendas.Vendedor_Ven AS Vendedor_Ven,    
		Vendas.Cliente_Ven AS Cliente_Ven,    
		Vendas.ValorTot_Ven AS ValorTot_Ven,    
		Vendas.Desconto_Ven AS Desconto_Ven,    
		Vendas.Data_Ven AS Data_Ven,    
		Vendas.Status_Ven AS Status_Ven,    
		Vendas.Acrescimo_Ven AS Acrescimo_Ven,    
		Vendas.VlrLiberarCorretor_Ven AS VlrLiberarCorretor_Ven,    
		Vendas.DataCessao_Ven AS DataCessao_Ven,    
		Vendas.DataCancel_Ven AS DataCancel_Ven, 
-- data de cadastro
		Vendas.DataCad_Ven  AS DataCad_Ven,
		Vendas.User_Ven AS User_Ven,    
		Vendas.VlrCorretagem_Ven AS VlrCorretagem_Ven,    
		Vendas.TipoVenda_Ven AS TipoVenda_Ven,   
		CASE    
			WHEN Vendas.Status_Ven = 0 THEN '0 - Normal'     
			WHEN Vendas.Status_Ven = 1 THEN '1 - Cancelada'     
			WHEN Vendas.Status_Ven = 2 THEN '2 - Alterada'     
			WHEN Vendas.Status_Ven = 3 THEN '3 - Quitado'     
			WHEN Vendas.Status_Ven = 4 THEN '4 - Em Acerto' END AS Status_Venda,    
		Vendas.ValProvisaoCurto_Ven AS ValProvisaoCurto_Ven,   
		Vendas.ValProvisaoLongo_Ven AS ValProvisaoLongo_Ven,    
		Vendas.ValProvisaoCurtoBaixa_ven AS ValProvisaoCurtoBaixa_ven,    
		Vendas.ValProvisaoLongoBaixa_ven AS ValProvisaoLongoBaixa_ven,    
		Vendas.ValProvisaoCurtoCessao_ven AS ValProvisaoCurtoCessao_ven,    
		Vendas.ValProvisaoLongoCessao_ven AS ValProvisaoLongoCessao_ven,                            
		ItensVenda.PrecoProc_Itv AS PrecoProc_Itv,   
		ItensVenda.ValComissaoDir_Itv AS ValComissaoDir   

	FROM UAU.dbo.ItensVenda AS ItensVenda  

	INNER JOIN UAU.dbo.Vendas AS Vendas   
		ON ItensVenda.Obra_Itv = Vendas.Obra_Ven    
		AND ItensVenda.NumVend_Itv = Vendas.Num_Ven    
		AND ItensVenda.Empresa_itv = Vendas.Empresa_ven   

	UNION         

	SELECT 
        Juros_VRec AS Juros_Ven,
        Multa_VRec AS Multa_Ven,		
		ItensRecebidas.Produto_Itr AS Produto_Itr,        
		ItensRecebidas.CodPerson_Itr AS CodPerson_Itr,        
		VendasRecebidas.Empresa_vrec AS Empresa_vrec,        
		VendasRecebidas.Obra_VRec AS Obra_VRec,        
		VendasRecebidas.Num_VRec AS Num_VRec,        
		VendasRecebidas.Vendedor_VRec AS Vendedor_VRec,        
		VendasRecebidas.Cliente_VRec AS Cliente_VRec,        
		VendasRecebidas.ValorTot_VRec AS ValorTot_VRec,        
		VendasRecebidas.Desconto_VRec AS Desconto_VRec,        
		VendasRecebidas.Data_VRec AS Data_VRec,        
		VendasRecebidas.Status_VRec AS Status_VRec,        
		VendasRecebidas.Acrescimo_VRec AS Acrescimo_VRec,        
		VendasRecebidas.VlrLiberarCorretor_VRec AS VlrLiberarCorretor_VRec,        
		VendasRecebidas.DataCessao_Vrec AS DataCessao_Vrec,        
		VendasRecebidas.DataCancel_Vrec AS DataCancel_Vrec,
		VendasRecebidas.DataCad_Vrec AS DataCad_Vrec,
		VendasRecebidas.User_VRec AS User_VRec,       
		VendasRecebidas.VlrCorretagem_VRec AS VlrCorretagem_VRec,        
		VendasRecebidas.TipoVenda_VRec AS TipoVenda_VRec,       
		CASE          
			WHEN VendasRecebidas.Status_VRec = 0 THEN '0 - Normal'         
			WHEN VendasRecebidas.Status_VRec = 1 THEN '1 - Cancelada'         
			WHEN VendasRecebidas.Status_VRec = 2 THEN '2 - Alterada'         
			WHEN VendasRecebidas.Status_VRec = 3 THEN '3 - Quitado'         
			WHEN VendasRecebidas.Status_VRec = 4 THEN '4 - Em Acerto' END AS Status_Venda,       
		VendasRecebidas.ValProvisaoCurto_Vrec AS ValProvisaoCurto_Vrec,       
		VendasRecebidas.ValProvisaoLongo_VRec AS ValProvisaoLongo_VRec,       
		VendasRecebidas.ValProvisaoCurtoBaixa_vrec AS ValProvisaoCurtoBaixa_vrec,       
		VendasRecebidas.ValProvisaoLongoBaixa_vrec AS ValProvisaoLongoBaixa_vrec,        
		VendasRecebidas.ValProvisaoCurtoCessao_vrec AS ValProvisaoCurtoCessao_vrec,       
		VendasRecebidas.ValProvisaoLongoCessao_vrec AS ValProvisaoLongoCessao_vrec,       
		ItensRecebidas.PrecoProc_Itr AS PrecoProc_Itr,       
		ItensRecebidas.ValComissaoDir_itr as ValComissaoDir       

	FROM UAU.dbo.ItensRecebidas AS ItensRecebidas      

	INNER JOIN UAU.dbo.VendasRecebidas AS VendasRecebidas       
		ON ItensRecebidas.Obra_Itr = VendasRecebidas.Obra_VRec        
		AND ItensRecebidas.NumVend_Itr = VendasRecebidas.Num_VRec        
		AND ItensRecebidas.Empresa_itr = VendasRecebidas.Empresa_vrec   

) AS V   

LEFT OUTER JOIN  UAU.dbo.UnidadePer AS UP   
	ON V.Empresa_ven = UP.Empresa_unid   
	AND V.Obra_Ven = UP.Obra_unid   
	AND V.Produto_Itv = UP.Prod_unid  
	AND V.CodPerson_Itv = UP.NumPer_unid   

LEFT OUTER JOIN  UAU.dbo.UnidadeDetalhe AS UD   
	ON UD.Empresa_udt = UP.Empresa_unid   
	AND UD.Prod_udt = UP.Prod_unid  
	AND UD.NumPer_udt = UP.NumPer_unid   

INNER JOIN UAU.dbo.PrdSrv AS PS  
	ON PS.NumProd_psc = V.Produto_Itv  

INNER JOIN BASE AS B  
	ON B.Chave = CONCAT(CAST(V.Empresa_ven AS varchar),'-',CAST(V.Obra_Ven AS varchar), '-',CAST(V.Num_Ven AS varchar))  

LEFT JOIN UAU.dbo.VendaDistrato
		ON VendaDistrato.Empresa_vdd = V.Empresa_ven
			AND VendaDistrato.NumVend_vdd = V.Num_Ven
			AND VendaDistrato.Obra_vdd = V.Obra_Ven

--WHERE v.Obra_Ven LIKE ('%E') 
--WHERE UP.Obra_unid LIKE ('%I') 
--AND  V.Produto_Itv NOT IN (3,36,106) 
--AND V.Empresa_ven NOT IN (9,19) 

--AND V.Num_Ven  IN (7)
--AND V.Empresa_ven  IN (52) 
--) as base_ven


--WHERE (DATEDIFF(DAY, base_ven.DataCad_Ven, GETDATE()) <= 1) AND (base_ven.Produto_Itv IN (68, 66,3,61,58))
go

