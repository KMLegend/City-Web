

 

CREATE VIEW [dbo].[VW_GER_CONTROLE_RH_GESTOR_FOLHA] AS 
WITH PROVENTOS AS (
SELECT
EventosCad.NumCapRH, 
EventosCad.CodProvDesc, 
EventosCad.CredDeb, 
EventosCad.Valor, 
EventosCad.Qtde, 
EventosCad.DataFolha 
FROM (
	SELECT		
		NumCapRH_Pdc AS NumCapRH, 
		CodProvDesc_Pdc AS CodProvDesc, 
		CredDeb_Pdc AS CredDeb, 
		Valor_Pdc AS Valor, 
		Qtde_Pdc AS Qtde, 
		DataFolha_Pdc AS DataFolha
	FROM UAU.dbo.ProvDescCalc 
	--WHERE		DataFolha_Pdc BETWEEN <DataInicio> AND <DataTermino> 
				
	UNION 
				
	SELECT		
		NumCapRH_PdcM AS NumCapRH, 
		CodProvDesc_PdcM AS CodProvDesc,
		CredDeb_PdcM AS CredDeb,
		Valor_PdcM AS Valor, 
		Qtde_PdcM AS Qtde, 
		DataFolha_PdcM  AS DataFolha
	FROM UAU.dbo.ProvDescCalcMes 
	--WHERE		DataFolha_PdcM BETWEEN <DataInicio> AND <DataTermino> 
				
	UNION 
				
	SELECT		
		NumCapRh_PdFer AS NumCapRH, 
		CodProvDesc_PdFer AS CodProvDesc,
		CredDeb_PdFer AS CredDeb, 
		Valor_PdFer AS Valor, 
		Qtde_PdFer AS Qtde,  
		DataFolha_PdFer  AS DataFolha
	FROM UAU.dbo.ProvDescFerias 
	--WHERE		DataFolha_PdFer BETWEEN <DataInicio> AND <DataTermino> 
				
	UNION 
				
	SELECT		
		NumCapRH_PdRes AS NumCapRH, 
		CodProvDesc_PdRes AS CodProvDesc, 
		CredDeb_PdRes AS CredDeb,
		Valor_PdRes AS Valor, 
		Qtde_PdRes AS Qtde, 
		ISNULL(DataPgto_PdRes, DataPgto_Res) [DataPgto_PdRes]  --AS DataFolha
	FROM UAU.dbo.VwRescisao 
	INNER JOIN UAU.dbo.ProvDescRescisao 
		ON NumCapRH_Res = NumCapRH_PdRes 
		AND Num_Res = NumRes_PdRes 
	--WHERE		ISNULL(DataPgto_PdRes, DataPgto_Res) BETWEEN <DataInicio> AND <DataTermino> 
				
	UNION 
				
	SELECT		
		NumCapRH_PdDTer AS NumCapRH, 
		CodProvDesc_PdDTer AS CodProvDesc,
		CredDeb_PdDTer AS CredDeb,
		Valor_PdDTer AS Valor, 
		Qtde_PdDTer AS Qtde, 
		DataFolha_PdDTer AS DataFolha 
	FROM UAU.dbo.ProvDescDTer 
	--WHERE		DataFolha_PdDTer BETWEEN <DataInicio> AND <DataTermino> 
				
	UNION 
				
	SELECT		
		NumCapRH_PdAdQ AS NumCapRH, 
		CodProvDesc_PdAdQ AS CodProvDesc,
		CASE CredDeb_PdAdQ 
			WHEN 'P' THEN 'C' 
			ELSE CredDeb_PdAdQ 
		END AS CredDeb,
		Valor_PdAdQ AS Valor, 
		Qtde_PdAdQ AS Qtde, 
		DataFolha_PdAdQ AS DataFolha 
	FROM UAU.dbo.ProvDescAdiantQuinz 
	--WHERE		DataFolha_PdAdQ BETWEEN <DataInicio> AND <DataTermino> 

) AS EventosCad
),
RH AS (
SELECT 
	calc.DataFolha_Cal
	,calc.EmpresaProc_Cal
	,calc.ObraProc_Cal
	,rh.CodPes_CapRH
	,rh.Empresa_CapRH
	,rh.Obra_CapRH

FROM UAU.dbo.Calculo AS calc

LEFT JOIN UAU.dbo.CapacitacaoRH AS rh
    ON rh.Num_CapRH = calc.NumCapRH_Cal
)


SELECT		
	CAP.CodPes_CapRH AS CodPes_CapRH, 
	UPPER(P.Nome_Pes) AS Nome_Pes, 
	CAP.MatFunc_CapRH AS MatFunc_CapRH, 
	SF.Descricao_SitF AS Descricao_SitF, 
	CAP.Empresa_CapRH AS Empresa_CapRH, 
	CAP.Obra_CapRH AS Obra_CapRH, 
	UPPER(E.Desc_Emp) AS Desc_Emp, 
	UPPER(O.Descr_Obr) AS Descr_Obr, 
	E.CGC_Emp AS CGC_Emp, 
	PR.CodProvDesc AS CodProvDesc_Pdc, 
	UPPER(PD.Descricao_PD) AS Descricao_PD, 
	PR.CredDeb AS CredDeb_Pdc, 
	--PR.Valor AS Valor_Pdc, 
	--CHARINDEX ('.', PR.Valor, 0),
	--SUBSTRING(CAST(PR.Valor AS VARCHAR),0,(CHARINDEX ('.', PR.Valor, 0))) AS Salario_A,
	--SUBSTRING(CAST(PR.Valor AS VARCHAR),(CHARINDEX ('.', PR.Valor, 0))+1,2) AS Salario_B,
	CONCAT(SUBSTRING(CAST(PR.Valor AS VARCHAR),0,(CHARINDEX ('.', PR.Valor, 0))),',',SUBSTRING(CAST(PR.Valor AS VARCHAR),(CHARINDEX ('.', PR.Valor, 0))+1,2)) AS Valor_Pdc,
	PR.Qtde AS Qtde_Pdc, 
	PR.DataFolha AS DataFolha_Pdc, 
	--CAST(<DataInicio> AS DATETIME) [DataInicial], 
	--CAST(<DataTermino> AS DATETIME) [DataFinal], 
	CAST(CAST(YEAR(PR.DataFolha) AS VARCHAR) + '-' + CAST(MONTH(PR.DataFolha) AS VARCHAR) + '-01' AS DATETIME) AS MesFolha,
	MONTH(CAST(CAST(YEAR(PR.DataFolha) AS VARCHAR) + '-' + CAST(MONTH(PR.DataFolha) AS VARCHAR) + '-01' AS DATETIME)) AS Folha_Mes,
	YEAR(CAST(CAST(YEAR(PR.DataFolha) AS VARCHAR) + '-' + CAST(MONTH(PR.DataFolha) AS VARCHAR) + '-01' AS DATETIME)) AS Folha_Ano,
	RH.Empresa_CapRH AS [Calculo - RH.Empresa_CapRH],
	RH.EmpresaProc_Cal AS [Calculo - RH.EmpresaProc_Cal],
	RH.Obra_CapRH AS [Calculo - RH.Obra_CapRH],
	RH.ObraProc_Cal AS [Calculo - RH.ObraProc_Cal]

FROM UAU.dbo.CapacitacaoRH AS CAP

INNER JOIN UAU.dbo.Pessoas AS P
	ON COALESCE(CAP.CodPes_CapRH,'') = COALESCE(P.Cod_Pes,'')
LEFT JOIN UAU.dbo.SituacaoFunc AS SF
	ON COALESCE(SF.Codigo_SitF,'') = COALESCE(CAP.CodSitF_CapRH,'') 
INNER JOIN UAU.dbo.Empresas AS E
	ON COALESCE(CAP.Empresa_CapRH,'') = COALESCE(E.Codigo_Emp,'')
INNER JOIN PROVENTOS AS PR
	ON COALESCE(CAP.Num_CapRH,'') = COALESCE(PR.NumCapRh,'') 
INNER JOIN UAU.dbo.Obras AS O
	ON COALESCE(CAP.Empresa_CapRH,'') = COALESCE(O.Empresa_Obr,'') 
	AND COALESCE(CAP.Obra_CapRH,'') = COALESCE(O.Cod_Obr,'') 
LEFT JOIN UAU.dbo.ProvDesc AS PD
	ON COALESCE(PD.CodProvDesc_Pd,'') = COALESCE(PR.CodProvDesc,'')
LEFT JOIN RH AS RH
	ON COALESCE(PR.DataFolha,'') = COALESCE(RH.DataFolha_Cal,'')
	AND COALESCE(CAP.CodPes_CapRH,'') = COALESCE(RH.CodPes_CapRH,'')
	AND COALESCE(CAP.Empresa_CapRH,'') = COALESCE(RH.Empresa_CapRH,'')
	AND COALESCE(CAP.Obra_CapRH,'') = COALESCE(RH.Obra_CapRH,'')

--WHERE CAP.Empresa_CapRH IN (4,62,91)


--ORDER BY	Empresa_CapRH, Obra_CapRH, DataFolha_Pdc, CodPes_CapRH, Descricao_Pd	
go

