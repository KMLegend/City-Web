

CREATE VIEW [dbo].[VW_GER_CONTROLE_EMP_OBRA] AS 

SELECT DISTINCT 
	upper(e.Codigo_emp) as Codigo_emp,
	upper(e.Desc_emp) as Desc_emp,
	upper(o.cod_obr) as cod_obr,
	upper(o.descr_obr) as descr_obr,
	concat(upper(e.Codigo_emp),' | ',upper(e.Desc_emp),' | ',upper(o.cod_obr),' | ',upper(o.descr_obr)) as Name


FROM UAU.dbo.Obras as o 
full join UAU.dbo.empresas as e
on  coalesce(e.Codigo_emp,'') =  coalesce(o.Empresa_obr,'')
--order by 1

go

