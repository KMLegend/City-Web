
CREATE VIEW [dbo].[VW_GER_CONTROLE_CESSAO_DIREITO] AS 

SELECT * 
FROM UAU.dbo.VendaHist 
WHERE numnovavend_vhist is not null 
AND Obra_vhist like '%I'

go

