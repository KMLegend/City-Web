
CREATE VIEW [dbo].[VW_GER_CARTEIRA_CONTA_RECEBIDAS] AS (

SELECT BASE.*
FROM (
SELECT 
	[CODEMP] -- codigo da empresa 
	,[EMPRESA]
	,[OBRA_RPD] AS COD_OBR -- codigo da obra
	,[OBRA]
	,[IDENTIFICADOR_UNID]
	,[NUM_VEN] AS COD_VENDA -- codigo do contrato de venda
	,[COD_CLIENTE] AS COD_CLIENTE -- codigo da cliente
	,[CLIENTE]
	,NULL AS DATA_NEGOCIACAO -- data de negociação
	,[DATA VENCIMENTO] AS DATA_VENCIMENTO -- data vencimento
	,NULL AS DATA_PAGAMENTO --[DATA_PAGAMENTO]
	,[TIPO] -- tipo_rec (descricao de tipo exemplo: Renegociacao)
	,'CONTA EM ABERTO' AS [STATUS]
	,[NUM PARC] AS NUM_PARCELA --qual de parcela
	,[NUM PARC GERAL] AS NUM_PARCELA_GERAL  --total de parcela
	,[DIAS EM ABERTO]-- calcula tempo da fatura em aberto
	,CAST([VLR PRINCIPAL]AS FLOAT) AS VALOR_PRINCIPAL  -- valor principal

 FROM [BI].[dbo].[TB_GER_CONTROLE_CONTA_A_RECEBER]
-- WHERE [CODEMP] = '10'
--AND [EMPRESA] = 'SPE CITY 03 OM PRAÇA DO SOL EMPREENDIMENTOS LTDA'
--AND IDENTIFICADOR_UNID LIKE '2402%'
----AND [NUM_VEN] = '132'

UNION ALL

 SELECT 
	[CODEMP] -- codigo da empresa 
	,[EMPRESA]
	,[OBRA_RPD] AS COD_OBR -- codigo da obra
	,[OBRA]
	,[IDENTIFICADOR_UNID]
	,[VENDA] AS COD_VENDA -- codigo do contrato de venda
	,[CLIENTE_REC] AS COD_CLIENTE -- codigo da cliente
	,[CLIENTE]
	,[DATACONCIL] AS DATA_NEGOCIACAO -- data de negociação
	,[DATA VENCIMENTO] AS DATA_VENCIMENTO -- data vencimento
	,[DATADEP_RPG] AS DATA_PAGAMENTO --[DATA_PAGAMENTO]
	,[TIPO] -- tipo_rec (descricao de tipo exemplo: Renegociacao)
	,'CONTA PAGA' AS [STATUS]
	,[PARCELARECEBIDA] AS NUM_PARCELA --qual de parcela
	,[NUMPARCGER_REC] AS NUM_PARCELA_GERAL  --total de parcela
	,0 AS [DIAS EM ABERTO]-- calcula tempo da fatura em aberto
	,CAST([VALORPRINCIPALPRICE_REC]AS FLOAT) AS VALOR_PRINCIPAL  -- valor principal

FROM [BI].[dbo].[TB_GER_CONTROLE_CONTA_RECEBIDAS]
--WHERE CODEMP = '10'
--AND EMPRESA = 'SPE CITY 03 OM PRAÇA DO SOL EMPREENDIMENTOS LTDA'
--AND IDENTIFICADOR_UNID LIKE '2402%'
--AND [VENDA] = '132'
) AS BASE

--ORDER BY 1,2,3,4,5,6,7
)
go

