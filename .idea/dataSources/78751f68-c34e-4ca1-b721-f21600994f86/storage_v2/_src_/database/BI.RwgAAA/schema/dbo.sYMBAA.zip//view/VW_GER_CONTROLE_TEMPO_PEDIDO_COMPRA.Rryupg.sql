



CREATE VIEW [dbo].[VW_GER_CONTROLE_TEMPO_PEDIDO_COMPRA] AS

--Este relatório traz a média de compra baseado na diferença entre a data de aprovação do pedido e o fechamento da compra (Geração da Ordem de Compra), 
--com esse relatório é possível saber quanto tempo que o departamento de compra está levando para realizar a compra.
/* Variaveis:

Cotado - 0 para mostrar todos pedidos ou 1 para mostrar apenas cotados. -- numerico
DataInicio - Data de Início - Aprovação de pedido (confirmação do insumo, `sim`, na tela de seleção de insumos e fornecedores).   -- date
DataTermino - Data de término - Aprovação de pedido (confirmação do fornecedores).   -- date
EmpresaObra - Empresa(s) e Obra(s)  -- numerico
*/

SELECT		
	--CAST(<DataInicio> AS DATETIME) [DataInicial], 
	--CAST(<DataTermino> AS DATETIME) [DataFinal], 
	Resultado.*, 
	UPPER(Desc_Emp) [Empresa], 
	UPPER(Descr_Obr) [Obra], 
	UPPER 
	( 
		CASE Tipo 
			WHEN 'MATERIAL' THEN Descr_Ins 
			WHEN 'SERVIÇO' THEN Descr_Comp 
		END 
	) [Insumo], 
	MAX(DocFiscal_Proc) [NotaFiscal], 
	MAX(Data_Nfp) [DataNota] 
FROM 
( 
			SELECT		ItensCot_Temp.Empresa_Temp [CodEmp], 
						ItensCot_Temp.Obra_Temp [CodObra], 
						NumPedido_Temp [Pedido], 
						COALESCE(ItensCot_Temp.Cotacao_Temp, 0) [Cotação], 
						ItensCot_Temp.Insumo_Temp [CodIns], 
						COALESCE(Aprovacao.DataConf_Temp, ItensCot_Temp.DataConf_Temp) [Data do Pedido], 
						COALESCE(Aprovacao.QuemConf_Temp, ItensCot_Temp.QuemConf_Temp) [UsrAprovPedido], 
						Cotacao.Numero_OC [O.C], 
						Cotacao.Obs_OC [Obs], 
						ItensCot_Temp.Unid_temp [Unidade], 
						ItensCot_temp.QtdeCot_temp [Qtde], 
						Cotacao.Preco_OC [PrecoUnitario], 
						(ItensCot_temp.QtdeCot_temp * Cotacao.Preco_OC) [ValorTotal],
						DATEDIFF(DAY, COALESCE(Aprovacao.DataConf_Temp, ItensCot_Temp.DataConf_Temp), Cotacao.DataGer_OC) [DtAprovPed-DataCompra], 
						DATEDIFF(DAY, COALESCE(Aprovacao.DataConf_Temp, ItensCot_Temp.DataConf_Temp), Cotacao.DtAtividade_OC) [DtAprovPed-DtEntrega], 
						Cotacao.DataGer_OC [DataCompra], 
						Cotacao.Usuario_OC [UsuarioCompra], 
						Cotacao.DtAtividade_OC [DataEntrega], 
						ItensCot_Temp.DtEntrega_Temp [DataEntregaPed], 
						'MATERIAL' [Tipo], 
						CASE WHEN ItensCot_Temp.Excluido_Temp = 0 
							THEN '0 - NÃO' 
							ELSE '1 - SIM' 
						END [Excluído], 
						DATEDIFF(DAY, Pedidos.DtPedido_Ped, Cotacao.DataGer_OC) [DtCompra-DtPedido], 
						DATEDIFF(DAY, Cotacao.DataGer_OC, Cotacao.DtAtividade_OC) [DtCompra-DtEntrega], 
						DATEDIFF(DAY, Pedidos.DtPedido_Ped, Cotacao.DataGer_OC) + DATEDIFF(DAY, Cotacao.DataGer_OC, Cotacao.DtAtividade_OC) [Pedido-Entrega], 
						SimulacoesConf.Data_Sm [DataAprovSimulacao], 
						SimulacoesConfObra.Data_Smo [DataSimulacaoObra], 
						Pedidos.DtPedido_Ped [DataPedido], 
						UltPreco.Preco_Uoc [UltimoPreco] 
			FROM		UAU.dbo.ItensCot_Temp 
						INNER JOIN 
						( 
							SELECT		Empresa_ApPedM, 
										Obra_ApPedM, 
										Insumo_ApPedM, 
										NumPedido_ApPedM, 
										ItemPed_ApPedM, 
										MAX(DataAprov_ApPedM) [DataConf_Temp], 
										( 
											SELECT		MAX(APM.UsrAprov_ApPedM) 
											FROM		UAU.dbo.AprovacaoPedMat [APM] 
											WHERE		APM.Empresa_ApPedM = APM1.Empresa_ApPedM 
														AND APM.Obra_ApPedM = APM1.Obra_ApPedM 
														AND APM.Insumo_ApPedM = APM1.Insumo_ApPedM 
														AND APM.NumPedido_ApPedM = APM1.NumPedido_ApPedM 
														AND APM.ItemPed_ApPedM = APM1.ItemPed_ApPedM 
														AND APM.DataAprov_ApPedM = MAX(APM1.DataAprov_ApPedM) 
										) [QuemConf_Temp] 
							FROM		UAU.dbo.AprovacaoPedMat [APM1] 
							GROUP BY	Empresa_ApPedM, Obra_ApPedM, Insumo_ApPedM, NumPedido_ApPedM, ItemPed_ApPedM 
						) [Aprovacao] 
							ON Aprovacao.Empresa_ApPedM = ItensCot_Temp.Empresa_Temp 
							AND Aprovacao.Obra_ApPedM = ItensCot_Temp.Obra_Temp 
							AND Aprovacao.Insumo_ApPedM = ItensCot_Temp.Insumo_Temp 
							AND Aprovacao.NumPedido_ApPedM = ItensCot_Temp.NumPedido_Temp 
							AND Aprovacao.ItemPed_ApPedM = ItensCot_Temp.ItemPed_Temp 
						LEFT JOIN 
						( 
							SELECT		Empresa_Ocp [Empresa_OC], 
										NumCot_Ocp [NumCot_OC], 
										CodInsumo_Ioc [CodIns_OC], 
										MAX(NumeroOC_Ocp) [Numero_OC], 
										MAX(CAST(ObsInsumo_Ioc AS VARCHAR)) [Obs_OC], 
										MAX(Unidade_Ioc) [Unidade_OC], 
										SUM(Qtde_Ioc) [Qtde_OC], 
										MAX(Preco_Ioc) [Preco_OC], 
										SUM(Qtde_Ioc) * MAX(Preco_Ioc) [ValorTotal_OC], 
										MIN(DataGer_Ocp) [DataGer_OC], 
										MIN(DtAtividade_Hen) [DtAtividade_OC], 
										MIN(Usuario_Ocp) [Usuario_OC] 
							FROM		UAU.dbo.OrdemCompra 
										INNER JOIN UAU.dbo.ItensOrdemCompra 
											ON Empresa_Ocp = Empresa_Ioc 
											AND Obra_Ocp = Obra_Ioc 
											AND NumeroOC_Ocp = NumeroOC_Ioc 
										LEFT JOIN UAU.dbo.HistoricoEntrega 
											ON Empresa_Ocp = Empresa_Hen 
											AND Obra_Ocp = Obra_Hen 
											AND NumeroOC_Ocp = NumOC_Hen 
							GROUP BY	Empresa_Ocp, NumCot_Ocp, CodInsumo_Ioc 
						) [Cotacao] 
							ON Cotacao.Empresa_OC = ItensCot_Temp.Empresa_Temp 
							AND Cotacao.NumCot_OC = CASE WHEN ItensCot_Temp.Cotacao_Temp = 0 THEN -1 ELSE ItensCot_Temp.Cotacao_Temp END 
							AND Cotacao.CodIns_OC = ItensCot_Temp.Insumo_Temp 
						LEFT JOIN UAU.dbo.Pedidos 
							ON Pedidos.Empresa_Ped = ItensCot_Temp.Empresa_Temp 
							AND Pedidos.Obra_Ped = ItensCot_Temp.Obra_Temp 
							AND Pedidos.Cod_Ped = ItensCot_Temp.NumPedido_Temp 
						LEFT JOIN 
						( 
							SELECT		Empresa_Smlc [Empresa_Sm], 
										NumCot_Smlc [NumCot_Sm], 
										MIN(Data_Smlc) [Data_Sm] 
							FROM		UAU.dbo.SimulacoesConf 
							GROUP BY	Empresa_Smlc, NumCot_Smlc 
						) [SimulacoesConf] 
							ON SimulacoesConf.Empresa_Sm = ItensCot_Temp.Empresa_Temp 
							AND SimulacoesConf.NumCot_Sm = ItensCot_Temp.Cotacao_Temp 
						LEFT JOIN 
						( 
							SELECT		Empresa_Smlc [Empresa_Smo], 
										ObraCot_Smlc [Obra_Smo], 
										NumCot_Smlc [NumCot_Smo], 
										MIN(DataConf_Smlc) [Data_Smo] 
							FROM		UAU.dbo.SimulacoesConf 
							GROUP BY	Empresa_Smlc, ObraCot_Smlc, NumCot_Smlc 
						) [SimulacoesConfObra] 
							ON SimulacoesConfObra.Empresa_Smo = ItensCot_Temp.Empresa_Temp 
							AND SimulacoesConfObra.Obra_Smo = ItensCot_Temp.Obra_Temp 
							AND SimulacoesConfObra.NumCot_Smo = ItensCot_Temp.Cotacao_Temp 
						LEFT JOIN 
						( 
							SELECT		Empresa_Uoc, 
										CodInsumo_Uoc, 
										MIN(Preco_Ioc) [Preco_Uoc] 
							FROM		UAU.dbo.OrdemCompra 
										INNER JOIN UAU.dbo.ItensOrdemCompra 
											ON Empresa_Ioc = Empresa_Ocp 
											AND Obra_Ioc = Obra_Ocp 
											AND NumeroOC_Ioc = NumeroOC_Ocp 
										INNER JOIN 
										( 
											SELECT		Empresa_Ocp [Empresa_Uoc], 
														CodInsumo_Ioc [CodInsumo_Uoc], 
														MAX(DataGer_Ocp) [DataGer_Uoc] 
											FROM		UAU.dbo.OrdemCompra 
														INNER JOIN UAU.dbo.ItensOrdemCompra 
															ON Empresa_Ioc = Empresa_Ocp 
															AND Obra_Ioc = Obra_Ocp 
															AND NumeroOC_Ioc = NumeroOC_Ocp 
											GROUP BY	Empresa_Ocp, CodInsumo_Ioc 
										) [UltCompraIns] 
											ON Empresa_Uoc = Empresa_Ocp 
											AND CodInsumo_Uoc = CodInsumo_Ioc 
											AND DataGer_Uoc = DataGer_Ocp 
							GROUP BY	Empresa_Uoc, CodInsumo_Uoc 
						) [UltPreco] 
							ON UltPreco.Empresa_Uoc = ItensCot_Temp.Empresa_Temp 
							AND UltPreco.CodInsumo_Uoc = ItensCot_Temp.Insumo_Temp 
			WHERE		ItensCot_Temp.Confirmado_Temp = 1 
						--AND ItensCot_Temp.Obra_Temp in ('3401C')--,'5501C','4701C','7601C')
						--AND ItensCot_Temp.Empresa_Temp  = 34
						--AND CONVERT(DATETIME,CONVERT(VARCHAR(10), COALESCE(Aprovacao.DataConf_Temp, ItensCot_Temp.DataConf_Temp) , 103),103) 
						--BETWEEN <DataInicio> AND <DataTermino> 

			UNION 

			SELECT		ItensCotServ_Temp.Empresa_ServTemp [CodEmp], 
						ItensCotServ_Temp.Obra_ServTemp [CodObra], 
						ItensCotServ_Temp.NumPedido_ServTemp [Pedido], 
						COALESCE(ItensCotServ_Temp.Cotacao_ServTemp, 0) [Cotação], 
						ItensCotServ_Temp.Serv_ServTemp [CodIns], 
						COALESCE(Aprovacao.DataConf_ServTemp, ItensCotServ_Temp.DataConf_ServTemp) [Data do Pedido], 
						COALESCE(Aprovacao.QuemConf_ServTemp, ItensCotServ_Temp.QuemConf_ServTemp) [UsrAprovPedido], 
						0 [O.C], 
						CAST(ItensCotServ_Temp.Obs_ServTemp AS VARCHAR) [Obs], 
						ItensCotServ_Temp.Unid_ServTemp [Unidade], 
						ItensCotServ_Temp.QtdeCot_ServTemp [Qtde], 
						ItensCotServ_Temp.PrecoOrc_ServTemp [PrecoUnitario], 
						(ItensCotServ_Temp.QtdeCot_ServTemp * ItensCotServ_Temp.PrecoOrc_ServTemp) [ValorTotal],
						DATEDIFF(DAY, COALESCE(Aprovacao.DataConf_ServTemp, ItensCotServ_Temp.DataConf_ServTemp), 
									  COALESCE(( 
										SELECT		MIN(SimulacoesConf.Data_Smlc) 
										FROM		UAU.dbo.SimulacoesConf 
										WHERE		Empresa_Smlc = Empresa_ServTemp 
													AND NumCot_Smlc = Cotacao_ServTemp 
									  ),NULL) 
						) [DataCompra-DtAprovPed], 
						( 
							DATEDIFF(DAY, COALESCE(Aprovacao.DataConf_ServTemp, ItensCotServ_Temp.DataConf_ServTemp), 
										  COALESCE(( 
											SELECT		MIN(SimulacoesConf.Data_Smlc) 
											FROM		UAU.dbo.SimulacoesConf 
											WHERE		Empresa_Smlc = Empresa_ServTemp 
														AND NumCot_Smlc = Cotacao_ServTemp 
										  ),NULL)) + 
							DATEDIFF(DAY, COALESCE(( 
											SELECT		MIN(Data_Smlc) 
											FROM		UAU.dbo.SimulacoesConf 
											WHERE		Empresa_Smlc = Empresa_ServTemp 
														AND NumCot_Smlc = Cotacao_ServTemp 
										  ), NULL), 
										  COALESCE(( 
											SELECT		MIN(DtCriacao_Med) 
											FROM		UAU.dbo.ItensMedicao 
														INNER JOIN UAU.dbo.Medicoes 
															ON Empresa_Item = Empresa_Med 
															AND Contrato_Item = Contrato_Med 
															AND CodMed_Item = Cod_Med 
														INNER JOIN UAU.dbo.ItensContrato 
															INNER JOIN UAU.dbo.ItensContratoCotServ 
																ON Empresa_Itens = Empresa_ItCotServ 
																AND Contrato_Itens = Contrato_ItCotServ 
																AND Item_Itens = Item_ItCotServ 
															INNER JOIN UAU.dbo.ItensSimuladosConfServ 
																ON Empresa_SimcServ = Empresa_Itens 
																AND Cotacao_SimcServ = Cotacao_ItCotServ 
																AND CodForn_SimcServ = CodForn_ItCotServ 
																AND Serv_SimcServ = Serv_Itens 
															ON Empresa_Item = Empresa_Itens 
															AND Contrato_Item = Contrato_Itens 
															AND Ins_Item = Serv_Itens
															AND ItensCont_Item = Item_itens 
											WHERE		Empresa_Itens = Empresa_ServTemp 
														AND Cotacao_ItCotServ = Cotacao_ServTemp 
														AND Serv_Itens = Serv_ServTemp 
							), NULL)) 
						) [Pedido-Entrega], 
						COALESCE(( 
							SELECT		MIN(Data_Smlc) 
							FROM		UAU.dbo.SimulacoesConf 
							WHERE		Empresa_Smlc = Empresa_ServTemp 
										AND NumCot_Smlc = Cotacao_ServTemp 
						), NULL) [DataCompra], 
						( 
							SELECT		MAX(Quem_Ped) 
							FROM		UAU.dbo.Pedidos 
							WHERE		Empresa_Ped = Empresa_ServTemp 
										AND Obra_Ped = Obra_ServTemp 
										AND Cod_Ped = NumPedido_ServTemp 
						) [UsuarioCompra], 
						COALESCE(( 
							SELECT		MIN(DtCriacao_Med) 
							FROM		UAU.dbo.ItensMedicao 
										INNER JOIN UAU.dbo.Medicoes 
											ON Empresa_Item = Empresa_Med 
											AND Contrato_Item = Contrato_Med 
											AND CodMed_Item = Cod_Med 
										INNER JOIN UAU.dbo.ItensContrato 
											INNER JOIN UAU.dbo.ItensContratoCotServ 
												ON Empresa_Itens = Empresa_ItCotServ 
												AND Contrato_Itens = Contrato_ItCotServ 
												AND Item_Itens = Item_ItCotServ 
											INNER JOIN UAU.dbo.ItensSimuladosConfServ 
												ON Empresa_SimcServ = Empresa_Itens 
												AND Cotacao_SimcServ = Cotacao_ItCotServ 
												AND CodForn_SimcServ = CodForn_ItCotServ 
												AND Serv_SimcServ = Serv_Itens 
											ON Empresa_Item = Empresa_Itens 
											AND Contrato_Item = Contrato_Itens 
											AND Ins_Item = Serv_Itens
											AND ItensCont_Item = Item_itens 
							WHERE		Empresa_Itens = Empresa_ServTemp  
										AND Cotacao_ItCotServ = Cotacao_ServTemp 
										AND Serv_Itens = Serv_ServTemp 
						), NULL) [DataEntrega], 
						'' [DataEntregaPed], 
						'SERVIÇO' [Tipo], 
						CASE Excluido_ServTemp 
							WHEN 0 THEN '0 - NÃO' 
							ELSE '1 - SIM' 
						END [Excluído], 
						DATEDIFF(DAY, COALESCE(( 
										SELECT		MIN(DtPedido_Ped) 
										FROM		UAU.dbo.Pedidos 
										WHERE		Empresa_Ped = Empresa_ServTemp 
													AND Obra_Ped = Obra_ServTemp 
													AND Cod_Ped = NumPedido_ServTemp 
									  ), NULL), 
									  COALESCE(( 
										SELECT		MIN(Data_Smlc) 
										FROM		UAU.dbo.SimulacoesConf 
										WHERE		Empresa_Smlc = Empresa_ServTemp 
													AND NumCot_Smlc = Cotacao_ServTemp 
									  ), NULL)) [DtCompra-DtPedido], 
						DATEDIFF(DAY, COALESCE(( 
										SELECT		MIN(Data_Smlc) 
										FROM		UAU.dbo.SimulacoesConf 
										WHERE		Empresa_Smlc = Empresa_ServTemp 
													AND NumCot_Smlc = Cotacao_ServTemp 
									  ), NULL), 
									  COALESCE(( 
										SELECT		MIN(DtCriacao_Med) 
										FROM		UAU.dbo.ItensMedicao 
													INNER JOIN UAU.dbo.Medicoes 
														ON Empresa_Item = Empresa_Med 
														AND Contrato_Item = Contrato_Med 
														AND CodMed_Item = Cod_Med 
													INNER JOIN UAU.dbo.ItensContrato 
														INNER JOIN UAU.dbo.ItensContratoCotServ 
															ON Empresa_Itens = Empresa_ItCotServ 
															AND Contrato_Itens = Contrato_ItCotServ 
															AND Item_Itens = Item_ItCotServ 
														INNER JOIN UAU.dbo.ItensSimuladosConfServ 
															ON Empresa_SimcServ = Empresa_Itens 
															AND Cotacao_SimcServ = Cotacao_ItCotServ 
															AND CodForn_SimcServ = CodForn_ItCotServ 
															AND Serv_SimcServ = Serv_Itens 
														ON Empresa_Item = Empresa_Itens 
														AND Contrato_Item = Contrato_Itens 
														AND Ins_Item = Serv_Itens
														AND ItensCont_Item = Item_itens   
										WHERE		Empresa_Itens = Empresa_ServTemp 
													AND Cotacao_ItCotServ = Cotacao_ServTemp 
													AND Serv_Itens = Serv_ServTemp 
									  ), NULL)) [DtCompra-DtEntrega],	
						( 
							SELECT		DATEDIFF(DAY, COALESCE(( 
														SELECT		MIN(DtPedido_Ped) 
														FROM		UAU.dbo.Pedidos 
														WHERE		Empresa_Ped = Empresa_ServTemp 
																	AND Obra_Ped = Obra_ServTemp 
																	AND Cod_Ped = NumPedido_ServTemp 
													  ), NULL), 
													  COALESCE(( 
														SELECT		MIN(Data_Smlc) 
														FROM		UAU.dbo.SimulacoesConf 
														WHERE		Empresa_Smlc = Empresa_ServTemp 
																	AND NumCot_Smlc = Cotacao_ServTemp 
													  ), NULL)) + 
										DATEDIFF(DAY, COALESCE(( 
														SELECT		MIN(Data_Smlc) 
														FROM		UAU.dbo.SimulacoesConf 
														WHERE		Empresa_Smlc = Empresa_ServTemp 
																	AND NumCot_Smlc = Cotacao_ServTemp 
													  ), NULL), 
													  COALESCE(( 
														SELECT		MIN(DtCriacao_Med) 
														FROM		UAU.dbo.ItensMedicao 
																	INNER JOIN UAU.dbo.Medicoes 
																		ON Empresa_Item = Empresa_Med 
																		AND Contrato_Item = Contrato_Med 
																		AND CodMed_Item = Cod_Med 
																	INNER JOIN UAU.dbo.ItensContrato 
																					INNER JOIN UAU.dbo.ItensContratoCotServ 
																						ON Empresa_Itens = Empresa_ItCotServ 
																						AND Contrato_Itens = Contrato_ItCotServ 
																						AND Item_Itens = Item_ItCotServ 
																					INNER JOIN UAU.dbo.ItensSimuladosConfServ 
																						ON Empresa_SimcServ = Empresa_Itens 
																						AND Cotacao_SimcServ = Cotacao_ItCotServ 
																						AND CodForn_SimcServ = CodForn_ItCotServ 
																						AND Serv_SimcServ = Serv_Itens 
																					ON Empresa_Item = Empresa_Itens 
																					AND Contrato_Item = Contrato_Itens 
																					AND Ins_Item = Serv_Itens
																					AND ItensCont_Item = Item_itens 
																	WHERE		Empresa_Itens = Empresa_ServTemp 
																				AND Cotacao_ItCotServ = Cotacao_ServTemp 
																				AND Serv_Itens = Serv_ServTemp 
																), NULL))) [Pedido-Entrega], 
						COALESCE(( 
							SELECT		MIN(Data_Smlc) 
							FROM		UAU.dbo.SimulacoesConf 
							WHERE		Empresa_Smlc = Empresa_ServTemp 
										AND NumCot_Smlc = Cotacao_ServTemp 
						), NULL) [DataAprovSimulacao], 
						COALESCE(( 
							SELECT		MIN(DataConf_Smlc) 
							FROM		UAU.dbo.SimulacoesConf 
							WHERE		Empresa_Smlc = Empresa_ServTemp 
										AND NumCot_Smlc = Cotacao_ServTemp 
										AND ObraCot_Smlc = Obra_ServTemp 
						), NULL) [DataSimulacaoObra], 
						COALESCE(( 
							SELECT		MIN(DtPedido_Ped) 
							FROM		UAU.dbo.Pedidos 
							WHERE		Empresa_Ped = Empresa_ServTemp 
										AND Obra_Ped = Obra_ServTemp 
										AND Cod_Ped = NumPedido_ServTemp 
						), NULL) [DataPedido], 
						0 [UltimoPreco] 
			FROM		UAU.dbo.ItensCotServ_Temp 
						INNER JOIN 
						( 
							SELECT		Empresa_ApPedS, 
										Obra_ApPedS, 
										Serv_ApPedS, 
										NumPedido_ApPedS, 
										MAX(DataAprov_ApPedS) [DataConf_ServTemp], 
										( 
											SELECT		MAX(APM.UsrAprov_ApPedS) 
											FROM		UAU.dbo.AprovacaoPedServ [APM] 
											WHERE		APM.Empresa_ApPedS = APM1.Empresa_ApPedS 
														AND APM.Obra_ApPedS = APM1.Obra_ApPedS 
														AND APM.Serv_ApPedS = APM1.Serv_ApPedS 
														AND APM.NumPedido_ApPedS = APM1.NumPedido_ApPedS 
														AND APM.DataAprov_ApPedS = MAX(APM1.DataAprov_ApPedS) 
										) [QuemConf_ServTemp] 
							FROM		UAU.dbo.AprovacaoPedServ [APM1] 
							GROUP BY	Empresa_ApPedS, Obra_ApPedS, Serv_ApPedS, NumPedido_ApPedS 
						) [Aprovacao] 
							ON Aprovacao.Empresa_ApPedS = ItensCotServ_Temp.Empresa_ServTemp 
							AND Aprovacao.Obra_ApPedS = ItensCotServ_Temp.Obra_ServTemp 
							AND Aprovacao.Serv_ApPedS = ItensCotServ_Temp.Serv_ServTemp 
							AND Aprovacao.NumPedido_ApPedS = ItensCotServ_Temp.NumPedido_ServTemp 

			WHERE		ItensCotServ_Temp.Confirmado_ServTemp = 1 
						--AND ItensCotServ_Temp.Obra_ServTemp in ('3401C')--,'5501C','4701C','7601C')
						--AND ItensCotServ_Temp.Empresa_ServTemp = 34
						--AND CONVERT(DATETIME,CONVERT(VARCHAR(10), COALESCE(Aprovacao.DataConf_ServTemp, ItensCotServ_Temp.DataConf_ServTemp) , 103),103)  
						--BETWEEN <DataInicio> AND <DataTermino> 
) [Resultado] 
			INNER JOIN UAU.dbo.Empresas 
				ON Codigo_Emp = CodEmp 
			INNER JOIN UAU.dbo.Obras 
				ON Cod_Obr = CodObra 
				AND Empresa_Obr = CodEmp 
			LEFT JOIN UAU.dbo.InsumosGeral 
				ON Cod_Ins = CodIns 
			LEFT JOIN UAU.dbo.Composicoes 
				ON Cod_Comp = CodIns 
			LEFT JOIN 
			( 
				SELECT		* 
				FROM 
				( 
							SELECT		DISTINCT Dados_Proc.Empresa_Proc, 
										Dados_Proc.Obra_Proc, 
										Dados_Proc.NumCot_Proc, 
										Dados_Proc.OrdemCompra_Proc, 
										Dados_Proc.Num_Proc, 
										Parc_Proc.DocFiscal_Proc 
							FROM		UAU.dbo.Dados_Proc 
										INNER JOIN UAU.dbo.Parc_Proc 
											ON Parc_Proc.Empresa_Proc = Dados_Proc.Empresa_Proc 
											AND Parc_Proc.Obra_Proc = Dados_Proc.Obra_Proc 
											AND Parc_Proc.Num_Proc = Dados_Proc.Num_Proc 

							UNION 

							SELECT		DISTINCT Empresa_Pag, 
										ObraProc_Pag, 
										NumCot_Pag, 
										OrdemCompra_Pag, 
										NumProc_Pag, 
										NumFiscal_Pag 
							FROM		UAU.dbo.ContasPagas 
				) [Processos] 
							LEFT JOIN 
							( 
								SELECT		DISTINCT Empresa_Proc [Empresa_Nfp] , 
											Obra_Proc [Obra_Nfp], 
											Num_Proc [NumProc_Nfp], 
											NumNfAux_Nfe [NumNf_Nfp], 
											DataSaiEnt_Nfe [Data_Nfp] 
								FROM		UAU.dbo.NotFisc_Proc 
											INNER JOIN UAU.dbo.NotasFiscaisEnt 
												ON Empresa_Nfe = Empresa_Proc 
												AND Num_Nfe = NumNfe_Proc 
							) [NotFiscProc] 
								ON Empresa_Nfp = Empresa_Proc 
								AND Obra_Nfp = Obra_Proc 
								AND NumProc_Nfp = Num_Proc 
								AND NumNf_Nfp = DocFiscal_Proc 
			) [NotasFiscais] 
				ON Empresa_Proc = CodEmp 
				AND Obra_Proc = CodObra 
				AND NumCot_Proc = [Cotação] 
				AND OrdemCompra_Proc = [O.C] 
--WHERE		Cotação <> CASE <Cotado> WHEN 1 THEN 0 ELSE -1 END 
GROUP BY	CodEmp, CodObra, Pedido, [Cotação], CodIns, [Data do Pedido], UsrAprovPedido, [O.C], Obs, Unidade, Qtde, PrecoUnitario, ValorTotal, 
			[DtAprovPed-DataCompra], [DtAprovPed-DtEntrega], DataCompra, UsuarioCompra, DataEntrega, DataEntregaPed, Tipo, Excluido, [DtCompra-DtPedido], 
			[DtCompra-DtEntrega], [Pedido-Entrega], DataAprovSimulacao, DataSimulacaoObra, DataPedido, UltimoPreco, Desc_Emp, Descr_Obr, Descr_Ins, 
			Descr_Comp 
--ORDER BY	CodEmp, CodObra, Pedido
go

