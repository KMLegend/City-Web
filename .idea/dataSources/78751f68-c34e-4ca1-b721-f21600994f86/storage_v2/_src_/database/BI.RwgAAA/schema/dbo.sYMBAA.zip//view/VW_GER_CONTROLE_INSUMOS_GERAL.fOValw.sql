

CREATE VIEW [dbo].[VW_GER_CONTROLE_INSUMOS_GERAL] AS

SELECT DISTINCT
    InsumosGeral.Cod_ins,
    InsumosGeral.Descr_ins,
    UnidInsumoGeral.CodUn_UnIns AS Unid_ins
    --InsumosGeral.Conf_ins,
    --InsumosGeral.QuemCad_ins,
    --InsumosGeral.AtInat_ins,
    --InsumosGeral.Tvenc_ins,
    --InsumosGeral.Compra_ins,
    --InsumosGeral.Antec_ins,
    --InsumosGeral.Util_ins,
    --InsumosGeral.Est_ins,
    --InsumosGeral.TPagto_ins,
    --InsumosGeral.Categ_ins,
    --InsumosGeral.G1G2_ins,
    --InsumosGeral.Cap_ins,
    --InsumosGeral.Mao_ins,
    --InsumosGeral.Encargo_ins,
    --InsumosGeral.Tcompra_ins,
    --InsumosGeral.NTVenc_ins,
    --InsumosGeral.Tipo_ins,
    --InsumosGeral.NCompra_ins,
    --InsumosGeral.DtVenc_ins,
    --InsumosGeral.DataCad_ins,
    --InsumosGeral.DataAlt_ins,
    --InsumosGeral.UsrAlt_ins,
    --InsumosGeral.Anexos_ins,
    --InsumosGeral.CodTipoNet_ins,
    --InsumosGeral.CodDeprec_ins,
    --InsumosGeral.CodGrupo_Ins,
    --InsumosGeral.Patrimonio_Ins,
    --InsumosGeral.preco_ins,
    --InsumosGeral.dtcot_ins,
    --InsumosGeral.moeda_ins,
    --InsumosGeral.precoImProd_ins,
    --InsumosGeral.PorServ_Ins,
    --InsumosGeral.CapAplic_Ins,
    --InsumosGeral.QtdeEstMin_Ins,
    --InsumosGeral.QtdeEstMax_Ins,
    --InsumosGeral.CodLocArm_Ins,
    --InsumosGeral.NCM_Ins,
    --InsumosGeral.CEST_ins,
    --AplicacaoInsumoPisCofins.NumSTPis_aipc,
    --AplicacaoInsumoPisCofins.NumSTCofins_aipc,
    --AplicacaoInsumoPisCofins.PorcPis_aipc,
    --AplicacaoInsumoPisCofins.PorcCofins_aipc,
    --AplicacaoProdInsumo.NaturezaCredito_api,
    --AplicacaoProdInsumo.TipoCredito_api,
    --InsumosGeral.IndUtilizacaoBem_ins,
    --InsumosGeral.CapEstorno_ins,
    --InsumosGeral.ControlaPrecoMeta_Ins,
    --AplicacaoProdInsumo.NumSTIcms_api,
    --InsumosGeral.CapacTrabEquip_ins,
    --InsumosGeral.CodMarcPat_Ins,
    --InsumosGeral.ItemManutPat_Ins,
    --InsumosGeral.CodSubGrPat_Ins,
    --InsumosGeral.CapTransacaoFin_ins,
    --CapTransacaoFin.Desc_cger AS [CapTransacaoFin.Desc_cger],
    --Cap.Desc_cger AS [Cap.Desc_cger],
    --CapEstorno.Desc_cger AS [CapEstorno.Desc_cger],
    --UnidInsumoGeral.CodUn_UnIns,
    --InsumosSGQ.crite_ins,
    --InsumosSGQ.especi_ins,
    --InsumosSGQ.iden_ins,
    --InsumosSGQ.Orienta_ins,
    --InsumosSGQ.verifi_ins,
    --InsumosSGQ.obs_ins,
    --CategoriasdeInsumo.Desc_cger AS [CategoriasdeInsumo.Desc_cger],
    --InsumosSGQ.Controlar_ins,
    --MarcaModelo.Desc_marc,
    --SubGrupoPatrimonio.Descricao_SubGrPat,
    --InsumosGeral.NumApi_ins,
    --AplicacaoProdInsumo.Descr_api,
    --TabNCM.Descr_ncm,
    --InsumosGeral.CategMovFin_ins,
    --CategoriasDeMovFin.Desc_cmf,
    --UnidInsumoGeral.Padrao_UnIns,
    --UnidInsumoGeral.AtInat_UnIns,
    --InsumosGeral.PorcTolEntrega_ins,
    --InsumosGeral.PorcTotPrecoUnit_ins,
    --InsumosGeral.PorcTotPrecoUnitReducao_ins
FROM UAU.dbo.InsumosGeral
    LEFT JOIN UAU.dbo.AplicacaoProdInsumo
        ON AplicacaoProdInsumo.Num_api = InsumosGeral.NumApi_ins
           AND AplicacaoProdInsumo.Tipo_api = 1
    LEFT JOIN UAU.dbo.InsumosSGQ
        ON InsumosGeral.Cod_ins = InsumosSGQ.codInsumo_ins
    LEFT JOIN UAU.dbo.UnidInsumoGeral
        ON InsumosGeral.Cod_Ins = UnidInsumoGeral.CodIns_UnIns
           AND UnidInsumoGeral.Padrao_UnIns = 1
    LEFT JOIN UAU.dbo.CategoriasdeInsumo
        ON CategoriasdeInsumo.Codigo_cger = InsumosGeral.Categ_ins
    LEFT JOIN UAU.dbo.CAP
        ON Cap.Codigo_Cger = InsumosGeral.CapAplic_Ins
    LEFT JOIN UAU.dbo.CAP as CapEstorno
        ON CapEstorno.Codigo_Cger = InsumosGeral.CapEstorno_Ins
    LEFT JOIN UAU.dbo.CAP CapTransacaoFin
        ON CapTransacaoFin.Codigo_Cger = InsumosGeral.CapTransacaoFin_ins
    LEFT JOIN UAU.dbo.MarcaModelo
        ON MarcaModelo.Codigo_marc = InsumosGeral.CodMarcPat_Ins
    LEFT JOIN UAU.dbo.SubGrupoPatrimonio
        ON SubGrupoPatrimonio.Codigo_SubGrPat = InsumosGeral.CodSubGrPat_Ins
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins
        ON AplicacaoInsumoPisCofins.Num_aipc = AplicacaoProdInsumo.Num_api
    LEFT JOIN UAU.dbo.TabNCM
        ON InsumosGeral.NCM_Ins = TabNCM.Codigo_ncm
    LEFT JOIN UAU.dbo.CategoriasDeMovFin
        ON InsumosGeral.CategMovFin_ins = CategoriasDeMovFin.Codigo_cmf

--where Cod_ins = '1040201009'
--WHERE AtInat_ins = 0

go

