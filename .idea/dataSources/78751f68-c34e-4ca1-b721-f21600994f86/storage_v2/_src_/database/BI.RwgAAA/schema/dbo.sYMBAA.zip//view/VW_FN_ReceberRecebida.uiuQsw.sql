


CREATE view [dbo].[VW_FN_ReceberRecebida] as 


SELECT 
Consulta,

TIPO,

       --Calculado,


       Empresa_Prc,
       Obra_Prc,
       NumVend_Prc,
       /*** Valores por parcelas da venda ***/

 	   Data_Rec,     
	   PercentValor_Rpd,
		Valor_Rec,
		VlJurosParc_Rec,
		VlCorrecao_Rec,
		VlAcres_Rec,
		VlTaxaBol_Rec,
		VlMulta_Rec,
		VlJuros_Rec,
		VlCorrecaoAtr_Rec,
		VlDesconto_Rec,
		ValDescontoCusta_Rec,
		ValDescontoImposto_Rec,
		ValDescontoCondicional_rec,
		ValorConf_Rec,
		VlJurosParcConf_Rec,
		VlCorrecaoConf_Rec,
		VlAcresConf_Rec,
		VlTaxaBolConf_Rec,
		VlMultaConf_Rec,
		VlJurosConf_Rec,
		VlCorrecaoAtrConf_Rec,
		VlDescontoConf_Rec,
		ValDescontoCustaConf_Rec,
		ValDescontoImpostoConf_Rec,
		ValDescontoCondicionalConf_rec,
	   --Valor_Prc,
       
	   
	   ValorCorrecao_Prc,
       ValorCorrecaoAtr_Prc,
       ValorJurosParc_Prc,
       ValorMulta_Prc,
       ValorJuros_Prc,
       ValorAcres_Prc,
       ValorDesconto_Prc,
       ValorDescontoCondicional_Prc,
       VlCorrecaoEmb_Prc,
       VlJurosParcEmb_Prc,
       VlrDescAdiant_Prc,
       VlrPrincipal_Prc,
       TotPrinc,
       /*** Dados das pacelas ***/
       Tipo_Prc,
       NumParc_Prc,
       NumParcGer_Prc,
       IdxReaj_Prc,
       ComoParc_Prc,
       ValDescontoCusta_Prc,
       TotParc_Prc,
       ValorTaxaBol_Prc,
       ValDescontoImposto_Prc,
       JurosParc_Prc,
       AmortParc_Prc,
       GrupoIdx_Prc,
       Data_Prc,
       DtIdxParc_Prc,
       DtJurParc_Prc,
       DataPror_Prc,
       DtParc_Prc,
       BegEndParc_Prc,
       ValorResiduo_Prc,
       CobrarMulta_Prc,
       CobrarCorrecao_Prc,
       CobrarJurosAtr_Prc,
       Cliente_Prc,
       DtJurosComJuros_Prc,
       Cap_Prc,
       CapCorrecaoAtr_Prc,
       CapJuros_Prc,
       CapCorrecao_Prc,
       CapMulta_Prc,
       CapJurosAtr_Prc,
       CapAcrescimo_Prc,
       CapDesconto_Prc,
       CapDescontoAntec_Prc,
       CapTaxaBol_Prc,
       CapDescontoCusta_Prc,
       CapRepasse_Prc,
       CapDescontoCondicional_Prc,
       PorcSegJuros_prc,
       DataSegJuros_prc,
       CarenciaAtraso_prc,
       CarenciaAtrasoCorrecao_prc,
       CobrarJurosProRata_prc,
       CobrarJurosProRataPrimeiroMes_prc,
       DataProrrogacao_prc,
       NumCtp_prc,
       DataCad_prc,
       DataIniPeriodoAluguel_prc,
       TotJurParc
FROM
(

    /*** Dados de contas a Receber ***/
    /*** TIPO = 1 -> Demonstrar que é uma conta a receber ***/
    /*** Calculado = 1 -> Demonstrar que essa parcela deve ser calculada ***/
    SELECT 
	'Receber_1_1' as Consulta,
	1 AS TIPO,
           
		   
		   
		  -- 1 AS Calculado,
           
		   
		   
		   Tipo_Prc,
           NumParc_Prc,
           NumParcGer_Prc,
           IdxReaj_Prc,
           ComoParc_Prc,
          
    /*trat valor prc*/  
	  	null  as Data_Rec,	
		0 as PercentValor_Rpd,
		0 as Valor_Rec,
		0 as VlJurosParc_Rec,
		0 as VlCorrecao_Rec,
		0 as VlAcres_Rec,
		0 as VlTaxaBol_Rec,
		0 as VlMulta_Rec,
		0 as VlJuros_Rec,
		0 as VlCorrecaoAtr_Rec,
		0 as VlDesconto_Rec,
		0 as ValDescontoCusta_Rec,
		0 as ValDescontoImposto_Rec,
		0 as ValDescontoCondicional_rec,
		0 as ValorConf_Rec,
		0 as VlJurosParcConf_Rec,
		0 as VlCorrecaoConf_Rec,
		0 as VlAcresConf_Rec,
		0 as VlTaxaBolConf_Rec,
		0 as VlMultaConf_Rec,
		0 as VlJurosConf_Rec,
		0 as VlCorrecaoAtrConf_Rec,
		0 as VlDescontoConf_Rec,
		0 as ValDescontoCustaConf_Rec,
		0 as ValDescontoImpostoConf_Rec,
		0 as ValDescontoCondicionalConf_rec,		
		 -- Valor_Prc,   -- igual a VlrPrincipal_Prc
          
		  
		  
		  Valor_Prc AS VlrPrincipal_Prc,
           0 AS TotPrinc,
           ValDescontoCusta_Prc,
           TotParc_Prc,
           ValorTaxaBol_Prc,
           ValDescontoImposto_Prc,
           JurosParc_Prc,
           AmortParc_Prc,
           GrupoIdx_Prc,
           Data_Prc,
           DtIdxParc_Prc,
           DtJurParc_Prc,
           NULL AS DataPror_Prc,
           DtParc_Prc,
           BegEndParc_Prc,
           ValorResiduo_Prc,
           CobrarMulta_Prc,
           CobrarCorrecao_Prc,
           CobrarJurosAtr_Prc,
           Cliente_Prc,
           DtJurosComJuros_Prc,
           Cap_Prc,
           CapCorrecaoAtr_Prc,
           CapJuros_Prc,
           CapCorrecao_Prc,
           CapMulta_Prc,
           CapJurosAtr_Prc,
           CapAcrescimo_Prc,
           CapDesconto_Prc,
           CapDescontoAntec_Prc,
           CapTaxaBol_Prc,
           CapDescontoCusta_Prc,
           CapRepasse_Prc,
           CapDescontoCondicional_prc,
           PorcSegJuros_prc,
           DataSegJuros_prc,
           CarenciaAtraso_prc,
           CarenciaAtrasoCorrecao_prc,
           CobrarJurosProRata_prc,
           CobrarJurosProRataPrimeiroMes_prc,
           DataPror_prc As DataProrrogacao_prc,
           NumCtp_prc,
           DataCad_prc,
           0 AS ValorCorrecao_Prc,
           0 AS ValorCorrecaoAtr_Prc,
           0 AS ValorJurosParc_Prc,
           0 AS ValorMulta_Prc,
           0 AS ValorJuros_Prc,
           0 AS ValorAcres_Prc,
           0 AS ValorDesconto_Prc,
           0 AS ValorDescontoCondicional_Prc,
           0 AS VlrDescAdiant_Prc,
           0 AS VlCorrecaoEmb_Prc,
           0 AS VlJurosParcEmb_Prc,
           Empresa_Prc,
           Obra_Prc,
           NumVend_Prc,
           DataIniPeriodoAluguel_prc,
           0 AS TotJurParc
    FROM UAU.dbo.ContasReceber
        LEFT JOIN
        (
            SELECT Empresa_rpde,
                   Obra_rpde,
                   NumVend_rpde,
                   NumParc_rpde,
                   NumParcGer_rpde,
                   Tipo_rpde
            FROM UAU.dbo.RecebePgtoDivEstorno
            --WHERE DataRec_rpde < '07/31/2024'
            --      AND DataContabil_rpde >= '07/31/2024'
        ) RecebePgtoDivEstorno
            ON RecebePgtoDivEstorno.Empresa_rpde = ContasReceber.Empresa_prc
               AND RecebePgtoDivEstorno.Obra_rpde = ContasReceber.Obra_Prc
               AND RecebePgtoDivEstorno.NumVend_rpde = ContasReceber.NumVend_prc
               AND RecebePgtoDivEstorno.NumParc_rpde = ContasReceber.NumParc_Prc
               AND RecebePgtoDivEstorno.NumParcGer_rpde = ContasReceber.NumParcGer_Prc
               AND RecebePgtoDivEstorno.Tipo_rpde = ContasReceber.Tipo_Prc
    WHERE 
	--Empresa_Prc = 52
 --         AND Obra_Prc = '5201I'
 --         AND NumVend_Prc = 7
          --AND 
		  Tipo_prc <> '1'
          AND RecebePgtoDivEstorno.Empresa_rpde IS NULL
    /*** Unindo os dados das duas consultas ***/
    UNION ALL
    
	
	
	
	
	/*** Dados de contas a Receber ***/
    /*** TIPO = 1 -> Demonstrar que é uma conta a receber ***/
    /*** Calculado = 1 -> Demonstrar que essa parcela deve ser calculada ***/
    SELECT 
	
		'Receber_1_2' as Consulta,
	1 AS TIPO,
           
		   
		   
		   
		   --1 AS Calculado,
           
		   
		   
		   Tipo_Prc,
           NumParc_Prc,
           NumParcGer_Prc,
           IdxReaj_Prc,
           ComoParc_Prc,

    /*trat valor prc*/ 
	  	null  as Data_Rec,	
		0 as PercentValor_Rpd,
		0 as Valor_Rec,
		0 as VlJurosParc_Rec,
		0 as VlCorrecao_Rec,
		0 as VlAcres_Rec,
		0 as VlTaxaBol_Rec,
		0 as VlMulta_Rec,
		0 as VlJuros_Rec,
		0 as VlCorrecaoAtr_Rec,
		0 as VlDesconto_Rec,
		0 as ValDescontoCusta_Rec,
		0 as ValDescontoImposto_Rec,
		0 as ValDescontoCondicional_rec,
		0 as ValorConf_Rec,
		0 as VlJurosParcConf_Rec,
		0 as VlCorrecaoConf_Rec,
		0 as VlAcresConf_Rec,
		0 as VlTaxaBolConf_Rec,
		0 as VlMultaConf_Rec,
		0 as VlJurosConf_Rec,
		0 as VlCorrecaoAtrConf_Rec,
		0 as VlDescontoConf_Rec,
		0 as ValDescontoCustaConf_Rec,
		0 as ValDescontoImpostoConf_Rec,
		0 as ValDescontoCondicionalConf_rec,		
		   --Valor_Prc,   -- igual a VlrPrincipal_Prc
           
		   
		   
		   Valor_Prc AS VlrPrincipal_Prc,
           0 AS TotPrinc,
           ValDescontoCusta_Prc,
           TotParc_Prc,
           ValorTaxaBol_Prc,
           ValDescontoImposto_Prc,
           JurosParc_Prc,
           AmortParc_Prc,
           GrupoIdx_Prc,
           Data_Prc,
           DtIdxParc_Prc,
           DtJurParc_Prc,
           NULL AS DataPror_Prc,
           DtParc_Prc,
           BegEndParc_Prc,
           ValorResiduo_Prc,
           CobrarMulta_Prc,
           CobrarCorrecao_Prc,
           CobrarJurosAtr_Prc,
           Cliente_Prc,
           DtJurosComJuros_Prc,
           Cap_Prc,
           CapCorrecaoAtr_Prc,
           CapJuros_Prc,
           CapCorrecao_Prc,
           CapMulta_Prc,
           CapJurosAtr_Prc,
           CapAcrescimo_Prc,
           CapDesconto_Prc,
           CapDescontoAntec_Prc,
           CapTaxaBol_Prc,
           CapDescontoCusta_Prc,
           CapRepasse_Prc,
           CapDescontoCondicional_prc,
           PorcSegJuros_prc,
           DataSegJuros_prc,
           CarenciaAtraso_prc,
           CarenciaAtrasoCorrecao_prc,
           CobrarJurosProRata_prc,
           CobrarJurosProRataPrimeiroMes_prc,
           DataPror_prc AS DataProrrogacao_prc,
           NumCtp_prc,
           DataCad_prc,
           0 AS ValorCorrecao_Prc,
           0 AS ValorCorrecaoAtr_Prc,
           0 AS ValorJurosParc_Prc,
           0 AS ValorMulta_Prc,
           0 AS ValorJuros_Prc,
           0 AS ValorAcres_Prc,
           0 AS ValorDesconto_Prc,
           0 AS ValorDescontoCondicional_Prc,
           0 AS VlrDescAdiant_Prc,
           0 AS VlCorrecaoEmb_Prc,
           0 AS VlJurosParcEmb_Prc,
           Empresa_Prc,
           Obra_Prc,
           NumVend_Prc,
           DataIniPeriodoAluguel_prc,
           0 AS TotJurParc
    FROM UAU.dbo.ContasReceber
        LEFT JOIN
        (
            SELECT Empresa_rpde,
                   Obra_rpde,
                   NumVend_rpde,
                   NumParc_rpde,
                   NumParcGer_rpde,
                   Tipo_rpde
            FROM UAU.dbo.RecebePgtoDivEstorno
            --WHERE DataRec_rpde < '07/31/2024'
            --      AND DataContabil_rpde >= '07/31/2024'
        ) RecebePgtoDivEstorno
            ON RecebePgtoDivEstorno.Empresa_rpde = ContasReceber.Empresa_prc
               AND RecebePgtoDivEstorno.Obra_rpde = ContasReceber.Obra_Prc
               AND RecebePgtoDivEstorno.NumVend_rpde = ContasReceber.NumVend_prc
               AND RecebePgtoDivEstorno.NumParc_rpde = ContasReceber.NumParc_Prc
               AND RecebePgtoDivEstorno.NumParcGer_rpde = ContasReceber.NumParcGer_Prc
               AND RecebePgtoDivEstorno.Tipo_rpde = ContasReceber.Tipo_Prc
    WHERE 
	--Empresa_Prc = 52
 --         AND Obra_Prc = '5201I'
 --         AND NumVend_Prc = 7
 --         AND DataCad_Prc <= '07/31/2024'
 --         AND 
		  Tipo_Prc = '1'
          AND RecebePgtoDivEstorno.Empresa_rpde IS NULL
   
   
   
   UNION ALL


    /*** Dados da tabela de estorno ***/
    /*** TIPO = 2 -> Demonstrar que é uma conta recebida ***/
    SELECT DISTINCT

		'Receber_2_1' as Consulta,
        2 AS TIPO,
        
		
		
		--2 AS Calculado,
        
		
		
		Tipo_Prc,
        NumParc_Prc,
        NumParcGer_Prc,
        IdxReaj_Prc,
        ComoParc_Prc,

      /*trat valor prc*/
	  	null  as Data_Rec,
		PercentValor_Rpd as PercentValor_Rpd,
		0 as Valor_Rec,
		0 as VlJurosParc_Rec,
		0 as VlCorrecao_Rec,
		0 as VlAcres_Rec,
		0 as VlTaxaBol_Rec,
		0 as VlMulta_Rec,
		0 as VlJuros_Rec,
		0 as VlCorrecaoAtr_Rec,
		0 as VlDesconto_Rec,
		0 as ValDescontoCusta_Rec,
		0 as ValDescontoImposto_Rec,
		0 as ValDescontoCondicional_rec,
		0 as ValorConf_Rec,
		0 as VlJurosParcConf_Rec,
		0 as VlCorrecaoConf_Rec,
		0 as VlAcresConf_Rec,
		0 as VlTaxaBolConf_Rec,
		0 as VlMultaConf_Rec,
		0 as VlJurosConf_Rec,
		0 as VlCorrecaoAtrConf_Rec,
		0 as VlDescontoConf_Rec,
		0 as ValDescontoCustaConf_Rec,
		0 as ValDescontoImpostoConf_Rec,
		0 as ValDescontoCondicionalConf_rec,
		--PercentValor_Rpd AS Valor_Prc,


        PercentPrinc_Rpd AS VlrPrincipal_Prc,
        PercentPrinc_Rpd AS TotPrinc,
        ValDescontoCusta_Prc,
        TotParc_Prc,
        ValorTaxaBol_Prc,
        ValDescontoImposto_Prc,
        JurosParc_Prc,
        AmortParc_Prc,
        GrupoIdx_Prc,
        Data_Prc,
        DtIdxParc_Prc,
        DtJurParc_Prc,
        DataRec_rpde AS DataPror_Prc,
        DtParc_Prc,
        BegEndParc_Prc,
        ValorResiduo_Prc,
        CobrarMulta_Prc,
        CobrarCorrecao_Prc,
        CobrarJurosAtr_Prc,
        Cliente_Prc,
        DtJurosComJuros_Prc,
        Cap_Prc,
        CapCorrecaoAtr_Prc,
        CapJuros_Prc,
        CapCorrecao_Prc,
        CapMulta_Prc,
        CapJurosAtr_Prc,
        CapAcrescimo_Prc,
        CapDesconto_Prc,
        CapDescontoAntec_Prc,
        CapTaxaBol_Prc,
        CapDescontoCusta_Prc,
        CapRepasse_Prc,
        CapDescontoCondicional_prc,
        PorcSegJuros_prc,
        DataSegJuros_prc,
        CarenciaAtraso_prc,
        CarenciaAtrasoCorrecao_prc,
        CobrarJurosProRata_prc,
        CobrarJurosProRataPrimeiroMes_prc,
        DataPror_Prc AS DataProrrogacao_prc,
        NumCtp_prc,
        DataCad_prc,
        PercentCorr_Rpd AS ValorCorrecao_Prc,
        PercentCorrAtr_Rpd AS ValorCorrecaoAtr_Prc,
        PercentJurComp_Rpd AS ValorJurosParc_Prc,
        PercentMultaAtr_Rpd AS ValorMulta_Prc,
        PercentJurAtr_Rpd AS ValorJuros_Prc,
        PercentAcres_Rpd AS ValorAcres_Prc,
        PercentDesc_Rpd AS ValorDesconto_Prc,
        PercentDescontoCondicional_rpd AS ValorDescontoCondicional_Prc,
        PercentDescAntec_Rpd AS VlrDescAdiant_Prc,
        PercentCorrEmb_Rpd AS VlCorrecaoEmb_Prc,
        PercentJurCompEmb_Rpd AS VlJurosParcEmb_Prc,
        Empresa_Prc,
        Obra_Prc,
        NumVend_Prc,
        DataIniPeriodoAluguel_prc,
           0 AS TotJurParc
    FROM UAU.dbo.RecebePgtoDivEstorno
        INNER JOIN UAU.dbo.RecebePgto
            ON RecebePgto.Empresa_rpg = RecebePgtoDivEstorno.Empresa_rpde
               AND RecebePgto.NumReceb_Rpg = RecebePgtoDivEstorno.NumReceb_rpde
               AND RecebePgto.Tipo_Rpg = RecebePgtoDivEstorno.TipoRpg_rpde
               AND RecebePgto.NumCont_Rpg = RecebePgtoDivEstorno.NumCont_rpde
        INNER JOIN UAU.dbo.RecebePgtoDiv
            ON RecebePgtoDiv.Empresa_Rpd = RecebePgtoDivEstorno.Empresa_rpde
               AND RecebePgtoDiv.NumReceb_Rpd = RecebePgtoDivEstorno.NumReceb_rpde
               AND RecebePgtoDiv.TipoRpg_Rpd = RecebePgtoDivEstorno.TipoRpg_rpde
               AND RecebePgtoDiv.NumCont_Rpd = RecebePgtoDivEstorno.NumCont_rpde
               AND RecebePgtoDiv.NumParc_Rpd = RecebePgtoDivEstorno.NumParc_rpde
               AND RecebePgtoDiv.NumVend_Rpd = RecebePgtoDivEstorno.NumVend_rpde
               AND RecebePgtoDiv.Obra_Rpd = RecebePgtoDivEstorno.Obra_rpde
               AND RecebePgtoDiv.ParcType_Rpd = RecebePgtoDivEstorno.ParcType_rpde
               AND RecebePgtoDiv.Tipo_Rpd = RecebePgtoDivEstorno.Tipo_rpde
               AND RecebePgtoDiv.NumParcGer_Rpd = RecebePgtoDivEstorno.NumParcGer_rpde
        INNER JOIN UAU.dbo.ContasReceber
            ON RecebePgtoDivEstorno.Empresa_rpde = ContasReceber.Empresa_prc
               AND RecebePgtoDivEstorno.Obra_rpde = ContasReceber.Obra_Prc
               AND RecebePgtoDivEstorno.NumVend_rpde = ContasReceber.NumVend_prc
               AND RecebePgtoDivEstorno.NumParc_rpde = ContasReceber.NumParc_Prc
               AND RecebePgtoDivEstorno.NumParcGer_rpde = ContasReceber.NumParcGer_Prc
               AND RecebePgtoDivEstorno.Tipo_rpde = ContasReceber.Tipo_Prc
    --WHERE ContasReceber.Empresa_prc = 52
    --      AND ContasReceber.Obra_Prc = '5201I'
    --      AND ContasReceber.NumVend_prc = 7
    --      AND RecebePgtoDivEstorno.DataContabil_rpde >= '07/31/2024'
    --      AND RecebePgtoDivEstorno.DataRec_rpde < '07/31/2024'
    
	
	UNION ALL


    /*** Dados de contas Recebidas ***/
    /*** TIPO = 2 -> Demonstrar que é uma conta recebida ***/
    /*** Calculado = 1 ou 2 -> Demonstrar que essa parcela deve ser calculada ***/
    /*** Calculado = 1 ->> Se Data_Rec >= Data Selecionada Considerar com conta Não Recebida (Calcular) ***/
    /*** Calculado = 2 ->> Se Data_Rec < Data Selecionada Considerar com conta Recebida (Não Calcular) ***/
    SELECT 
	
		'Receber_2_2' as Consulta,
	2 AS TIPO,

	 /*varia*/
		   /*
           ISNULL(   StatusRecebimento,
                     CASE
                         WHEN Data_Rec >= '07/31/2024' THEN
                             1
                         ELSE
                             2
                     END
                 ) AS Calculado,
*/


           ISNULL(Tipo_Rec, 'P') AS Tipo_Prc,
           ISNULL(NumParc_Rec, 1) AS NumParc_Prc,
           ISNULL(NumParcGer_Rec, 1) AS NumParcGer_Prc,
           IdxReaj_Rec AS IdxReaj_Prc,
           ComoParc_Rec AS ComoParc_Prc,
           

      /*trat valor prc*/   
			Data_Rec,
			0 as PercentValor_Rpd,
		   Recebidas.Valor_Rec,
			Recebidas.VlJurosParc_Rec,
			Recebidas.VlCorrecao_Rec,
			Recebidas.VlAcres_Rec ,
			Recebidas.VlTaxaBol_Rec,
			Recebidas.VlMulta_Rec,
			Recebidas.VlJuros_Rec,
			Recebidas.VlCorrecaoAtr_Rec,
			Recebidas.VlDesconto_Rec,
			Recebidas.ValDescontoCusta_Rec,
			Recebidas.ValDescontoImposto_Rec,
			Recebidas.ValDescontoCondicional_rec,
			Recebidas.ValorConf_Rec,
			--Recebidas.VlJurosParcConf_Rec,
			CASE 
				WHEN VendasRecebidas.AniversarioContr_VRec = 0 THEN Recebidas.VlJurosParcConf_Rec
					ELSE Recebidas.VlJurosParcConf_Rec - Recebidas.VlJurosParcEmbConf_Rec
				END AS VlJurosParcConf_Rec,
			Recebidas.VlCorrecaoConf_Rec,
			Recebidas.VlAcresConf_Rec,
			Recebidas.VlTaxaBolConf_Rec,
			Recebidas.VlMultaConf_Rec,
			Recebidas.VlJurosConf_Rec,
			Recebidas.VlCorrecaoAtrConf_Rec,
			Recebidas.VlDescontoConf_Rec,
			Recebidas.ValDescontoCustaConf_Rec,
			Recebidas.ValDescontoImpostoConf_Rec,
			Recebidas.ValDescontoCondicionalConf_rec,


		   /*varia*/
		   /*
		   CASE
               WHEN Data_Rec < '07/31/2024' THEN --Esse valor não será calculado 
           (((Recebidas.Valor_Rec + Recebidas.VlJurosParc_Rec + Recebidas.VlCorrecao_Rec + Recebidas.VlAcres_Rec
              + Recebidas.VlTaxaBol_Rec + Recebidas.VlMulta_Rec + Recebidas.VlJuros_Rec + Recebidas.VlCorrecaoAtr_Rec
             )
             - (Recebidas.VlDesconto_Rec + Recebidas.ValDescontoCusta_Rec + Recebidas.ValDescontoImposto_Rec
                + Recebidas.ValDescontoCondicional_rec
               )
            )
            + ((Recebidas.ValorConf_Rec + Recebidas.VlJurosParcConf_Rec + Recebidas.VlCorrecaoConf_Rec
                + Recebidas.VlAcresConf_Rec + Recebidas.VlTaxaBolConf_Rec + Recebidas.VlMultaConf_Rec
                + Recebidas.VlJurosConf_Rec + Recebidas.VlCorrecaoAtrConf_Rec
               )
               - (Recebidas.VlDescontoConf_Rec + Recebidas.ValDescontoCustaConf_Rec
                  + Recebidas.ValDescontoImpostoConf_Rec + Recebidas.ValDescontoCondicionalConf_rec
                 )
              )
           )
               ELSE --Valor será calculado 
           (Recebidas.Valor_Rec + Recebidas.ValorConf_Rec)
           END AS Valor_Prc,

		   */


                                            --Valor do Principal 
           ISNULL(
                     RecebimentoEstorno.PercentPrinc_Rpd,
                     (CASE VendasRecebidas.AniversarioContr_VRec
                          WHEN 0 THEN
                     (Recebidas.Valor_Rec + Recebidas.ValorConf_Rec)
                          ELSE
                     ((Recebidas.Valor_Rec + Recebidas.ValorConf_Rec)
                      + (Recebidas.VlJurosParcEmb_Rec + Recebidas.VlJurosParcEmbConf_Rec)
                      + (Recebidas.VlCorrecaoEmb_Rec + Recebidas.VlCorrecaoEmbConf_Rec)
                     )
                      END
                     )
                 ) AS VlrPrincipal_Prc,     --Valor do Principal 
           ISNULL(
                     RecebimentoEstorno.PercentPrinc_Rpd,
                     (CASE VendasRecebidas.AniversarioContr_VRec
                          WHEN 0 THEN
                     (Recebidas.Valor_Rec + Recebidas.ValorConf_Rec)
                          ELSE
                     ((Recebidas.Valor_Rec + Recebidas.ValorConf_Rec)
                      + (Recebidas.VlJurosParcEmb_Rec + Recebidas.VlJurosParcEmbConf_Rec)
                      + (Recebidas.VlCorrecaoEmb_Rec + Recebidas.VlCorrecaoEmbConf_Rec)
                     )
                      END
                     )
                 ) AS TotPrinc,             --Outras dados as parcelas recebidas 
           ISNULL(
                     RecebimentoEstorno.PercentDescontoCusta_Rpd,
                     (Recebidas.ValDescontoCusta_Rec + Recebidas.ValDescontoCustaConf_Rec)
                 ) AS ValDescontoCusta_Prc,
           TotParc_Rec AS TotParc_Prc,
           ISNULL(RecebimentoEstorno.PercentTaxaBol_Rpd, (Recebidas.VlTaxaBol_Rec + Recebidas.VlTaxaBolConf_Rec)) AS ValorTaxaBol_Prc,
           ISNULL(
                     RecebimentoEstorno.PercentDescontoImposto_Rpd,
                     (Recebidas.ValDescontoImposto_Rec + Recebidas.ValDescontoImpostoConf_Rec)
                 ) AS ValDescontoImposto_Prc,
           JurosParc_Rec AS JurosParc_Prc,
           AmortParc_Rec AS AmortParc_Prc,
           GrupoIdx_Rec AS GrupoIdx_Prc,
           ISNULL(DataVenci_Rec, Data_VRec) AS Data_Prc,
           DtIdxParc_Rec AS DtIdxParc_Prc,
           DtJurParc_Rec AS DtJurParc_Prc,
           COALESCE(DataRec_rpde, Data_Rec, Data_VRec) AS DataPror_Prc,
           DtParc_Rec AS DtParc_Prc,
           BegEndParc_Rec AS BegEndParc_Prc,
           ValorResiduo_Rec AS ValorResiduo_Prc,
           CobrarMulta_Rec AS CobrarMulta_Prc,
           CobrarCorrecao_Rec AS CobrarCorrecao_Prc,
           CobrarJurosAtr_Rec AS CobrarJurosAtr_Prc,
           Cliente_vRec AS Cliente_Prc,
           DtJurosComJuros_rec AS DtJurosComJuros_Prc,
           ISNULL(Cap_rec, CapProvisaoCurto_Vrec) AS Cap_Prc,
           CapCorrecaoAtr_rec AS CapCorrecaoAtr_Prc,
           CapJuros_rec AS CapJuros_Prc,
           CapCorrecao_rec AS CapCorrecao_Prc,
           CapMulta_rec AS CapMulta_Prc,
           CapJurosAtr_rec AS CapJurosAtr_Prc,
           CapAcrescimo_rec AS CapAcrescimo_Prc,
           CapDesconto_rec AS CapDesconto_Prc,
           CapDescontoAntec_rec AS CapDescontoAntec_Prc,
           CapTaxaBol_rec AS CapTaxaBol_Prc,
           CapDescontoCusta_rec AS CapDescontoCusta_Prc,
           CapRepasse_rec AS CapRepasse_Prc,
           CapDescontoCondicional_Rec AS CapDescontoCondicional_Prc,
           PorcSegJuros_rec AS PorcSegJuros_prc,
           DataSegJuros_rec AS DataSegJuros_prc,
           CarenciaAtraso_rec AS CarenciaAtraso_prc,
           CarenciaAtrasoCorrecao_rec AS CarenciaAtrasoCorrecao_prc,
           CobrarJurosProRata_rec AS CobrarJurosProRata_prc,
           CobrarJurosProRataPrimeiroMes_rec AS CobrarJurosProRataPrimeiroMes_prc,
           NULL AS DataProrrogacao_prc,
           NumCtp_rec As NumCtp_prc,
           DataCad_rec As DataCad_prc,
                                            --Valor da correção 
           ISNULL(
                     RecebimentoEstorno.PercentCorr_Rpd,
                     (CASE VendasRecebidas.AniversarioContr_VRec
                          WHEN 0 THEN
                     (Recebidas.VlCorrecao_Rec + Recebidas.VlCorrecaoConf_Rec)
                          ELSE
                     (Recebidas.VlCorrecao_Rec + Recebidas.VlCorrecaoConf_Rec)
                     - (Recebidas.VlCorrecaoEmb_Rec + Recebidas.VlCorrecaoEmbConf_Rec)
                      END
                     )
                 ) AS ValorCorrecao_Prc,
           ISNULL(
                     RecebimentoEstorno.PercentJurComp_Rpd,
                     (Recebidas.VlCorrecaoAtr_Rec + Recebidas.VlCorrecaoAtrConf_Rec)
                 ) AS ValorCorrecaoAtr_Prc, --Valor dos juros da parcela 
           ISNULL(
                     RecebimentoEstorno.PercentJurComp_Rpd,
                     (CASE VendasRecebidas.AniversarioContr_VRec
                          WHEN 0 THEN
                     (Recebidas.VlJurosParc_Rec + Recebidas.VlJurosParcConf_Rec)
                          ELSE
                     (Recebidas.VlJurosParc_Rec + Recebidas.VlJurosParcConf_Rec)
                     - (Recebidas.VlJurosParcEmb_Rec + Recebidas.VlJurosParcEmbConf_Rec)
                      END
                     )
                 ) AS ValorJurosParc_Prc,
           ISNULL(RecebimentoEstorno.PercentMultaAtr_Rpd, (Recebidas.VlMulta_Rec + Recebidas.VlMultaConf_Rec)) AS ValorMulta_Prc,
           ISNULL(RecebimentoEstorno.PercentJurAtr_Rpd, (Recebidas.VlJuros_Rec + Recebidas.VlJurosConf_Rec)) AS ValorJuros_Prc,
           ISNULL(RecebimentoEstorno.PercentAcres_Rpd, (Recebidas.VlAcres_Rec + Recebidas.VlAcresConf_Rec)) AS ValorAcres_Prc,
           ISNULL(RecebimentoEstorno.PercentDesc_Rpd, (Recebidas.VlDesconto_Rec + Recebidas.VlDescontoConf_Rec)) AS ValorDesconto_Prc,
           ISNULL(
                     RecebimentoEstorno.PercentDescontoCondicional_rpd,
                     (Recebidas.ValDescontoCondicional_rec + Recebidas.ValDescontoCondicionalConf_rec)
                 ) AS ValorDescontoCondicional_Prc,
           ISNULL(RecebimentoEstorno.PercentDescAntec_Rpd, VlrDescAdiant_Rec) AS VlrDescAdiant_Rec,
           ISNULL(
                     RecebimentoEstorno.PercentCorrEmb_Rpd,
                     (Recebidas.VlCorrecaoEmb_Rec + Recebidas.VlCorrecaoEmbConf_Rec)
                 ) AS VlCorrecaoEmb_Prc,
           ISNULL(
                     RecebimentoEstorno.PercentJurCompEmb_Rpd,
                     (Recebidas.VlJurosParcEmb_Rec + Recebidas.VlJurosParcEmbConf_Rec)
                 ) AS VlJurosParcEmb_Prc,
           Empresa_vRec,
           Obra_vRec,
           Num_vRec,
           DataIniPeriodoAluguel_rec AS DataIniPeriodoAluguel_prc,
			CASE 
				WHEN VendasRecebidas.AniversarioContr_VRec = 0 
					THEN (Recebidas.VlJurosParc_Rec + Recebidas.VlJurosParcConf_Rec)
				ELSE (Recebidas.VlJurosParc_Rec + Recebidas.VlJurosParcConf_Rec) - (Recebidas.VlJurosParcEmb_Rec + Recebidas.VlJurosParcEmbConf_Rec)
				END AS TotJurParc
    FROM UAU.dbo.Recebidas
        LEFT JOIN
        (
            SELECT Empresa_rpde,
                   Obra_rpde,
                   NumVend_rpde,
                   NumParc_rpde,
                   NumParcGer_rpde,
                   Tipo_rpde,
                   2 AS StatusRecebimento,
                   ParcType_rpde,
                   DataRec_rpde,
                   NumCont_rpde,
                   numReceb_rpde,
                   TipoRpg_rpde
            FROM UAU.dbo.RecebePgtoDivEstorno
            --WHERE DataRec_rpde < '07/31/2024'
            --      AND DataContabil_rpde >= '07/31/2024'
        ) recebePgtoDivEstorno
            ON RecebePgtoDivEstorno.Empresa_rpde = Recebidas.Empresa_rec
               AND RecebePgtoDivEstorno.Obra_rpde = Recebidas.Obra_Rec
               AND RecebePgtoDivEstorno.NumVend_rpde = Recebidas.NumVend_Rec
               AND RecebePgtoDivEstorno.NumParc_rpde = Recebidas.NumParc_Rec
               AND RecebePgtoDivEstorno.NumParcGer_rpde = Recebidas.NumParcGer_Rec
               AND RecebePgtoDivEstorno.Tipo_rpde = Recebidas.Tipo_Rec
        LEFT JOIN UAU.dbo.RecebePgtoDiv RecebimentoEstorno
            ON RecebimentoEstorno.Empresa_rpd = RecebePgtoDivEstorno.Empresa_rpde
               AND RecebimentoEstorno.NumReceb_rpd = RecebePgtoDivEstorno.NumReceb_rpde
               AND RecebimentoEstorno.TipoRpg_rpd = RecebePgtoDivEstorno.TipoRpg_rpde
               AND RecebimentoEstorno.NumCont_rpd = RecebePgtoDivEstorno.NumCont_rpde
               AND RecebimentoEstorno.NumParc_rpd = RecebePgtoDivEstorno.NumParc_rpde
               AND RecebimentoEstorno.NumVend_rpd = RecebePgtoDivEstorno.NumVend_rpde
               AND RecebimentoEstorno.Obra_rpd = RecebePgtoDivEstorno.Obra_rpde
               AND RecebimentoEstorno.ParcType_rpd = RecebePgtoDivEstorno.ParcType_rpde
               AND RecebimentoEstorno.Tipo_rpd = RecebePgtoDivEstorno.Tipo_rpde
               AND RecebimentoEstorno.NumParcGer_rpd = RecebePgtoDivEstorno.NumParcGer_rpde
        RIGHT JOIN UAU.dbo.VendasRecebidas
            ON VendasRecebidas.Empresa_vrec = Recebidas.Empresa_rec
               AND VendasRecebidas.Obra_vrec = Recebidas.Obra_rec
               AND VendasRecebidas.Num_vrec = Recebidas.NumVend_rec

) AS Parcelas

    --WHERE Empresa_vRec = 52
    --      AND Obra_vRec like '%I'
    --      AND Num_vRec = 7



go

