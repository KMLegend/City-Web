



 CREATE VIEW [dbo].[VW_GER_CONTROLE_ITENS_CONTRATO] AS 
 
 select DISTINCT
	C.Empresa_cont   , 
	c.Obra_cont ,
	--v.empresa_des  [EmpresaUAU2] , 
	P.nome_pes ,  
	C.Cod_cont ,  
	C.Objeto_cont , 
	C.Situacao_cont , 
	C.CodPes_cont , 
	i.Empresa_itens ,  
	i.Contrato_itens ,
	i.Item_itens , 
	i.Serv_itens , 
	i.Descr_itens , 
	i.Qtde_itens , 
	i.Origem_itens , 
	i.Unid_itens , 
	pl.Empresa_ItSi  , 
	pl.Contrato_ItSi , 
	pl.Obra_ItSi , 
	pl.Item_ItSi   , 
	pl.ItemPl_ItSi , 
	pl.Serv_ItSi , 
	pl.Ins_ItSi , 
	pl.Produto_ItSi , 
	pl.ContratoPl_ItSi , 
	pl.Porc_ItSi , 
	pl.Total_ItSi 
	-- , 
	--v.DescCompPl_Des [DescricaoCompPlUAU],
	--v.DescInsPl_Des [DescricaoInsumoUAU], 
	--sum(v.TotalLiq_Des * pl.Porc_ItSi)  [PercentualMedido] 
	
from UAU.dbo.ItensContrato i
left join UAU.dbo.ItensContSi pl 
	on  i.Empresa_itens = pl.Empresa_ItSi 
		and i.Item_itens = pl.Item_ItSi 
		and i.Contrato_itens = pl.Contrato_ItSi 
left join UAU.dbo.Contratos c  
	on  i.Contrato_itens  = c.Cod_cont 
		and i.Empresa_itens = c.Empresa_cont  
--left join UAU.dbo.vwdesembolso v 
--	on  c.Obra_cont = v.Obra_Des
--		and c.Empresa_cont = v.Empresa_Des
--		and c.Cod_cont = v.ContratoServ_Des
--		and pl.ItemPl_ItSi = v.ItemPl_Des
--		and pl.Serv_ItSi = v.CompPl_Des
--		and pl.Ins_ItSi = v.InsumoPl_Des                        
LEFT JOIN UAU.dbo.Pessoas p 
	ON C.CodPes_cont  = P.cod_pes   
go

