CREATE VIEW dbo.VW_GER_CONTROLE_FISCAL_RECEITA_DEPOSITOS_PROPORCIONAIS AS 

SELECT *
FROM
(
    SELECT Depositos.Numero_Dep
         , Depositos.Banco_Dep
         , Depositos.Conta_Dep
         , Depositos.Data_Dep
         , RecebePgto.DataConciliacao_Rpg
         , RecebePgtoDiv.*
         , RecebePgto.Status_Rpg
         , RecebePgto.DescTit_Rpg
         , RecebePgto.Tipo_rpg
         , RecebePgto.NumReceb_rpg
         , RecebePgto.Cliente_rpg
         , Recebidas.DataVenci_Rec
         , Pessoas.nome_pes
         , Depositos.Empresa_Dep                   AS Empresa
         , Recebidas.Data_Rec
         , Parcelas.Descricao_Par
         , Parcelas.Tipo_par
         , COALESCE(Recebidas.TotParcGrupo_rec, 0) AS TotParcGrupo_rec
         , CASE RecebePgtoDiv.Tipo_Rpd
               WHEN 'A' THEN
                   0
               WHEN 'R' THEN
                   0
               ELSE
                   CASE AniversarioContr_VRec
                       WHEN 0 THEN
         (RecebePgtoDiv.PercentPrinc_Rpd)
                       ELSE
         (RecebePgtoDiv.PercentPrinc_Rpd + RecebePgtoDiv.PercentJurCompEmb_Rpd + RecebePgtoDiv.PercentCorrEmb_Rpd)
                   END
           END                                     AS Principal
         , CASE RecebePgtoDiv.Tipo_Rpd
               WHEN 'A' THEN
                   RecebePgtoDiv.PercentPrinc_Rpd + RecebePgtoDiv.PercentCorr_Rpd
               WHEN 'R' THEN
                   RecebePgtoDiv.PercentPrinc_Rpd + RecebePgtoDiv.PercentCorr_Rpd
               ELSE
                   CASE AniversarioContr_VRec
                       WHEN 0 THEN
         (RecebePgtoDiv.PercentCorr_Rpd)
                       ELSE
         (RecebePgtoDiv.PercentCorr_Rpd) - (RecebePgtoDiv.PercentCorrEmb_Rpd)
                   END
           END                                     AS Correcao
         , CASE AniversarioContr_VRec
               WHEN 0 THEN
         (RecebePgtoDiv.PercentJurComp_Rpd)
               ELSE
         (RecebePgtoDiv.PercentJurComp_Rpd) - (RecebePgtoDiv.PercentJurCompEmb_Rpd)
           END                                     AS JurosParc
    FROM UAU.dbo.RecebePgtoDiv
        LEFT JOIN UAU.dbo.RecebePgto
            ON RecebePgtoDiv.Empresa_Rpd = RecebePgto.Empresa_rpg
               AND RecebePgtoDiv.NumReceb_Rpd = RecebePgto.NumReceb_Rpg
               AND RecebePgtoDiv.TipoRpg_Rpd = RecebePgto.Tipo_Rpg
               AND RecebePgtoDiv.NumCont_Rpd = RecebePgto.NumCont_Rpg
        LEFT JOIN UAU.dbo.Recebidas
            ON RecebePgtoDiv.Empresa_Rpd = Recebidas.Empresa_rec
               AND RecebePgtoDiv.NumVend_Rpd = Recebidas.NumVend_Rec
               AND RecebePgtoDiv.Obra_Rpd = Recebidas.Obra_Rec
               AND RecebePgtoDiv.ParcType_Rpd = Recebidas.ParcType_Rec
               AND RecebePgtoDiv.Tipo_Rpd = Recebidas.Tipo_Rec
               AND RecebePgtoDiv.NumParcGer_Rpd = Recebidas.NumParcGer_Rec
               AND RecebePgtoDiv.NumParc_Rpd = Recebidas.NumParc_Rec
        INNER JOIN
        (
            SELECT Empresa_vrec
                 , Obra_VRec
                 , Num_VRec
                 , Cliente_VRec
                 , IntExt_Vrec
                 , AlmoxCentral_VRec
                 , AniversarioContr_VRec
            FROM UAU.dbo.VendasRecebidas
            UNION
            SELECT Empresa_ven
                 , Obra_Ven
                 , Num_Ven
                 , Cliente_Ven
                 , IntExt_Ven
                 , AlmoxCentral_Ven
                 , AniversarioContr_Ven
            FROM UAU.dbo.Vendas
        )                   VendasRecebidas
            ON RecebePgtoDiv.Empresa_rpd = VendasRecebidas.Empresa_vrec
               AND RecebePgtoDiv.NumVend_rpd = VendasRecebidas.Num_VRec
               AND RecebePgtoDiv.Obra_rpd = VendasRecebidas.Obra_VRec
        INNER JOIN UAU.dbo.Depositos
            ON RecebePgto.Empresa_Rpg = Depositos.Empresa_Dep
               AND RecebePgto.NumDep_Rpg = Depositos.Numero_Dep
               AND RecebePgto.ContaDep_Rpg = Depositos.Conta_Dep
               AND RecebePgto.BancoDep_Rpg = Depositos.Banco_Dep
        INNER JOIN UAU.dbo.Pessoas
            ON RecebePgto.Cliente_Rpg = Pessoas.cod_pes
        INNER JOIN UAU.dbo.Parcelas
            ON RecebePgtoDiv.Tipo_Rpd = Parcelas.Tipo_Par
    WHERE --AND Depositos.Data_Dep BETWEEN '09/01/2024' AND '09/30/2024' AND
        Depositos.Banco_Dep IS NOT NULL
        AND (
                VendasRecebidas.IntExt_VRec = 'E'
                OR (
                       VendasRecebidas.IntExt_Vrec = 'I'
                       AND VendasRecebidas.AlmoxCentral_Vrec = 1
                   )
            )
        --and Empresa_Dep = 1 
        AND (NOT EXISTS
    (
        SELECT BancoContaUsuarios.Banco_BcoCont
        FROM UAU.dbo.BancoContaUsuarios WITH (NOLOCK)
        WHERE Usuario_BcoCont = 'KEICY'
              AND Depositos.Empresa_dep = BancoContaUsuarios.Empresa_BcoCont
              AND Depositos.Banco_dep = BancoContaUsuarios.Banco_BcoCont
              AND Depositos.Conta_dep = BancoContaUsuarios.Conta_BcoCont
    )
            )
        --AND Depositos.Data_Dep BETWEEN '09/01/2024' AND '09/30/2024'
        AND Depositos.Banco_Dep IS NOT NULL
        AND (
                VendasRecebidas.IntExt_VRec = 'E'
                OR (
                       VendasRecebidas.IntExt_Vrec = 'I'
                       AND VendasRecebidas.AlmoxCentral_Vrec = 1
                   )
            )
) AS Depositos

--ORDER BY DescTit_Rpg
go

