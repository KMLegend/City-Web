

CREATE VIEW [dbo].[VW_GER_CONTROLE_PLANO_INDEXADOR] AS 
-- aplicação de indice de juros sobre as parcelas de vendas, de acordo com a data abaixo
SELECT 
P.Empresa_pidx
,P.NumVen_pidx
,P.ObraVen_pidx
,P.Data_pidx
,P.IdxReaj_pidx
,I.Descr_idx
,P.GrupoIdx_pidx
FROM UAU.dbo.PlanoIndexador AS P
LEFT JOIN UAU.dbo.Indices AS I
ON P.IdxReaj_pidx = I.Cod_idx

--WHERE P.Empresa_pidx = '53'
--AND P.NumVen_pidx = '67'

go

