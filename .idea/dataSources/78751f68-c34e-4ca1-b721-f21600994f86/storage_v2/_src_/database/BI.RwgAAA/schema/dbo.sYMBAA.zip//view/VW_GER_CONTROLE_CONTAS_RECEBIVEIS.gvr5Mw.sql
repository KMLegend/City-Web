






CREATE VIEW [dbo].[VW_GER_CONTROLE_CONTAS_RECEBIVEIS] AS 
-- conjunto de contas a receber e recebidas


WITH ID AS (
SELECT 
	   Idx_vi
      ,Data_vi
      ,Valor_vi
      ,DataFim_vi
      ,Anexos_vi
      ,DataCad_vi
      ,UsrCad_vi
      ,TipoCadastro_vi
FROM BI.dbo.VW_GER_CONTROLE_VALOR_INDICES 
)
, CORRECAO AS (
SELECT
	CONTA.COD_EMP -- codigo da empresa
	,CONTA.COD_OBR -- codigo da obra	
	,CONTA.COD_VENDA -- codigo do contrato de venda
	,DATEADD(MONTH,1,CONTA."DATA_VENCIMENTO") AS DATA_CORRECAO
FROM (

	SELECT 		
		base."COD_EMP" -- codigo da empresa 
		,base."EMPRESA"
		,base."COD_OBR" -- codigo da obra
		,base."OBRA"
		,base."COD_VENDA" -- codigo do contrato de venda
		,base."IDENTIFICADOR_UNID"
		--,VENDA."num_ven" --Numero do Contrato
		--,VENDA."data_ven" AS "DATA_VENDA" --Data da Venda
		--,VENDA."identificador_unid" -- Unidade    
		,base."COD_CLIENTE" -- codigo da cliente
		,base."CLIENTE"
		,base."DATA_NEGOCIACAO" -- data de negociação
		,base."DATA_VENCIMENTO" -- data vencimento
		,base."DATA_PAGAMENTO" --[DATA_PAGAMENTO]
		,ROW_NUMBER() OVER(
			PARTITION BY  base."COD_EMP",base."COD_OBR",base."COD_VENDA",base."TIPO" 
			ORDER BY base."DATA_VENCIMENTO" ASC) AS LINHA
		,base."TIPO" -- tipo_rec (descricao de tipo exemplo: Renegociacao)
		,base."STATUS"
		,base."NUM_PARCELA" --qual de parcela
		,base."NUM_PARCELA_GERAL"  --total de parcela
		,base."DIAS_EM_ABERTO"-- calcula tempo da fatura em aberto
		,base."VALOR_PRINCIPAL"  -- valor principal
		,base."VALOR_AJUSTADO"  -- valor ajustado
	FROM (

		SELECT 		
			"codemp" AS COD_EMP -- codigo da empresa 
			,"empresa" AS EMPRESA
			,"obra_rpd" AS COD_OBR -- codigo da obra
			,"obra" AS OBRA
			,"identificador_unid" AS IDENTIFICADOR_UNID
			,"num_ven" AS COD_VENDA -- codigo do contrato de venda
			,"cod_cliente" AS COD_CLIENTE -- codigo da cliente
			,"cliente" AS CLIENTE
			,NULL AS DATA_NEGOCIACAO -- data de negociação
			,"data vencimento" AS DATA_VENCIMENTO -- data vencimento
			,NULL AS DATA_PAGAMENTO --[DATA_PAGAMENTO]
			,"tipo" AS TIPO -- tipo_rec (descricao de tipo exemplo: Renegociacao)
			,'CONTA EM ABERTO'  AS STATUS
			,"num parc" AS NUM_PARCELA --qual de parcela
			,"num parc geral" AS NUM_PARCELA_GERAL  --total de parcela
			,"dias em aberto" AS DIAS_EM_ABERTO -- calcula tempo da fatura em aberto
			,CAST("vlr principal" AS FLOAT) AS VALOR_PRINCIPAL  -- valor principal
			,CAST("vlr parcela" AS FLOAT) AS VALOR_AJUSTADO  -- valor ajustado

		 FROM [BI].[dbo].[VW_GER_CONTROLE_CONTA_A_RECEBER]
		-- WHERE "identificador_unid" is not null
		-- WHERE "codemp" = '10'
			-- AND "empresa" = 'SPE CITY 03 OM PRAÇA DO SOL EMPREENDIMENTOS LTDA'
			-- AND "identificador_unid" like '2402%'
			-- AND "num_ven" = '131'

		UNION ALL

		SELECT 		
			"codemp" AS COD_EMP -- codigo da empresa 
			,"empresa" AS EMPRESA
			,"obra_rpd" AS COD_OBR -- codigo da obra
			,"obra" AS OBRA
			,"identificador_unid" AS IDENTIFICADOR_UNID
			,"venda" AS COD_VENDA -- codigo do contrato de venda
			,"cliente_rec" AS COD_CLIENTE -- codigo da cliente
			,"cliente" AS CLIENTE
			,"dataconcil" AS DATA_NEGOCIACAO -- data de negociação
			,"data vencimento" AS DATA_VENCIMENTO -- data vencimento
			,"datadep_rpg" AS DATA_PAGAMENTO --[DATA_PAGAMENTO]
			,"tipo" AS TIPO -- tipo_rec (descricao de tipo exemplo: Renegociacao)
			,'CONTA PAGA'  AS STATUS	
			,"parcelarecebida" AS NUM_PARCELA --qual de parcela
			,"numparcger_rec" AS NUM_PARCELA_GERAL  --total de parcela
			,0 AS DIAS_EM_ABERTO -- calcula tempo da fatura em aberto
			,CAST("valorprincipalprice_rec" AS FLOAT) AS VALOR_PRINCIPAL  -- valor principal
			,CAST("valordepositado" AS FLOAT) AS VALOR_AJUSTADO  -- valor ajustado

		FROM [BI].[dbo].[VW_GER_CONTROLE_CONTA_RECEBIDAS]
		-- WHERE "identificador_unid" is not null
		-- WHERE "codemp" = '10'
			-- AND "empresa" = 'SPE CITY 03 OM PRAÇA DO SOL EMPREENDIMENTOS LTDA'
			-- AND "identificador_unid" like '2402%'
			-- AND "venda" = '131'

	) AS base
	 --WHERE base."COD_EMP" = 52
		--AND base."COD_OBR" = '5201I'
		--AND base."COD_OBR" like '%I'
		--AND base."COD_VENDA" = 2	AND 
		WHERE base."TIPO"  = 'PARCELA'  

) AS CONTA
WHERE CONTA."LINHA" = 1
)
, VENDA AS (
SELECT DISTINCT  
	CHAVE
	,CHAVE_VENDA
	,CHAVE_PROD
	,CHAVEUNID
	,EMPRESA_VEN
	,OBRA_VEN
	,NUM_VEN
	,VENDEDOR_VEN
	,CLIENTE_VEN
	,VALORTOT_VEN
	,ACRESCIMO_VEN
	,DESCONTO_VEN
	,DATA_VEN
	,DATACESSAO_VEN
	,DATACANCEL_VEN
	--,DATA_ASS_DISTRATO
	,DATACAD_VEN
	,PRODUTO_ITV
	,NOMEPRODUTO
	,CODPERSON_ITV
	,FRACAOIDEAL_UNID
	,IDENTIFICADOR_UNID
	,QTDE_UNID
	,STATUS_VEN
	,STATUS_UNID
	,STATUS_VENDA
	,VALPROVISAOCURTO_VEN
	,VALPROVISAOLONGO_VEN
	,VALPROVISAOCURTOBAIXA_VEN
	,VALPROVISAOLONGOBAIXA_VEN
	,VALPROVISAOCURTOCESSAO_VEN
	,VALPROVISAOLONGOCESSAO_VEN
	,CODTIPPROD_UNID
	,PRECOPROC_ITV
	,VALCOMISSAODIR
	,CONCATIDENTIFICADOR_UNID
FROM BI.dbo.VW_GER_CONTROLE_VENDA_UNIDADE
  
WHERE (
	IDENTIFICADOR_UNID not like ('%A%')
	AND IDENTIFICADOR_UNID not like ('%P%')
	AND IDENTIFICADOR_UNID not like ('E%')
	AND IDENTIFICADOR_UNID not like ('G%')
	AND IDENTIFICADOR_UNID not like ('L%')
	AND IDENTIFICADOR_UNID not like ('M%')
	AND IDENTIFICADOR_UNID not like ('V%')
	)
	--AND EMPRESA_VEN = 52
	--AND OBRA_VEN = '5201I'
	--AND OBRA_VEN like '%I'
	--AND NUM_VEN = 2
)
, RECEBIDA AS (
SELECT 		
	base."COD_EMP" -- codigo da empresa 
	,base."EMPRESA"
	,base."COD_OBR" -- codigo da obra
	,base."OBRA"
	,base."COD_VENDA" -- codigo do contrato de venda
	,base."IDENTIFICADOR_UNID"
	,DATEADD(DAY,1,EOMONTH ((base."DATA_VENCIMENTO"),-1)) AS MES_REFERENCIA_INDICE
	--,VENDA."num_ven" --Numero do Contrato
	--,VENDA."data_ven" AS "DATA_VENDA" --Data da Venda
	--,VENDA."identificador_unid" -- Unidade    
	,base."COD_CLIENTE" -- codigo da cliente
	,base."CLIENTE"
	,base."DATA_NEGOCIACAO" -- data de negociação
	,base."DATA_VENCIMENTO" -- data vencimento
	,base."DATA_PAGAMENTO" --[DATA_PAGAMENTO]
	,ROW_NUMBER() OVER(
		PARTITION BY base."COD_EMP" , base."COD_OBR" , base."COD_VENDA"
		ORDER BY base."DATA_VENCIMENTO" ASC) AS LINHA
	,base."TIPO" -- tipo_rec (descricao de tipo exemplo: Renegociacao)
	,base."STATUS"
	,base."NUM_PARCELA" --qual de parcela
	,base."NUM_PARCELA_GERAL"  --total de parcela
	,base."DIAS_EM_ABERTO"-- calcula tempo da fatura em aberto
	,base."VALOR_PRINCIPAL"  -- valor principal
	,base."VALOR_AJUSTADO"  -- valor ajustado
FROM (

	SELECT 		
		"codemp" AS COD_EMP -- codigo da empresa 
		,"empresa" AS EMPRESA
		,"obra_rpd" AS COD_OBR -- codigo da obra
		,"obra" AS OBRA
		,"identificador_unid" AS IDENTIFICADOR_UNID
		,"num_ven" AS COD_VENDA -- codigo do contrato de venda
		,"cod_cliente" AS COD_CLIENTE -- codigo da cliente
		,"cliente" AS CLIENTE
		,NULL AS DATA_NEGOCIACAO -- data de negociação
		,"data vencimento" AS DATA_VENCIMENTO -- data vencimento
		,NULL AS DATA_PAGAMENTO --[DATA_PAGAMENTO]
		,"tipo" AS TIPO -- tipo_rec (descricao de tipo exemplo: Renegociacao)
		,'CONTA EM ABERTO'  AS STATUS
		,"num parc" AS NUM_PARCELA --qual de parcela
		,"num parc geral" AS NUM_PARCELA_GERAL  --total de parcela
		,"dias em aberto" AS DIAS_EM_ABERTO -- calcula tempo da fatura em aberto
		,CAST("vlr principal" AS FLOAT) AS VALOR_PRINCIPAL  -- valor principal
		,CAST("vlr parcela" AS FLOAT) AS VALOR_AJUSTADO  -- valor ajustado

	FROM [BI].[dbo].[VW_GER_CONTROLE_CONTA_A_RECEBER]
	-- WHERE "identificador_unid" is not null
	-- WHERE "codemp" = '10'
		-- AND "empresa" = 'SPE CITY 03 OM PRAÇA DO SOL EMPREENDIMENTOS LTDA'
		-- AND "identificador_unid" like '2402%'
		-- AND "num_ven" = '131'

	UNION ALL

	SELECT 		
		"codemp" AS COD_EMP -- codigo da empresa 
		,"empresa" AS EMPRESA
		,"obra_rpd" AS COD_OBR -- codigo da obra
		,"obra" AS OBRA
		,"identificador_unid" AS IDENTIFICADOR_UNID
		,"venda" AS COD_VENDA -- codigo do contrato de venda
		,"cliente_rec" AS COD_CLIENTE -- codigo da cliente
		,"cliente" AS CLIENTE
		,"dataconcil" AS DATA_NEGOCIACAO -- data de negociação
		,"data vencimento" AS DATA_VENCIMENTO -- data vencimento
		,"datadep_rpg" AS DATA_PAGAMENTO --[DATA_PAGAMENTO]
		,"tipo" AS TIPO -- tipo_rec (descricao de tipo exemplo: Renegociacao)
		,'CONTA PAGA'  AS STATUS	
		,"parcelarecebida" AS NUM_PARCELA --qual de parcela
		,"numparcger_rec" AS NUM_PARCELA_GERAL  --total de parcela
		,0 AS DIAS_EM_ABERTO -- calcula tempo da fatura em aberto
		,CAST("valorprincipalprice_rec" AS FLOAT) AS VALOR_PRINCIPAL  -- valor principal
		,CAST("valordepositado" AS FLOAT) AS VALOR_AJUSTADO  -- valor ajustado

	FROM [BI].[dbo].[VW_GER_CONTROLE_CONTA_RECEBIDAS]
	-- WHERE "identificador_unid" is not null
	-- WHERE "codemp" = '10'
		-- AND "empresa" = 'SPE CITY 03 OM PRAÇA DO SOL EMPREENDIMENTOS LTDA'
		-- AND "identificador_unid" like '2402%'
		-- AND "venda" = '131'

) AS base

--WHERE base."COD_EMP" = 52
	--AND base."COD_OBR" = '5201I'
	--AND base."COD_OBR" like '%I'
	--AND base."COD_VENDA" = 2
	--AND base."TIPO"  = 'PARCELA' 

)
,PESSOAS AS (
SELECT 
	cod_pes, 
	nome_pes, 
	cpf_pes, 
	dtnasc_pes, 
	Email_pes
FROM UAU.dbo.Pessoas 
)

SELECT 
	--[LINHA_1]
	--,[LINHA_2]
	--,[Juros]
	--,[MES_REFERENCIA_INDICE]
	--,[Data_vi]
	--,[CONTA_SEM_CORRECAO]
	--,[Perc_Valor_vi]
	--,[Valor_vi],
	BASE.[Empresa_Prc]--Empresa
	,BASE.[Obra_Prc]--Obra
	,BASE.[NumVend_Prc]--N venda
	,BASE.[DATA_VEN]--Data Venda
	,BASE.[DATACANCEL_VEN]--Data Cancelamento
	,BASE.[VALORTOT_VEN]--Valor venda
	,BASE.[STATUS_VENDA]--Status da Venda
	,BASE.[PRODUTO_ITV]--Cod Produto
	,BASE.[CODPERSON_ITV]--Cod Person
	,BASE.[IDENTIFICADOR_UNID]--Identificador
	,BASE.[FRACAOIDEAL_UNID]--Fracao Ideal
	,BASE.[Tipo]--Tipo
	,BASE.[NumParc_Prc]--Parc
	--,[DATA_NEGOCIACAO]--Empresa
	,BASE.[DATA_VENCIMENTO]--Dt Vencimento
	,BASE.[DATA_PAGAMENTO]--Dt Recebimento
	--Dt Deposito
	,CASE 
		WHEN BASE.[Status Parcela] = 1 THEN 0
		WHEN BASE.[Status Parcela] = 2 THEN (BASE.[Principal]+BASE.[ValorCorrecao_Prc]+BASE.TotJurParc)
		ELSE null END as [VLR_TOTAL_RECEBIDO]--Vlr Total Recebido
	,BASE.[Principal]--Principal Real
	,BASE.[VALOR_PAGO] --Valor Reaj.
	--,[Valor_Prc]--Empresa
	--Vlr nao concil
	,BASE.TotJurParc -- Juros Real
	,BASE.VlJurosParcConf_Rec	--Juros
	,BASE.[ValorCorrecao_Prc]--Correcao
	,BASE.[ValorJuros_Prc]--Juros Atraso
	,BASE.[ValorMulta_Prc]--Multa
	,BASE.[IdxReaj_Prc]--Idx Reaj
	--tx 1 juros
	--dt 1 juros
	--dt reaj
	,BASE.[ComoParc_Prc]--Freq Parc
--	,ISNULL(P.[Amort_Vlp],PP.[Amort_Vlp]) AS [Amort_Vlp]--tipo Amort
--	,ISNULL(P.[BeginEnd_Vlp],PP.[BeginEnd_Vlp]) AS [BeginEnd_Vlp]--begin/end
	,BASE.[NumParcGer_Prc]--n de parcela
	--juros atraso
	--multa atraso
	,BASE.[TotParc_Prc]--Tot Parc
	,BASE.[Cliente_Prc]--Cod Cli
	,BASE.[nome_pes]--Nome
	,BASE.[cpf_pes]--Cnpj/cpf
	,BASE.[DtParc_Prc]--Dt Ini
	,BASE.[ValorResiduo_Prc]--Valor Residuo
	,BASE.[GrupoIdx_Prc]--Plano Idx
	,BASE.[VlrDescAdiant_Prc]--Desc Adiantamento
	,BASE.[ValorCorrecaoAtr_Prc]--Corr Atraso
	,BASE.[ValorTaxaBol_Prc]--Taxa Boleto
	,BASE.[ValDescontoCusta_Prc]--Vl desc custa
	,BASE.[ValDescontoImposto_Prc]--Vl desc imposto
	,BASE.[ValorAcres_Prc]--Acrescimo
	,BASE.[ValorDesconto_Prc]--Desconto
	,BASE.[ValorDescontoCondicional_Prc]--Desconto condicional
	,BASE.[VlrPrincipal_Prc]--Principal
	--,BASE.[Status Parcela]--Status Parcela
	,CASE 
		WHEN BASE.[Status Parcela] = 1 THEN '1 - Conta a Receber'
		WHEN BASE.[Status Parcela] = 2 THEN '2 - Conta Recebida'
		ELSE null END AS [Status Parcela]--Status Parcela
	,BASE.[Cap principal]--Cap principal
	--tx 2 juros
	--dt 2 juros
	--competencia
	--conta a receber excluida

FROM (

	SELECT
		CONTABIL.Empresa_Prc
		,CONTABIL.Obra_Prc
		,CONTABIL.NumVend_Prc
		,CONTABIL.DATA_VEN
		,CONTABIL.DATACANCEL_VEN
		,CONTABIL.VALORTOT_VEN
		,CONTABIL.STATUS_VENDA
		,CONTABIL.PRODUTO_ITV
		,CONTABIL.CODPERSON_ITV
		,CONTABIL.IDENTIFICADOR_UNID
		,CONTABIL.FRACAOIDEAL_UNID
		,CONTABIL.Tipo	 -- tipo_rec (descricao de tipo exemplo: Renegociacao)
		,CONTABIL.NumParc_Prc
		,CONTABIL.DATA_NEGOCIACAO
		,CONTABIL.DATA_VENCIMENTO
		,CONTABIL.DATA_PAGAMENTO
		,CONTABIL.VALOR_PAGO
		,CONTABIL.VlrPrincipal_Prc AS Principal --Principal
		,CONTABIL.TotJurParc -- Juros Real
		,CONTABIL.VlJurosParcConf_Rec	--Juros
		,CONTABIL.ValorCorrecao_Prc		--Correção
		,CONTABIL.ValorJuros_Prc -- Juros atraso
		,CONTABIL.ValorMulta_Prc -- Multa
		,CONTABIL.IdxReaj_Prc		--Idx. Reaj.
		,CONTABIL.ComoParc_Prc	--Freq. Parc.
		,CONTABIL.NumParcGer_Prc  --Nº de Parc.
		,CONTABIL.TotParc_Prc		--Tot. Parc.
		,CONTABIL.Cliente_Prc		--Cod. ClCONTABIL.
		,CONTABIL.nome_pes
		,CONTABIL.cpf_pes
		,CONTABIL.DtParc_Prc --Dt.Ini
		,CONTABIL.ValorResiduo_Prc --Valor Resíduo
		,CONTABIL.GrupoIdx_Prc --Plano Idx
		,CONTABIL.VlrDescAdiant_Prc --Desc. Adiantamento
		,CONTABIL.ValorCorrecaoAtr_Prc -- CoCONTABIL. Atraso
		,CONTABIL.ValorTaxaBol_Prc -- Taxa boleto
		,CONTABIL.ValDescontoCusta_Prc --Vl. desc. custa
		,CONTABIL.ValDescontoImposto_Prc  --Vl. desc. imposto
		,CONTABIL.ValorAcres_Prc -- Acréscimo
		,CONTABIL.ValorDesconto_Prc  -- Desconto
		,CONTABIL.ValorDescontoCondicional_Prc -- Desconto condicional
		,CONTABIL.VlrPrincipal_Prc  --Principal
		,CONTABIL.[Status Parcela]  --Status Parcela
		,CONTABIL.[Cap principal]


/*
		ROW_NUMBER() OVER(
			PARTITION BY CONTABIL.Empresa_Prc, CONTABIL.Obra_Prc,CONTABIL.NumVend_Prc,CONTABIL.CONTA_SEM_CORRECAO 
			ORDER BY CONTABIL.DATA_VENCIMENTO ASC) AS LINHA_1
		,(ROW_NUMBER() OVER(
			PARTITION BY CONTABIL.Empresa_Prc, CONTABIL.Obra_Prc,CONTABIL.NumVend_Prc,CONTABIL.CONTA_SEM_CORRECAO 
			ORDER BY CONTABIL.DATA_VENCIMENTO ASC))-1 AS LINHA_2
		,CASE 
			WHEN CONTABIL.VALOR_PAGO = CONTABIL.VlrPrincipal_Prc THEN 'SEM JUROS'
			ELSE (
			CASE
				--WHEN CONTABIL.CONTA_SEM_CORRECAO = 'SIM' THEN 'SEM JUROS'
				WHEN CONTABIL.CONTA_SEM_CORRECAO = 'NAO' 
					AND DATEADD(MONTH,2,Data_vi) is not null THEN 'JUROS DO MES'
				WHEN CONTABIL.CONTA_SEM_CORRECAO = 'NAO' 
					AND DATEADD(MONTH,2,Data_vi) is null THEN 'REPLICA DO ULTIMO MES'	
			ELSE null END) END AS JUROS
		,CONTABIL.MES_REFERENCIA_INDICE
		,CONTABIL.Data_vi
		,CONTABIL.CONTA_SEM_CORRECAO
		,CONTABIL.Perc_Valor_vi
		,CONTABIL.Valor_vi
		,CONTABIL.Valor_Prc --Valor Reaj. AJUSTA A RECEBER??
*/
	FROM(

		SELECT 
			RR.Empresa_Prc
			,RR.Obra_Prc
			,RR.NumVend_Prc
			,v.DATA_VEN
			,V.DATACANCEL_VEN
			,V.VALORTOT_VEN
			,V.STATUS_VENDA
			,V.PRODUTO_ITV
			,V.CODPERSON_ITV
			,V.IDENTIFICADOR_UNID
			,V.FRACAOIDEAL_UNID
			,CONCAT(RR.Tipo_Prc,' - ',UPPER(P.Descricao_par)) AS Tipo	-- tipo_rec (descricao de tipo exemplo: Renegociacao)
			,RR.NumParc_Prc
			,R.DATA_NEGOCIACAO
			,CASE
				WHEN RR.TIPO = 1 THEN RR.DataProrrogacao_prc
				WHEN RR.TIPO = 2 THEN R.DATA_VENCIMENTO
				ELSE NULL END AS DATA_VENCIMENTO
			,R.DATA_PAGAMENTO
			,R.VALOR_AJUSTADO AS VALOR_PAGO
			,RR.VlrPrincipal_Prc AS Principal --Principal
			,RR.TotJurParc -- Juros Real
			,RR.VlJurosParcConf_Rec	--Juros
			,RR.ValorCorrecao_Prc		--Correção
			,RR.ValorJuros_Prc -- Juros atraso
			,RR.ValorMulta_Prc -- Multa
			,RR.IdxReaj_Prc		--Idx. Reaj.
			,RR.ComoParc_Prc	--Freq. Parc.
			,RR.NumParcGer_Prc  --Nº de Parc.
			,RR.TotParc_Prc		--Tot. Parc.
			,RR.Cliente_Prc		--Cod. Cli.
			,pe.nome_pes
			,pe.cpf_pes
			,RR.DtParc_Prc --Dt.Ini
			,RR.ValorResiduo_Prc --Valor Resíduo
			,RR.GrupoIdx_Prc --Plano Idx
			,RR.VlrDescAdiant_Prc --Desc. Adiantamento
			,RR.ValorCorrecaoAtr_Prc -- Corr. Atraso
			,RR.ValorTaxaBol_Prc -- Taxa boleto
			,RR.ValDescontoCusta_Prc --Vl. desc. custa
			,RR.ValDescontoImposto_Prc  --Vl. desc. imposto
			,RR.ValorAcres_Prc -- Acréscimo
			,RR.ValorDesconto_Prc  -- Desconto
			,RR.ValorDescontoCondicional_Prc -- Desconto condicional
			,RR.VlrPrincipal_Prc  --Principal
			,RR.TIPO AS [Status Parcela]  --Status Parcela
			,RR.Cap_Prc	AS [Cap principal]


/*
			R.MES_REFERENCIA_INDICE
			,I.Data_vi
			,CASE
				WHEN (
					CASE 
						WHEN 
						ROW_NUMBER() OVER(PARTITION BY RR.Empresa_Prc, RR.Obra_Prc,RR.NumVend_Prc,CONCAT(RR.Tipo_Prc,' - ',UPPER(P.Descricao_par))  
						ORDER BY R.DATA_VENCIMENTO ASC) = 1
						THEN 'S' 
						ELSE NULL END) IS NOT NULL
					AND R.DATA_VENCIMENTO < C.DATA_CORRECAO
					THEN 'SIM'
				ELSE 'NAO' END AS CONTA_SEM_CORRECAO
			,I.Valor_vi as Perc_Valor_vi
			,(I.Valor_vi/100) as Valor_vi
			--,CASE 
				--WHEN RR.TIPO = '1' THEN AR.[Data Vencimento]
				--WHEN RR.TIPO = '2' THEN R.[Data Vencimento]
				--ELSE NULL END AS DT_VENCIMENTO --Status Parcela (Dt. Visão)
			,CASE 
				WHEN RR.Consulta = 'Receber_1_1' 
					THEN RR.VlrPrincipal_Prc
				WHEN RR.Consulta = 'Receber_1_2' 
					THEN RR.VlrPrincipal_Prc
				WHEN RR.Consulta = 'Receber_2_1' 
					THEN RR.PercentValor_Rpd
				WHEN RR.Consulta = 'Receber_2_2' 
					THEN (
						CASE
							WHEN RR.Data_Rec < '08/31/2024' THEN --Esse valor não será calculado	 --data variavel
								(
									(
										(RR.Valor_Rec + RR.VlJurosParc_Rec + RR.VlCorrecao_Rec + RR.VlAcres_Rec + RR.VlTaxaBol_Rec + RR.VlMulta_Rec + RR.VlJuros_Rec + RR.VlCorrecaoAtr_Rec)
										- (RR.VlDesconto_Rec + RR.ValDescontoCusta_Rec + RR.ValDescontoImposto_Rec + RR.ValDescontoCondicional_rec )
									) 
									+ 
									(
										(RR.ValorConf_Rec + RR.VlJurosParcConf_Rec + RR.VlCorrecaoConf_Rec + RR.VlAcresConf_Rec + RR.VlTaxaBolConf_Rec + RR.VlMultaConf_Rec + RR.VlJurosConf_Rec + RR.VlCorrecaoAtrConf_Rec)
										- (RR.VlDescontoConf_Rec + RR.ValDescontoCustaConf_Rec + RR.ValDescontoImpostoConf_Rec + RR.ValDescontoCondicionalConf_rec )
									)
								)
							ELSE --Valor será calculado 
								(RR.Valor_Rec + RR.ValorConf_Rec)
							END
					)
				ELSE NULL END AS Valor_Prc --Valor Reaj. AJUSTA A RECEBER??
			,CASE 
				WHEN RR.Consulta = 'Receber_1_1' 
					THEN '1 - Conta a Receber'
				WHEN RR.Consulta = 'Receber_1_2' 
					THEN '1 - Conta a Receber'
				WHEN RR.Consulta = 'Receber_2_1' 
					THEN '2 - Conta Recebida'
				WHEN RR.Consulta = 'Receber_2_2' 
					THEN  --ISNULL(   StatusRecebimento, 
						CASE WHEN Data_Rec >= '08/31/2024' THEN '1 - Conta a Receber' ELSE '2 - Conta Recebida' END  --data variavel
					--)
				ELSE NULL END AS Calculado --Status Parcela (Dt. Visão)
*/

		FROM BI.dbo.VW_FN_ReceberRecebida AS RR

		LEFT JOIN CORRECAO AS C
			ON COALESCE(RR.Empresa_Prc,'') = COALESCE(C.COD_EMP,'')
			AND COALESCE(RR.Obra_Prc,'') = COALESCE(C.COD_OBR,'')
			AND COALESCE(RR.NumVend_Prc,'') = COALESCE(C.COD_VENDA,'')

		LEFT JOIN VENDA AS V
			ON COALESCE(RR.Empresa_Prc,'') = COALESCE(V.EMPRESA_VEN,'')
			AND COALESCE(RR.Obra_Prc,'') = COALESCE(V.OBRA_VEN,'')
			AND COALESCE(RR.NumVend_Prc,'') = COALESCE(V.NUM_VEN,'')


		LEFT JOIN RECEBIDA AS R
			ON COALESCE(RR.Empresa_Prc,'') = COALESCE(R."COD_EMP",'')
			AND COALESCE(RR.Obra_Prc,'') = COALESCE(R."COD_OBR",'')
			AND COALESCE(RR.NumVend_Prc,'') = COALESCE(R."COD_VENDA",'')
			AND COALESCE(RR.NumParc_Prc,'') = COALESCE(R.NUM_PARCELA,'')
			AND COALESCE(RR.NumParcGer_Prc,'') = COALESCE(R.NUM_PARCELA_GERAL,'')

		LEFT JOIN ID AS I
			ON COALESCE(RR.IdxReaj_Prc,'') = COALESCE(I.Idx_vi,'')
			AND COALESCE(DATEADD(DAY,1,EOMONTH ((R."DATA_VENCIMENTO"),-1)),'') = COALESCE(DATEADD(MONTH,2,I.Data_vi),'')

		LEFT JOIN PESSOAS as PE
			ON COALESCE(RR.Cliente_Prc,'') = COALESCE(PE.cod_pes,'')

		INNER JOIN UAU.dbo.Parcelas AS P
			ON COALESCE(RR.Tipo_Prc,'') = COALESCE(P.Tipo_par,'')

		--WHERE RR.Empresa_Prc = 52
			--AND RR.Obra_Prc = '5201I'
			--AND RR.Obra_Prc LIKE '%I'
			--AND RR.NumVend_Prc = 7
	) AS CONTABIL

) AS BASE
--WHERE BASE.Empresa_Prc = 52
		--AND BASE.Obra_Prc like '%I'
		--AND BASE.NumVend_Prc = 7
		--AND base.tipo not like '%1%'
go

