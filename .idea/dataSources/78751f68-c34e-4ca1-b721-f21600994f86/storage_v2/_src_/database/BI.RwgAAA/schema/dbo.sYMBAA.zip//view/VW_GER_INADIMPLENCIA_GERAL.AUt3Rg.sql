
CREATE VIEW [dbo].[VW_GER_INADIMPLENCIA_GERAL] AS 

SELECT 
SUBSTRING("cod_nome_empresa",0,(CHARINDEX('-',"cod_nome_empresa",0)-1)) AS CODEMP
,"cod_nome_empresa" AS COD_NOME_EMPRESA
,"identificador_unid" AS IDENTIFICADOR_UNID
,"nome_pes" AS NOME_PES
,"num_parc" AS NUM_PARC
,"tipo" AS TIPO
,"data_vencimento" AS DATA_VENCIMENTO
,"dias_em_aberto" AS DIAS_EM_ABERTO
,"vlr_principal" AS VLR_PRINCIPAL
,"data_ven" AS DATA_VEN
,"tipo" AS STATUS
,NULL AS OBSERVACAO
,''  AS ARQUIVO
FROM BI.dbo.TB_GER_CONTROLE_INADIMPLENCIA

go

