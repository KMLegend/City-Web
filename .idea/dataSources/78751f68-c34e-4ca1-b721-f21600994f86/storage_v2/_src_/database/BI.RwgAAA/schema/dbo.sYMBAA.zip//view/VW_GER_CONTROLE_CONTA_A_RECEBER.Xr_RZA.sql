



CREATE VIEW [dbo].[VW_GER_CONTROLE_CONTA_A_RECEBER] AS 

WITH PESSOAS AS (
SELECT 
	cod_pes, 
	nome_pes, 
	cpf_pes, 
	dtnasc_pes, 
	Email_pes
FROM UAU.dbo.Pessoas 
)
, EMPRESA AS (
SELECT Empresas.Codigo_emp AS CODEMP,
       Empresas.Desc_emp AS EMPRESA,
	   CASE 
			WHEN Obras.cod_obr = '0001' then '001'
			WHEN Obras.cod_obr = '0002' then '002'
			WHEN Obras.cod_obr = '0003' then '003'
			WHEN Obras.cod_obr = '0004' then '004'
			WHEN Obras.cod_obr = '0005' then '005'
			else Obras.cod_obr end AS CODOBR,
       Obras.descr_obr AS OBRA,
       CAST(Empresas.Codigo_emp AS varchar(5)) + '-' + CAST(Obras.cod_obr AS VARCHAR(5)) AS CHAVE,
       Obras.CodGrupo_obr,
	   concat(Empresas.Codigo_emp,'-',Empresas.Desc_emp) as [Cod-NomeEmpresa],
	   concat(Obras.cod_obr,'-',Obras.descr_obr) as [Cod_NomeObra]
FROM UAU.dbo.Obras
    INNER JOIN UAU.dbo.Empresas
        ON Obras.Empresa_obr = Empresas.Codigo_emp
)
, VENDAS AS (
SELECT * FROM BI.dbo.VW_GER_CONTROLE_VENDAS)

SELECT 
	INADIMPLENCIA.*
FROM (
SELECT 
	--BSE.CHAVE,
 --   BSE.CHAVE_VENDA,
	--BSE.CHAVE_PROD,
    BSE.Empresa AS CODEMP,
	EMPRESA.EMPRESA,
	VENDAS.Identificador_unid,
	VENDAS.nome_pes AS Cliente,
    BSE.Obra AS Obra_Rpd,												   -- codigo da obra
    Upper(EMPRESA.OBRA) AS OBRA,
	VENDAS.Num_Ven,
	BSE.cod_cliente,														-- codigo da cliente
    Upper(BSE.nome_pes) AS Nome_Pes,
    BSE.[Data Vencimento],													-- data vencimento
    BSE.Tipo,																-- tipo_rec (descricao de tipo exemplo: Renegociacao)
    BSE.[Num Parc],															-- ref de qual parcela do contrato de venda
	BSE.[Num Parc Geral],                                                   -- total de parcelas do contrato de venda
--	BSE.Descricao_tipprod,                                                  -- tipologia sinalizada pelo Gabriel Nominato
	DATEDIFF(DAY,BSE.[Data Vencimento],GETDATE()) AS [Dias Em Aberto],      -- calcula tempo da fatura em aberto
    BSE.[VLR Parcela],
    BSE.[VLR Principal],													-- valor principal
    BSE.[VLR Juros por atraso],
    BSE.[VLR Multa por atraso],
    BSE.[VLR Correção],
    BSE.[VLR Correção por atraso],
	VENDAS.Data_Ven

FROM (
SELECT CAST(ContasReceber.Empresa_prc AS VARCHAR) + '-' + CAST(ContasReceber.Obra_Prc AS VARCHAR) AS CHAVE,
       CAST(ContasReceber.Empresa_prc AS VARCHAR) + '-' + CAST(ContasReceber.Obra_Prc AS VARCHAR) + '-'+ CAST(ContasReceber.NumVend_prc AS VARCHAR) AS CHAVE_VENDA,
	   CAST(ContasReceber.Empresa_prc AS VARCHAR) + '-' + CAST(ContasReceber.Obra_Prc AS VARCHAR) + '-'+ CAST(unidadeper.prod_unid AS VARCHAR) AS CHAVE_PROD,
       ContasReceber.Empresa_prc AS Empresa,										   -- codigo da empresa 
       ContasReceber.Obra_Prc AS Obra,												   -- codigo da obra
       ContasReceber.Cliente_Prc AS cod_cliente,									   -- codigo da cliente
       ContasReceber.NumVend_prc AS Venda,										       -- codigo do contrato de venda
       pessoas.nome_pes,
       ContasReceber.Tipo_Prc,
       UPPER(Parcelas.Descricao_par) AS Tipo,										   -- tipo_rec (descricao de tipo exemplo: Renegociacao)
       ContasReceber.NumParc_Prc AS [Num Parc],                                        --ref de qual parcela do contrato de venda
       ContasReceber.NumParcGer_Prc AS [Num Parc Geral],                               --total de parcelas do contrato de venda
	   tipologiaproducao.Descricao_tipprod,                                                --tipologia sinalizada pelo Gabriel Nominato
       crc.ValParcela_crc AS [VLR Parcela],
       ContasReceber.Data_Prc AS [Data Vencimento],									   -- data vencimento
       ContasReceber.DataPror_Prc AS [Data Prorrogação],							   -- data prorrogaçao do documento
       crc.ValPrincipal_crc AS [VLR Principal],											   -- valor principal
       crc.ValJurosComp_crc AS [VLR Juros compensatorios],
       crc.ValCorrecao_crc AS [VLR Correção],
       crc.ValJuroAtraso_crc AS [VLR Juros por atraso],
       crc.ValMultaAtraso_crc AS [VLR Multa por atraso],
       crc.ValCorrecaoAtraso_crc AS [VLR Correção por atraso],
       crc.ValDescontoCusta_crc,
       crc.ValDescontoImposto_crc,
       crc.ValTaxaBol_crc AS [VLR Taxa de boleto],
       crc.ValParcelaAntec_crc,
       crc.ValJurosCompAntec_crc,
       crc.ValCorrecaoAntec_crc AS ValDescontoCusta_Prc,
       ContasReceber.TotParc_Prc,
       ContasReceber.DtParc_Prc,
       crc.DataCalc_crc
FROM UAU.dbo.ContasReceber
    INNER JOIN UAU.dbo.ContasReceberCalc AS crc
        ON ContasReceber.Empresa_prc = crc.Empresa_crc
           AND ContasReceber.Obra_Prc = crc.Obra_crc
           AND ContasReceber.NumVend_prc = crc.NumVend_crc
           AND ContasReceber.NumParc_Prc = crc.NumParc_crc
           AND ContasReceber.NumParcGer_Prc = crc.NumParcGer_crc
           AND ContasReceber.Tipo_Prc = crc.Tipo_crc
    INNER JOIN UAU.dbo.Parcelas
        ON ContasReceber.Tipo_Prc = Parcelas.Tipo_par
    INNER JOIN UAU.dbo.pessoas
        ON ContasReceber.Cliente_Prc = pessoas.cod_pes
    INNER JOIN UAU.dbo.Obras
        ON ContasReceber.Empresa_prc = Obras.Empresa_obr
           AND ContasReceber.Obra_Prc = Obras.cod_obr
	INNER JOIN UAU.dbo.Vendas
		ON ContasReceber.empresa_prc = Vendas.empresa_ven
		AND ContasReceber.NumVend_prc = Vendas.num_ven
		AND ContasReceber.obra_prc = Vendas.obra_ven	
	INNER JOIN UAU.dbo.ItensVenda AS ItensVenda   
		ON ItensVenda.Obra_Itv = Vendas.Obra_Ven    
		AND ItensVenda.NumVend_Itv = Vendas.Num_Ven    
		AND ItensVenda.Empresa_itv = Vendas.Empresa_ven  
	LEFT OUTER JOIN  UAU.dbo.UnidadePer AS unidadeper   
		ON Vendas.Empresa_ven = unidadeper.Empresa_unid   
		AND Vendas.Obra_Ven = unidadeper.Obra_unid   
		AND ItensVenda.Produto_Itv = unidadeper.Prod_unid  
		AND ItensVenda.CodPerson_Itv = unidadeper.NumPer_unid 
	LEFT JOIN UAU.dbo.tipologiaproducao as tipologiaproducao
		ON coalesce (tipologiaproducao.Codigo_tipprod,'') = coalesce (unidadeper.CodTipProd_unid,'')

WHERE CAST(ContasReceber.Empresa_prc AS VARCHAR) + '-' + CAST(ContasReceber.Obra_Prc AS VARCHAR) IS NOT NULL 
OR CAST(ContasReceber.Empresa_prc AS VARCHAR) + '-' + CAST(ContasReceber.Obra_Prc AS VARCHAR) <> ''

) AS BSE

LEFT JOIN VENDAS
	ON BSE.CHAVE_VENDA = VENDAS.CHAVE_VENDA

LEFT JOIN EMPRESA
	ON BSE.CHAVE = EMPRESA.CHAVE

--WHERE BSE.Obra NOT LIKE '%F%'
--AND BSE.Empresa > 0

) AS INADIMPLENCIA


--WHERE INADIMPLENCIA.Identificador_unid IS NOT NULL
--AND INADIMPLENCIA.[Cod-NomeEmpresa] = '10-SPE CITY 03 OM PRAÇA DO SOL EMPREENDIMENTOS LTDA'
--AND INADIMPLENCIA.Identificador_unid = '1702'



go

