
CREATE VIEW [dbo].[VW_GER_CONTROLE_APLICACAO_BANCARIA] AS 


SELECT DISTINCT
	EntSaiEmpAplic.Empresa_Es AS [Cod_Emp],
	EntSaiEmpAplic.Obra_Es AS [Obra],
	'' AS [Item],
	EntSaiEmpAplic.CategMovFin_Es AS [Insumo],
	'' AS [Servico],
	CategoriasDeMovFin.Desc_Cmf AS [DescrInsumo],
	CategoriasDeMovFin.Desc_Cmf AS [DescrServico],
	'0' AS [NumProcesso],
	CAST('0' AS VARCHAR) AS [DocFiscal],
	EntSaiEmpAplic.Data_Es AS [DataMovimento],
	'0.01' AS [VlrAtPagar],
	'0.01' AS [VlrAtPago],
	'0' AS [VlrComp],
	CAST(EntSaiEmpAplic.Cap_Es AS VARCHAR) + ' - ' + CAP.Desc_CGer AS [Cliente], 
	EntSaiEmpAplic.Banco_Es AS [Banco],
	EntSaiEmpAplic.Conta_Es AS [Conta],
	-1 AS [Produto],
	SUM(EntSaiEmpAplic.Valor_Es) AS [TotalReceita], 
	CASE 	
		WHEN EntSaiEmpAplic.EntSai_Es = 0 THEN 'RecEntrada'
		WHEN EntSaiEmpAplic.EntSai_Es = 1 THEN 'DespSaida'
	END AS [TipoControle],
	CASE 	
		WHEN EntSaiEmpAplic.EntSai_Es = 0 THEN 'R'
		WHEN EntSaiEmpAplic.EntSai_Es = 1 THEN 'D'
	END AS [Tipo],	
	NULL AS [ItemPl],
	NULL AS [ItemPlPai],
	NULL AS [QtdeItem],
	NULL AS [VlrUnitItem],
	NULL AS [UnitItemProc],
	NULL AS [UnidComp],
	NULL AS [UnidIns],
	NULL AS [ContratoPl]

FROM UAU.dbo.EntSaiEmpAplic
LEFT JOIN UAU.dbo.CategoriasDeMovFin 
	ON CategoriasDeMovFin.Codigo_Cmf = EntSaiEmpAplic.CategMovFin_Es
LEFT JOIN UAU.dbo.CAP 
	ON CAP.Codigo_CGer = EntSaiEmpAplic.Cap_Es

--WHERE EntSaiEmpAplic.Empresa_Es = 12
--AND ISNULL(EntSaiEmpAplic.Obra_Es, '') IN ('0012A','0012B','0012I','0012J','0012M','0012N','0012O','0012S','0012U','0012V','0012Z','0501A','0501C','0501E','0501F','0501G','0501H','0501I','0501J','0501L','0501M','0501N','0501O','0501P','0501R','0501S','0501T','0501U','0502A')
--AND EntSaiEmpAplic.Data_Es BETWEEN '08/01/2024' AND '08/31/2024'
--AND 3 IN ( 2, 3 )
--AND EntSaiEmpAplic.EntSai_Es = 1


GROUP BY 
	EntSaiEmpAplic.Empresa_Es,
	EntSaiEmpAplic.Obra_Es,
	EntSaiEmpAplic.CategMovFin_Es,
	CategoriasDeMovFin.Desc_Cmf,
	EntSaiEmpAplic.Data_Es,
	EntSaiEmpAplic.Banco_Es,
	EntSaiEmpAplic.Conta_Es,
	EntSaiEmpAplic.CAP_Es,
	CAP.Desc_CGer,
	EntSaiEmpAplic.EntSai_Es
go

