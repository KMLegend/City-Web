


CREATE VIEW [dbo].[VW_GER_CONTROLE_APROVACAO_PAGAMENTO] AS 

SELECT 
	Parc_Proc.Empresa_proc,
	Empresas.desc_emp AS Empresa,
	Parc_Proc.Obra_Proc,
	Obras.descr_obr AS Obra,
--	Parc_proc.*,
	Parc_Proc.Num_Proc,
	Parc_Proc.NumParc_Proc,
	Parc_proc.Contrato_Proc,
	Parc_proc.CodForn_Proc,
	Parc_Proc.ChqNome_Proc,
	Parc_Proc.banContParc_proc,
	Parc_Proc.Conta_Proc,
	Parc_Proc.CategMovFin_Proc,
	Parc_Proc.Grupo_Proc,
	Parc_Proc.TipoChq_Proc,
	--Parc_Proc.StatusParc_proc,
	CASE 
		WHEN Parc_proc.StatusParc_proc = 0 THEN '0 - A PAGAR'
		WHEN Parc_proc.StatusParc_proc = 1 THEN '1 - EMISSÃO'
		WHEN Parc_proc.StatusParc_proc = 2 THEN '2 - PAGO'
		WHEN Parc_proc.StatusParc_proc = 3 THEN '3 - EMISSÃO EM BANCO'
	END AS Status_Proc,
	
	Parc_Proc.Data_Proc,
	Parc_Proc.DtDocFisc_Proc,
	Parc_Proc.DtPagParc_Proc,

	Parc_Proc.UsrConfQdade_Proc,
	Parc_Proc.DataConfQdade_Proc,
	
	Parc_Proc.UsrConfVl_Proc,
	Parc_Proc.DataConfVl_Proc,
	Parc_Proc.UsrConfDt_Proc,
	Parc_Proc.DataConfDt_Proc,

	
	AprovEmissao.Quem_apv AS UsrAprov_Proc,
	--Usuarios.Nome_usr AS NomeAprovou,
	Parc_Proc.DataAprovEmissao_proc AS DataAprovEmissao_Proc,
	AprovEmissao.DataAprov_apv AS DataAprovacao,

	Parc_Proc.ValorParc_Proc,
	Parc_Proc.DescParc_proc,
	Parc_Proc.AcrescParc_proc,
	Parc_proc.ValorLiquido

	--ItemProcSI.InsumoPL_itsi                                                                                   AS InsumoPL_des,
 --   ItemProcSI.Comp_itsi                                                                                       AS CompPL_des,
	--Itens_Proc.QtdeProc_item,
	--Itens_Proc.ValUnitProc_Item,
	--Itens_Proc.ValUnitProc_Item * Itens_Proc.QtdeProc_item AS TotalBruto_des

	--Parc_proc.EmpFatura_Proc,
	--Parc_proc.EmpPaga_Proc,
--	CAST(Parc_proc.Empresa_proc AS VARCHAR) + '-' + Parc_proc.Obra_Proc + '-' + CAST(Parc_proc.Num_Proc AS VARCHAR) + '-' + CAST(Parc_proc.NumParc_Proc AS VARCHAR) AS Chave,

FROM
(
    SELECT 
		Parc_Proc.Empresa_proc,
		Parc_Proc.Obra_Proc,
		Parc_Proc.Num_Proc,
		Parc_Proc.NumParc_Proc,
		Parc_Proc.ValorParc_Proc,
		Dados_Proc.Data_Proc as Data_Proc,
		Parc_Proc.DtDocFisc_Proc as DtDocFisc_Proc,
		Parc_Proc.DtPagParc_Proc,
		Parc_Proc.DataAprovEmissao_proc,
		Parc_Proc.ChqNome_Proc,
		Parc_Proc.banContParc_proc,
		Parc_Proc.Conta_Proc,
		Parc_Proc.CategMovFin_Proc,
		Parc_Proc.Grupo_Proc,
		Parc_Proc.UsrConfQdade_Proc,
		Parc_Proc.UsrConfDt_Proc,
		Parc_Proc.DataConfVl_Proc,
		Parc_Proc.DataConfDt_Proc,
		Parc_Proc.DataConfQdade_Proc,
		Parc_Proc.UsrConfVl_Proc,
		Parc_Proc.TipoChq_Proc,
		Parc_Proc.StatusParc_proc,
		Parc_Proc.DescParc_proc,
		Parc_Proc.AcrescParc_proc,
		(Parc_Proc.ValorParc_proc - Parc_Proc.DescParc_proc + Parc_Proc.AcrescParc_proc) AS [ValorLiquido],
		Dados_Proc.EmpFatura_Proc,
		Dados_Proc.EmpPaga_Proc,
		Dados_Proc.Contrato_Proc,
		Dados_Proc.CodForn_Proc
    FROM UAU.dbo.Dados_Proc
        INNER JOIN UAU.dbo.Parc_Proc
            ON Dados_Proc.Empresa_proc = Parc_Proc.Empresa_proc
               AND Dados_Proc.Num_Proc = Parc_Proc.Num_Proc
               AND Dados_Proc.Obra_Proc = Parc_Proc.Obra_Proc
    WHERE Parc_Proc.StatusParc_proc <> 2

    UNION ALL

    SELECT ContasPagas.Empresa_pag,
           ContasPagas.ObraProc_Pag,
           ContasPagas.NumProc_Pag,
           ContasPagas.NumParc_Pag,
           (ContasPagas.ValorProc_Pag + ContasPagas.descParc_Pag - AcrescParc_Pag) AS valor,
		   ContasPagas.DataProc_Pag as Data_Proc,
		   ContasPagas.DtDocFisc_Pag as DtDocFisc_Proc,
           ContasPagas.DataEmissao_Pag,
           ContasPagas.DataAprovEmissao_pag,
           ContasPagas.ChqNome_Pag,
           ContasPagas.BancoProc_Pag,
           ContasPagas.Conta_Pag,
           ContasPagas.CategMovFin_Pag,
           NULL AS Grupo,
           ContasPagas.UsrConfQdade_Pag,
           ContasPagas.UsrConfDt_Pag,
           ContasPagas.DataConfVl_Pag,
           ContasPagas.DataConfDt_Pag,
           ContasPagas.DataConfQdade_Pag,
           ContasPagas.UsrConfVl_Pag,
           ContasPagas.TipoChq_Pag,
           2 AS Status_Pag,
           ContasPagas.descParc_Pag,
           ContasPagas.AcrescParc_Pag,
           ContasPagas.ValorProc_Pag,
           ContasPagas.EmpFatura_Pag,
           ContasPagas.EmpPaga_Pag,
           ContasPagas.Contrato_Pag,
           ContasPagas.CodForn_Pag
    FROM UAU.dbo.ContasPagas
) AS Parc_proc
    LEFT JOIN UAU.dbo.Contratos
        ON Contratos.Empresa_cont = Parc_proc.Empresa_proc
           AND Contratos.Obra_cont = Parc_proc.Obra_Proc
           AND Contratos.Cod_cont = Parc_proc.Contrato_Proc
    LEFT JOIN UAU.dbo.CategoriasDeMovFin
        ON Parc_Proc.CategMovFin_Proc = CategoriasDeMovFin.Codigo_cmf
    LEFT JOIN UAU.dbo.Bancos
        ON Bancos.Numero_banco = Parc_Proc.banContParc_proc
    LEFT JOIN UAU.dbo.CCorrente
        ON CCorrente.Empresa_banco = Parc_Proc.Empresa_proc
           AND CCorrente.Numero_banco = Parc_Proc.banContParc_proc
           AND CCorrente.Conta_banco = Parc_Proc.Conta_Proc
    LEFT JOIN UAU.dbo.Pessoas AS Pessoas1
        ON PARC_PROC.EmpPaga_Proc = Pessoas1.cod_pes
    LEFT JOIN UAU.dbo.Pessoas AS Pessoas2
        ON PARC_PROC.EmpFatura_Proc = Pessoas2.cod_pes
    LEFT JOIN UAU.dbo.Pessoas
        ON Parc_proc.CodForn_Proc = Pessoas.cod_pes
    LEFT JOIN UAU.dbo.AprovEmissao
        ON Parc_Proc.Empresa_proc = AprovEmissao.Empresa_apv
           AND Parc_Proc.Obra_Proc = AprovEmissao.Obra_apv
           AND Parc_Proc.Num_Proc = AprovEmissao.NumProc_apv
           AND Parc_Proc.NumParc_Proc = AprovEmissao.NumParc_apv
    LEFT JOIN UAU.dbo.Usuarios
        ON AprovEmissao.Quem_apv = Usuarios.Login_usr
    INNER JOIN UAU.dbo.Obras
        ON Parc_proc.Empresa_Proc = Empresa_obr
           AND Parc_proc.Obra_Proc = Obras.cod_obr
    INNER JOIN UAU.dbo.Empresas
        ON Empresa_Proc = Empresas.Codigo_emp

    --INNER JOIN UAU.dbo.ItemProcSI
    --    ON ItemProcSI.Empresa_itsi = Parc_proc.Empresa_proc
    --       AND ItemProcSI.NumProc_itsi = Parc_proc.Num_Proc
    --       AND ItemProcSI.Obra_itsi = Parc_proc.Obra_Proc

    --INNER JOIN UAU.dbo.Itens_Proc
    --    ON Itens_Proc.Empresa_item = ItemProcSI.Empresa_itsi
    --       AND Itens_Proc.NumProc_Item = ItemProcSI.NumProc_itsi
    --       AND Itens_Proc.ObraProc_Item = ItemProcSI.Obra_itsi
    --       AND Itens_Proc.CodInsProc_Item = ItemProcSI.InsumoProc_itsi


--WHERE Parc_Proc.Empresa_proc = '1'
--AND Parc_Proc.Obra_Proc = 'ACERT'
--AND Num_Proc = '257'
--AND (Parc_Proc.DtPagParc_Proc BETWEEN '10/01/2024' AND '10/15/2024' )


--WHERE (
--          (Parc_Proc.TipoChq_Proc = 'Cheque Avulso')
--          OR (Parc_Proc.TipoChq_Proc = 'Débito C/C')
--          OR (Parc_Proc.TipoChq_Proc = 'Débito Eletrônico')
--      )
--      AND (Parc_Proc.DtPagParc_Proc
--      BETWEEN '10/01/2024' AND '10/15/2024'
--          )
--      AND (Parc_Proc.StatusParc_Proc IN ( 2 ))

--ORDER BY 
--	Parc_proc.Empresa_proc,
--	Parc_proc.Obra_proc,
--	Parc_proc.DtPagParc_Proc,
--	Parc_proc.ChqNome_Proc,
--	Parc_proc.Grupo_Proc

go

