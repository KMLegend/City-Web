




CREATE VIEW [dbo].[VW_GER_CONTROLE_SEG_TRAB_CATS] AS 

SELECT [Anexos_cat],
       [Empresa_CapRH],
       [Obra_CapRH],
       [CodPes_CapRH],
       [Nome_pes],
       [NumCapRH_cat],
       [Num_cat],
       [DataAcidente_Cat],
       [DataReferencia_cat],
       [HoraAcidente_cat],
       [HoraTrabAntes_cat],
       [TipoAcidente_cat],
       [Tipo_cat],
       [NumCatOrigem_cat],
       [CodGerAcid_cat],
       [TipoGerAcid_cat],
       [IndObito_cat],
       [IndComunicPolicia_cat],
       [IndInternacao_cat],
       [IndAfastamento_cat],
       [DataAtendAtestado_cat],
       [HoraAtendAtestado_cat],
       [DurTratamento_cat],
       [CodLesao_cat],
       [TipoLesao_cat],
       [TipoLocalAcid_cat],
       [DescLocalAcid_cat],
       [NumLogrLocalAcid_cat],
       [Desc_Logr],
       [CEP_Logr],
       [NumEnd_cat],
       [NumBrrLocalAcid_cat],
       [Desc_brr],
       [DescUF_cid],
       [NumCid_brr],
       [Desc_cid],
       [UF_cMed],
       [CRM_cMed],
       [Nome_cMed],
       [CodCID_cat],
       [DiagProvavel_cat],
       [Observacao_cat],
       [DataAlt_cat],
       [UsrAlt_cat],
       [CodESocial_tces],
       [Tipo_tces],
       [Descricao_tces],
       [CodAgenteCausador_Cat],
       [CodParteAtingida_Cat],
       [TabelasESocial15].[Codigo_tes] AS codGeradora_tes,
       [TabelasESocial15].[Descricao_tes] AS descGeradora_tes,
       [TabelasESocial10].[Codigo_tes] + ' - ' + [TabelasESocial10].[Descricao_tes] AS [DescLesao],
       CASE
           WHEN ObraLocAcid_Cat IS NULL THEN
               EmpresaAcidente.Desc_emp
           ELSE
               ObraAcidente.descr_obr
       END AS DescLocalAcidente_emp,
       [Empresas].[Desc_emp],
       [Obras].[Descr_obr],
       [TabCodigoESocial].[CodESocial_tces] + ' - ' + [TabCodigoESocial].[Descricao_tces] AS [DescTipoLocalAdicente_tces],
       [TabelasESocial05].[Descricao_tes] AS descAgente_tes,
       [TabelasESocial4].[Codigo_tes] AS codParteAtingida_tes,
       [TabelasESocial4].[Descricao_tes] AS descParteAtingida_tes
FROM UAU.dbo.CAT
    LEFT JOIN UAU.dbo.[CapacitacaoRH] AS [CapacitacaoRH]
        ON [CAT].[NumCapRH_cat] = [CapacitacaoRH].[Num_CapRH]
    LEFT JOIN UAU.dbo.[Pessoas] AS [Pessoas]
        ON [CapacitacaoRH].[CodPes_CapRH] = [Pessoas].[Cod_pes]
    LEFT JOIN UAU.dbo.[Empresas] AS [Empresas]
        ON [CapacitacaoRH].[Empresa_CapRH] = [Empresas].[Codigo_emp]
    LEFT JOIN UAU.dbo.[Obras] AS [Obras]
        ON [CapacitacaoRH].[Obra_CapRH] = [Obras].[Cod_obr]
           AND [CapacitacaoRH].[Empresa_CapRH] = [Obras].[Empresa_obr]
    LEFT JOIN UAU.dbo.[TabelasESocial] AS [TabelasESocial15]
        ON [CAT].[CodGerAcid_cat] = [TabelasESocial15].[Codigo_tes]
           AND [CAT].[TipoGerAcid_cat] = [TabelasESocial15].[TipoTabela_tes]
    LEFT JOIN UAU.dbo.[TabelasESocial] AS [TabelasESocial10]
        ON [CAT].[CodLesao_cat] = [TabelasESocial10].[Codigo_tes]
           AND [CAT].[TipoLesao_cat] = [TabelasESocial10].[TipoTabela_tes]
    LEFT JOIN UAU.dbo.[TabCodigoESocial] AS [TabCodigoESocial]
        ON [CAT].[TipoLocalAcid_cat] = [TabCodigoESocial].[CodESocial_tces]
    LEFT JOIN UAU.dbo.[CadastroMedico] AS [CadastroMedico]
        ON [CAT].[CRMMedico_cat] = [CadastroMedico].[CRM_cMed]
           AND [CAT].[UFMedico_cat] = [CadastroMedico].[UF_cMed]
    LEFT JOIN UAU.dbo.[Logradouro] AS [Logradouro]
        ON [CAT].[NumLogrLocalAcid_cat] = [Logradouro].[Num_logr]
    LEFT JOIN UAU.dbo.[Bairro] AS [Bairro]
        ON [CAT].[NumBrrLocalAcid_cat] = [Bairro].[Num_brr]
    LEFT JOIN UAU.dbo.[Cidades] AS [Cidades]
        ON [Bairro].[NumCid_brr] = [Cidades].[Num_cid]
    INNER JOIN UAU.dbo.[TabelasESocial] AS [TabelasESocial4]
        ON [CAT].[CodParteAtingida_Cat] = [TabelasESocial4].[Codigo_tes]
           AND [CAT].[TipoTabParteAtingida_Cat] = [TabelasESocial4].[TipoTabela_tes]
    INNER JOIN UAU.dbo.[TabelasESocial] AS [TabelasESocial05]
        ON [CAT].[CodAgenteCausador_Cat] = [TabelasESocial05].[Codigo_tes]
           AND [CAT].[TipoTabAgenteCausador_Cat] = [TabelasESocial05].[TipoTabela_tes]
    LEFT JOIN UAU.dbo.[Empresas] AS [EmpresaAcidente]
        ON EmpLocAcid_cat = [EmpresaAcidente].[Codigo_emp]
    LEFT JOIN UAU.dbo.[Obras] AS [ObraAcidente]
        ON ObraLocAcid_Cat = [ObraAcidente].[Cod_obr]
           AND EmpLocAcid_cat = [ObraAcidente].[Empresa_obr]

WHERE [TabCodigoESocial].[Tipo_tces] = 13
      AND [CapacitacaoRH].[Funcionario_CapRH] = 1
      --AND [CapacitacaoRH].[Empresa_CapRH] = 53
      --AND [CapacitacaoRH].[Obra_CapRH] = '5301C'

--ORDER BY [DataReferencia_cat] DESC
go

