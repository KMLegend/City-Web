


CREATE VIEW [dbo].[VW_GER_CONTROLE_DADOS_DEPENDENTES] AS 

WITH TELEFONE AS (
SELECT DISTINCT
	Base_Telefone.pes_tel,
	MAX(Base_Telefone.FoneRes) AS FoneRes,
	MAX(Base_Telefone.FoneCom) AS FoneCom,
	MAX(Base_Telefone.FoneCel) AS FoneCel
FROM (
	SELECT DISTINCT
		pes_tel,
		CASE tipo_tel
			WHEN 0 THEN
				CONCAT(ddd_tel , '-' ,fone_tel) 
		END AS FoneRes,
		CASE tipo_tel
			WHEN 1 THEN
				CONCAT(ddd_tel , '-' ,fone_tel) 
		END AS FoneCom,
		CASE tipo_tel
			WHEN 2 THEN
				CONCAT(ddd_tel , '-' ,fone_tel) 
		END AS FoneCel
	FROM UAU.dbo.pestel
	WHERE  tipo_tel < 3 
) AS Base_Telefone
GROUP BY pes_tel
)
, EMPRESA AS (
SELECT 
	C.CodPes_CapRH,
	C.Empresa_CapRH,
	E.Desc_Emp
FROM UAU.dbo.CapacitacaoRH AS C
INNER JOIN UAU.dbo.Empresas AS E
	ON C.Empresa_CapRH = E.Codigo_Emp
WHERE C.CodSitF_CapRH <> 0
)
--, ENDERECO AS (
--SELECT DISTINCT
--    pesendereco.codpes_pend,
--    --pesendereco.tipo_pend,
--    pesendereco.cep_pend,
--    CASE 
--		WHEN pesendereco.numend_pend = ' ' THEN NULL
--		ELSE pesendereco.numend_pend END AS numend_pend,
--    CASE 
--		WHEN Isnull(pesendereco.endereco_pend, '') + ' ' + Isnull(pesendereco.complendereco_pend, '') = ' ' THEN NULL
--		ELSE Isnull(pesendereco.endereco_pend, '') + ' ' + Isnull(pesendereco.complendereco_pend, '') END AS Expr1,
--    pesendereco.bairro_pend,
--    pesendereco.cidade_pend,
--    pesendereco.uf_pend
--FROM UAU.dbo.pesendereco
--WHERE  pesendereco.tipo_pend =0 
--)



SELECT DISTINCT

	D.CodFunc_Dep,
	D.CodDepCad_Dep,
	P.Nome_Pes, --[Nome_Pes],
	D.DataCasam_Dep,
	P.DtNasc_Pes,
	CASE 
		WHEN PF.Pai_PF = ' ' THEN NULL
		ELSE PF.Pai_PF END AS Pai_PF,--[Pai_PF],
	PF.DtPai_PF, 
	CASE 
		WHEN PF.Mae_PF = ' ' THEN NULL
		ELSE PF.Mae_PF END AS Mae_PF,--[Mae_PF],
	PF.DtMae_PF,
	PR.Descr_Pro, --[Profis_PF],
	CASE 
		WHEN PF.Lotacao_PF = ' ' THEN NULL
		ELSE PF.Lotacao_PF END AS Lotacao_PF,--[Lotacao_PF],
	CASE 
		WHEN PF.Cargo_PF = ' ' THEN NULL
		ELSE PF.Cargo_PF END AS Cargo_PF,--[Cargo_PF],
	SUM(SF.Renda_SalF) AS Renda_SalF, --[Renda_PF],
	SF.Moeda_SalF, --[Moeda_PF],
	P.CPF_Pes,
	CASE 
		WHEN PF.Doc_PF = ' ' THEN NULL
		ELSE PF.Doc_PF END AS Doc_PF,
	CASE 
		WHEN PF.TDoc_PF = ' ' THEN NULL
		ELSE PF.TDoc_PF END AS TDoc_PF,
	PF.DtDoc_PF,
	PF.RegCasamento_PF,
	PD.Registro_Doc, --[CI_PF],
	PF.CodNacao_PF,
	N.Nacionalidade_Nacao, --[Nacionalidade_Nacao],
	PD.OrgaoEmissor_Doc, --[OrgExp_PF],
	PF.CidadeNat_PF,
	C.Desc_Cid, --[Desc_Cid],
	PD.DataEmissao_Doc, --[DataEmisCi_PF],
	PD.UF_Doc, --[UFCi_PF],
	CASE
		WHEN PF.Regcasamento_PF = 0 THEN 'comunhão parcial de bens'
		WHEN PF.Regcasamento_PF = 1 THEN 'comunhão total de bens'
		WHEN PF.Regcasamento_PF = 2 THEN 'separação total de bens'
	ELSE NULL END AS DescRegime,
	TEL.FoneRes,
	TEL.FoneCom, --[Fone_Tel],
	TEL.FoneCel,
	CASE 
		WHEN P.email_pes = ' ' THEN NULL
		ELSE P.email_pes END AS email_pes,
	EMP.Desc_Emp --[DescricaoEmpresa],

FROM UAU.dbo.Dependente as D
INNER JOIN UAU.dbo.Pessoas as P
    ON COALESCE(D.CodDepCad_Dep,'') = COALESCE(P.Cod_Pes,'')
    AND D.NumGPar_Dep = 1
--LEFT JOIN ENDERECO AS E
--	ON COALESCE(E.codpes_pend,'') = COALESCE(P.cod_pes,'')
LEFT JOIN TELEFONE AS TEL
	ON COALESCE(TEL.pes_tel,'') = COALESCE(P.cod_pes,'')
--LEFT JOIN  UAU.dbo.pesconj AS PC
--	ON COALESCE(PC.cod_pc,'') = COALESCE(P.cod_pes,'')
LEFT JOIN  UAU.dbo.pesfis AS PF
	ON COALESCE(PF.cod_pf,'') = COALESCE(P.cod_pes,'')
LEFT JOIN UAU.dbo.Profissao AS PR
    ON COALESCE(PF.NumPro_pf,'') = COALESCE(PR.Num_pro,'')
LEFT JOIN  UAU.dbo.salariofunc AS SF
    ON COALESCE(SF.CodPes_SalF,'') = COALESCE(P.cod_pes,'')
LEFT JOIN UAU.dbo.PessoasDoc AS PD
    ON COALESCE(PD.CodPes_Doc,'') = COALESCE(PF.Cod_PF,'')
    AND PD.Tipo_Doc = 1
LEFT JOIN UAU.dbo.Nacao AS N
    ON COALESCE(PF.CodNacao_PF,'') = COALESCE(N.Codigo_Nacao,'')
LEFT JOIN UAU.dbo.Cidades AS C
    ON COALESCE(PF.CidadeNat_PF,'') = COALESCE(C.Num_Cid,'')
LEFT JOIN EMPRESA AS EMP
	ON COALESCE(D.CodDepCad_Dep,'') = COALESCE(EMP.CodPes_CapRH,'')

GROUP BY     
	D.CodFunc_Dep,
	D.CodDepCad_Dep,
	P.Nome_Pes, --[Nome_Pes],
	D.DataCasam_Dep,
	P.DtNasc_Pes,
	CASE 
		WHEN PF.Pai_PF = ' ' THEN NULL
		ELSE PF.Pai_PF END,--[Pai_PF],
	PF.DtPai_PF, 
	CASE 
		WHEN PF.Mae_PF = ' ' THEN NULL
		ELSE PF.Mae_PF END,--[Mae_PF],
	PF.DtMae_PF,
	PR.Descr_Pro, --[Profis_PF],
	CASE 
		WHEN PF.Lotacao_PF = ' ' THEN NULL
		ELSE PF.Lotacao_PF END,--[Lotacao_PF],
	CASE 
		WHEN PF.Cargo_PF = ' ' THEN NULL
		ELSE PF.Cargo_PF END,--[Cargo_PF],
	SF.Moeda_SalF, --[Moeda_PF],
	P.CPF_Pes,
	CASE 
		WHEN PF.Doc_PF = ' ' THEN NULL
		ELSE PF.Doc_PF END,
	CASE 
		WHEN PF.TDoc_PF = ' ' THEN NULL
		ELSE PF.TDoc_PF END,
	PF.DtDoc_PF,
	PF.RegCasamento_PF,
	PD.Registro_Doc, --[CI_PF],
	PF.CodNacao_PF,
	N.Nacionalidade_Nacao, --[Nacionalidade_Nacao],
	PD.OrgaoEmissor_Doc, --[OrgExp_PF],
	PF.CidadeNat_PF,
	C.Desc_Cid, --[Desc_Cid],
	PD.DataEmissao_Doc, --[DataEmisCi_PF],
	PD.UF_Doc, --[UFCi_PF],
	CASE
		WHEN PF.Regcasamento_PF = 0 THEN 'comunhão parcial de bens'
		WHEN PF.Regcasamento_PF = 1 THEN 'comunhão total de bens'
		WHEN PF.Regcasamento_PF = 2 THEN 'separação total de bens'
	ELSE NULL END,
	TEL.FoneRes,
	TEL.FoneCom, --[Fone_Tel],
	TEL.FoneCel,
	CASE 
		WHEN P.email_pes = ' ' THEN NULL
		ELSE P.email_pes END,
	EMP.Desc_Emp --[DescricaoEmpresa],

go

