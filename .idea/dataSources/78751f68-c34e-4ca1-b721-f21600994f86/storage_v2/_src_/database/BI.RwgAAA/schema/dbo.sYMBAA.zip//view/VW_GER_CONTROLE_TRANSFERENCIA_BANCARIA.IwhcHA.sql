

CREATE VIEW [dbo].[VW_GER_CONTROLE_TRANSFERENCIA_BANCARIA] AS 

SELECT DISTINCT 
	Demonstrativo.*
FROM (
	SELECT 
		VwTransfBcoExtrato.EmpresaCred_Tb AS [Cod_Emp],
		VwTransfBcoExtrato.ObraCred_Tb AS [Obra],
		'' AS [Item],
		VwTransfBcoExtrato.CategMovFin_Tb AS [Insumo],
		'' AS [Servico],
		CategoriasDeMovFin.Desc_Cmf AS [DescrInsumo],
		CategoriasDeMovFin.Desc_Cmf AS [DescrServico],
		'0' AS [NumProcesso],
		VwTransfBcoExtrato.NumDoc_Tb AS [DocFiscal],
		VwTransfBcoExtrato.Data_Tb AS [DataMovimento],
		'0.01' AS [VlrAtPagar],
		'0.01' AS [VlrAtPago],
		'0' AS [VlrComp],
		VwTransfBcoExtrato.HistLancCred_Tb AS [Cliente],
		VwTransfBcoExtrato.BcoCred_Tb AS [Banco],
		VwTransfBcoExtrato.ContaCred_Tb AS [Conta],
		-1 AS [Produto],
		SUM(VwTransfBcoExtrato.Valor_Tb) AS [TotalReceita],
		'RecEntrada' AS [TipoControle],
		'R' AS [Tipo],
		NULL AS [ItemPl],
		NULL AS [ItemPlPai],
		NULL AS [QtdeItem],
		NULL AS [VlrUnitItem],
		NULL AS [UnitItemProc],
		NULL AS [UnidComp],
		NULL AS [UnidIns],
		NULL AS [ContratoPl]
	FROM UAU.dbo.VwTransfBcoExtrato

	LEFT JOIN UAU.dbo.CategoriasDeMovFin
	ON VwTransfBcoExtrato.CategMovFin_Tb = CategoriasDeMovFin.Codigo_Cmf

	--WHERE VwTransfBcoExtrato.EmpresaCred_Tb = 12
	--AND ISNULL(ObraCred_Tb, '') IN ('0012A','0012B','0012I','0012J','0012M','0012N','0012O','0012S','0012U','0012V','0012Z','0501A','0501C','0501E','0501F','0501G','0501H','0501I','0501J','0501L','0501M','0501N','0501O','0501P','0501R','0501S','0501T','0501U','0502A')
	--AND Data_Tb BETWEEN '08/01/2024' AND '08/31/2024'
	--AND 4 IN ( 2, 3, 4 )

	GROUP BY 
		VwTransfBcoExtrato.EmpresaCred_Tb,
		VwTransfBcoExtrato.ObraCred_Tb,
		VwTransfBcoExtrato.CategMovFin_Tb,
		CategoriasDeMovFin.Desc_Cmf,
		VwTransfBcoExtrato.NumDoc_Tb,
		VwTransfBcoExtrato.Data_Tb,
		VwTransfBcoExtrato.HistLancCred_Tb,
		VwTransfBcoExtrato.BcoCred_Tb,
		VwTransfBcoExtrato.ContaCred_Tb

	UNION

	SELECT 
		VwTransfBcoExtrato.Empresa_Tb AS [Cod_Emp],
		VwTransfBcoExtrato.ObraDeb_Tb AS [Obra],
		'' AS [Item],
		VwTransfBcoExtrato.CategMovFin_Tb AS [Insumo],
		'' AS [Servico],
		CategoriasDeMovFin.Desc_Cmf AS [DescrInsumo],
		CategoriasDeMovFin.Desc_Cmf AS [DescrServico],
		'0' AS [NumProcesso],
		VwTransfBcoExtrato.NumDoc_Tb AS [DocFiscal],
		VwTransfBcoExtrato.Data_Tb AS [DataMovimento],
		'0.01' AS [VlrAtPagar],
		'0.01' AS [VlrAtPago],
		'0' AS [VlrComp],
		VwTransfBcoExtrato.HistLanc_Tb AS [Cliente],
		VwTransfBcoExtrato.BcoDeb_Tb AS [Banco],
		VwTransfBcoExtrato.ContaDeb_Tb AS [Conta],
		-1 AS [Produto],
		SUM(VwTransfBcoExtrato.Valor_Tb) AS [TotalReceita],
		'DespSaida' AS [TipoControle],
		'D' AS [Tipo],
		NULL AS [ItemPl],
		NULL AS [ItemPlPai],
		NULL AS [QtdeItem],
		NULL AS [VlrUnitItem],
		NULL AS [UnitItemProc],
		NULL AS [UnidComp],
		NULL AS [UnidIns],
		NULL AS [ContratoPL]
	FROM UAU.dbo.VwTransfBcoExtrato

	LEFT JOIN UAU.dbo.CategoriasDeMovFin
	ON VwTransfBcoExtrato.CategMovFin_Tb = CategoriasDeMovFin.Codigo_Cmf

	--WHERE VwTransfBcoExtrato.Empresa_tb = 12
	--AND ISNULL(VwTransfBcoExtrato.ObraDeb_Tb, '') IN ('0012A','0012B','0012I','0012J','0012M','0012N','0012O','0012S','0012U','0012V','0012Z','0501A','0501C','0501E','0501F','0501G','0501H','0501I','0501J','0501L','0501M','0501N','0501O','0501P','0501R','0501S','0501T','0501U','0502A')
	--AND VwTransfBcoExtrato.Data_Tb BETWEEN '08/01/2024' AND '08/31/2024'
	--AND 4 IN ( 2, 3 ,4)

	GROUP BY 
		VwTransfBcoExtrato.Empresa_Tb,
		VwTransfBcoExtrato.ObraDeb_Tb,
		VwTransfBcoExtrato.CategMovFin_Tb,
		CategoriasDeMovFin.Desc_Cmf,
		VwTransfBcoExtrato.NumDoc_Tb,
		VwTransfBcoExtrato.Data_Tb,
		VwTransfBcoExtrato.HistLanc_Tb,
		VwTransfBcoExtrato.BcoDeb_Tb,
		VwTransfBcoExtrato.ContaDeb_Tb

) AS [Demonstrativo]
go

