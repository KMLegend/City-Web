
CREATE VIEW [dbo].[VW_GER_CONTROLE_SIMULACOES_COMPRAS] AS (

SELECT DISTINCT
	[Empresa_sml]
	,[Numero_Sml]
	,[NumCot_sml]
	,[NumCond_Sml]
	,[ValorTot_Sml]
	,[Data_Sml]
	,[Usr_Sml]
	,[IpiTotal_Sml]
	,[Desconto_Sml]
	,[Aprovada_Sml]
	,[Frete_Sml]
	,[Anexos_sml]
	,[NumCotG_sml]
	,[origem_sml]
	,[NumSmlG_sml]
FROM UAU.dbo.Simulacoes
--WHERE Data_Sml >= '2024-01-01'

)
go

