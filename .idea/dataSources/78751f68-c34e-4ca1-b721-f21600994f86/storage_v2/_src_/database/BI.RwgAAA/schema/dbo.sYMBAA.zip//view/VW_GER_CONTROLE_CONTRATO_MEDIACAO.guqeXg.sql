


CREATE VIEW [dbo].[VW_GER_CONTROLE_CONTRATO_MEDIACAO] AS

--Mostra as medições dos contratos feitas no período selecionado, contendo o valor acumulado, valor do contrato e o saldo do contrato.
/* Variaveis:
Contratado - Código do Contratado (% = todos)  -- texto
Contrato - Nº do Contrato (% = todos)  -- texto
DataInicio - Data de Início (criação da medição)  -- date
DataTermino - Data de Término (criação da medição)  -- date
EmpresaObra - Empresa(s) e Obra(s)  -- numerico
Status - Tipo de Status (0=Aberta; 1=Aprovada; 2=Medida; 3=Proc. Serviço Gerado). Para todos separar por virgula. Ex.: 0,1,2,3.  -- texto
*/

SELECT DISTINCT
    Medicao.*,
    CAST(Empresa AS VARCHAR) + '_' + Obra + '_' + CAST(Contrato AS VARCHAR) + '_' + CAST(Medicao AS VARCHAR) [CHAVE],
    CASE
        WHEN Tipo = 0 THEN
    (
    (
        SELECT ISNULL(SUM(Valor_Med), 0)
        FROM UAU.dbo.Medicoes
        WHERE Empresa_Med = Empresa
              AND Contrato_Med = Contrato
              AND Cod_Med < Medicao
    ) +
    (
        SELECT ISNULL(SUM(Valor_Acd), 0)
        FROM UAU.dbo.AcresDescMedicao
        WHERE Empresa_Acd = Empresa
              AND Contrato_Acd = Contrato
              AND CodMed_Acd < Medicao
              AND Tipo_Acd = 0
    ) -
    (
        SELECT ISNULL(SUM(Valor_Acd), 0)
        FROM UAU.dbo.AcresDescMedicao
        WHERE Empresa_Acd = Empresa
              AND Contrato_Acd = Contrato
              AND CodMed_Acd < Medicao
              AND Tipo_Acd = 1
    )
    )
        ELSE
            0
    END [TotalMedAnterior],
    CASE
        WHEN Tipo = 0 THEN
    (
    (
        SELECT ISNULL(SUM(Valor_Med), 0)
        FROM UAU.dbo.Medicoes
        WHERE Empresa_Med = Empresa
              AND Contrato_Med = Contrato
              AND Cod_Med < Medicao
    ) +
    (
        SELECT ISNULL(SUM(Valor_Acd), 0)
        FROM UAU.dbo.AcresDescMedicao
        WHERE Empresa_Acd = Empresa
              AND Contrato_Acd = Contrato
              AND CodMed_Acd < Medicao
              AND Tipo_Acd = 0
    ) -
    (
        SELECT ISNULL(SUM(Valor_Acd), 0)
        FROM UAU.dbo.AcresDescMedicao
        WHERE Empresa_Acd = Empresa
              AND Contrato_Acd = Contrato
              AND CodMed_Acd < Medicao
              AND Tipo_Acd = 1
    ) + TotalMed
    )
        ELSE
            0
    END [AcumuladoMedicao],
    Historico
--, 
--CAST(<DataInicio> AS DATETIME) [DataInicio], 
--CAST(<DataTermino>AS DATETIME) [DataTermino] 
FROM
(
    SELECT Medicoes.Empresa_Med [Empresa],
           Empresas.Desc_Emp [DescEmpresa],
           Medicoes.Contrato_Med [Contrato],
           Contratos.Objeto_Cont [Objeto],
           Medicoes.Cod_Med [Medicao],
           Contratos.Obra_Cont [Obra],
           Obras.Descr_Obr [DescObra],
           Medicoes.Obs_Med [ObservacaoMedicao],
           Medicoes.Status_Med,
           Contratos.CodPes_Cont [Contratado],
           Pessoas.Nome_Pes [NomeContratado],
           Medicoes.Valor_Med [SubTotal],
           ISNULL(AcresDescMedicao.AcrescimoMed, 0) [AcrescimoMed],
           ISNULL(AcresDescMedicao.DescontoMed, 0) [DescontoMed],
           Medicoes.Valor_Med + ISNULL(AcresDescMedicao.AcrescimoMed, 0) - ISNULL(AcresDescMedicao.DescontoMed, 0) [TotalMed],
           ItensMed.ValorMedido + ItensContr.ValorItens - AcompContr.AcompExe [TotalContrato],
           ItensContr.ValorItens - AcompContr.AcompExe [SaldoContrato],
           Medicoes.DataAprov_Med [DataAprovacao],
           Medicoes.DtCriacao_Med [DataCriacaoMed],
           ParcProcMedicao.Num_Proc [Processo],
           ParcProcMedicao.NumParc_Proc [ParcelaProc],
           ISNULL(Parc_Proc.DtPagParc_Proc, ParcProcMedicao.DtPagParc_Proc) [DataPagamento],
           NULL [Item],
           NULL [Descr_Itens],
           0 [Qtde_Item],
           0 [PrecoUnit_Item],
           0 [Total],
           0 [Tipo]
    FROM UAU.dbo.Medicoes
        INNER JOIN UAU.dbo.Contratos
            ON Medicoes.Empresa_Med = Contratos.Empresa_Cont
               AND Medicoes.Contrato_Med = Contratos.Cod_Cont
        INNER JOIN UAU.dbo.Obras
            ON Contratos.Obra_Cont = Obras.Cod_Obr
               AND Contratos.Empresa_Cont = Obras.Empresa_Obr
        INNER JOIN UAU.dbo.Pessoas
            ON Contratos.CodPes_Cont = Pessoas.Cod_Pes
        INNER JOIN UAU.dbo.Empresas
            ON Contratos.Empresa_Cont = Empresas.Codigo_Emp
        LEFT JOIN UAU.dbo.ParcProcMedicao
            ON Medicoes.Empresa_Med = ParcProcMedicao.Empresa_Proc
               AND Medicoes.Contrato_Med = ParcProcMedicao.Contrato_Proc
               AND Medicoes.Cod_Med = ParcProcMedicao.CodMed_Proc
        LEFT JOIN UAU.dbo.Parc_Proc
            ON ParcProcMedicao.Empresa_Proc = Parc_Proc.Empresa_Proc
               AND Contratos.Obra_Cont = Parc_Proc.Obra_Proc
               AND ParcProcMedicao.Num_Proc = Parc_Proc.Num_Proc
               AND ParcProcMedicao.NumParc_Proc = Parc_Proc.NumParc_Proc
        LEFT JOIN
        (
            SELECT Empresa_Acd,
                   Contrato_Acd,
                   CodMed_Acd,
                   SUM(   CASE Tipo_Acd
                              WHEN 0 THEN
                                  Valor_Acd
                              WHEN 1 THEN
                                  0
                          END
                      ) [AcrescimoMed],
                   SUM(   CASE Tipo_Acd
                              WHEN 0 THEN
                                  0
                              WHEN 1 THEN
                                  Valor_Acd
                          END
                      ) [DescontoMed]
            FROM UAU.dbo.AcresDescMedicao
            GROUP BY Empresa_Acd,
                     Contrato_Acd,
                     CodMed_Acd
        ) [AcresDescMedicao]
            ON Medicoes.Empresa_Med = AcresDescMedicao.Empresa_Acd
               AND Medicoes.Contrato_Med = AcresDescMedicao.Contrato_Acd
               AND Medicoes.Cod_Med = AcresDescMedicao.CodMed_Acd
        LEFT JOIN
        (
            SELECT Empresa_Item,
                   Contrato_Item,
                   SUM(Qtde_Item * PrecoUnit_Item) [ValorMedido]
            FROM UAU.dbo.ItensMedicao
            GROUP BY Empresa_Item,
                     Contrato_Item
        ) [ItensMed]
            ON Medicoes.Empresa_Med = ItensMed.Empresa_Item
               AND Medicoes.Contrato_Med = ItensMed.Contrato_Item
        LEFT JOIN
        (
            SELECT Empresa_Itens,
                   Contrato_Itens,
                   SUM(Qtde_Aec * Preco_Itens) [AcompExe]
            FROM UAU.dbo.AcompExecContrato
                RIGHT JOIN UAU.dbo.ItensContrato
                    ON Item_Aec = Item_Itens
                       AND Contrato_Aec = Contrato_Itens
                       AND Empresa_Aec = Empresa_Itens
            WHERE Status_Aec = 2
            GROUP BY Empresa_Itens,
                     Contrato_Itens
        ) [AcompContr]
            ON Medicoes.Empresa_Med = AcompContr.Empresa_Itens
               AND Medicoes.Contrato_Med = AcompContr.Contrato_Itens
        LEFT JOIN
        (
            SELECT Empresa_Itens [EmpIt],
                   Contrato_Itens [ContrIt],
                   SUM(Qtde_Itens * Preco_Itens) [ValorItens]
            FROM UAU.dbo.ItensContrato
            GROUP BY Empresa_Itens,
                     Contrato_Itens
        ) [ItensContr]
            ON Medicoes.Empresa_Med = ItensContr.EmpIt
               AND Medicoes.Contrato_Med = ItensContr.ContrIt

    --WHERE Contratos.Obra_Cont IN ('3401C')--,'5501C','4701C','7601C')
	--AND Medicoes.Empresa_Med = 34	
	--AND CAST(Medicoes.Contrato_Med AS VARCHAR) LIKE <Contrato> 
    --AND Medicoes.DtCriacao_Med BETWEEN <DataInicio> AND <DataTermino>
    --AND CAST(Contratos.CodPes_Cont AS VARCHAR) LIKE <Contratado>
    --AND Medicoes.Status_Med IN(<Status>)

    UNION
    SELECT DISTINCT
        Empresa_Med [Empresa],
        NULL [DescEmpresa],
        Contrato_Med [Contrato],
        Objeto_Cont [Objeto],
        Cod_Med Medicao,
        Obra_Cont [Obra],
        NULL [DescObra],
        NULL [ObservacaoMedicao],
        Status_Med,
        CodPes_Cont [Contratado],
        NULL [NomeContratado],
        0 [SubTotal],
        0 [AcrescimoMed],
        0 [DescontoMed],
        0 [TotalMed],
        0 [TotalContrato],
        0 [SaldoContrato],
        NULL [DataAprovacao],
        DtCriacao_Med [DataCriacaoMed],
        Num_Proc [Processo],
        NumParc_Proc [ParcelaProc],
        NULL [DataPagamento],
        Ins_Item [Item],
        Descr_Itens,
        Qtde_Item,
        PrecoUnit_Item,
        Qtde_Item * PrecoUnit_Item [Total],
        1 [Tipo]
    FROM UAU.dbo.Medicoes
        INNER JOIN UAU.dbo.ItensMedicao
            ON Empresa_Med = Empresa_Item
               AND Contrato_Med = Contrato_Item
               AND Cod_Med = CodMed_Item
        INNER JOIN UAU.dbo.Contratos
            ON Empresa_Med = Empresa_Cont
               AND Contrato_Med = Cod_Cont
        LEFT JOIN UAU.dbo.ParcProcMedicao
            ON Empresa_Med = Empresa_Proc
               AND Contrato_Med = Contrato_Proc
               AND Cod_Med = CodMed_Proc
        LEFT JOIN UAU.dbo.ItensContrato
            ON Empresa_Item = Empresa_Itens
               AND Contrato_Item = Contrato_Itens
               AND Ins_Item = Serv_Itens

--WHERE Obra_Cont IN ('3401C')--,'5501C','4701C','7601C')
	--AND Empresa_Med = 34
	--AND CAST(Contrato_Med AS VARCHAR) LIKE <Contrato> 
	--AND DtCriacao_Med BETWEEN <DataInicio> AND <DataTermino>
	--AND CAST(CodPes_Cont AS VARCHAR) LIKE <Contratado> 
	--AND Status_Med IN(<Status>)
) [Medicao]
    LEFT JOIN
    (
        SELECT Empresa_Proc,
               Obra_Proc,
               CodForn_Proc,
               Contrato_Proc,
               CodInsProc_Item,
               MAX(HistLanc_Proc) [Historico]
        FROM
        (
            SELECT Dados_Proc.Empresa_Proc,
                   Dados_Proc.Obra_Proc,
                   Dados_Proc.CodForn_Proc,
                   Dados_Proc.Contrato_Proc,
                   Itens_Proc.CodInsProc_Item,
                   Parc_Proc.HistLanc_Proc
            FROM UAU.dbo.Dados_Proc
                INNER JOIN UAU.dbo.Parc_Proc
                    ON Dados_Proc.Empresa_Proc = Parc_Proc.Empresa_Proc
                       AND Dados_Proc.Obra_Proc = Parc_Proc.Obra_Proc
                       AND Dados_Proc.Num_Proc = Parc_Proc.Num_Proc
                INNER JOIN UAU.dbo.Itens_Proc
                    ON Dados_Proc.Empresa_Proc = Itens_Proc.Empresa_Item
                       AND Dados_Proc.Obra_Proc = Itens_Proc.ObraProc_Item
                       AND Dados_Proc.Num_Proc = Itens_Proc.NumProc_Item
            WHERE Parc_Proc.StatusParc_Proc <> 2
            UNION
            SELECT Empresa_Pag,
                   ObraProc_Pag,
                   CodForn_Pag,
                   Contrato_Pag,
                   CodInsProc_Item,
                   HistLanc_Pag
            FROM UAU.dbo.ContasPagas
                INNER JOIN UAU.dbo.Itens_Proc
                    ON Empresa_Pag = Empresa_Item
                       AND ObraProc_Pag = ObraProc_Item
                       AND NumProc_Pag = NumProc_Item
        ) [TAB]
        GROUP BY Empresa_Proc,
                 Obra_Proc,
                 CodForn_Proc,
                 Contrato_Proc,
                 CodInsProc_Item
    ) [HistLanc]
        ON Empresa = Empresa_Proc
           AND Obra = Obra_Proc
           AND Contratado = CodForn_Proc
           AND Contrato = Contrato_Proc
           AND Item = CodInsProc_Item
--ORDER BY Empresa,
--         Obra,
--         Contrato,
--         Medicao,
--         Processo,
--         ParcelaProc,
--         Tipo
go

