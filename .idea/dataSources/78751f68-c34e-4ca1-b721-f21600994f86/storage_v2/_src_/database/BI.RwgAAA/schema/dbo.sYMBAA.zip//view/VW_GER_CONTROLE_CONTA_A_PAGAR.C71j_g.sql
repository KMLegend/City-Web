

--25570


CREATE VIEW [dbo].[VW_GER_CONTROLE_CONTA_A_PAGAR] AS 
--[UAU].[dbo].[VwDesembolsoAPagar]

SELECT Empresa_itsi AS Empresa_des,
       Obra_itsi AS Obra_des,
       NumProc_itsi AS NumProc_des,
       Parc_Proc.NumParc_Proc AS NumParc_des,
	   Composicoes.Cod_comp,
	   Composicoes.descr_comp,
       InsumoProc_itsi AS ItemProc_des,
	   InsumosGeral.Descr_ins,
       Parc_Proc.DtPagParc_Proc AS DtPgto_des,
       Porc_itsi * Parc_Proc.AcrescParc_Proc AS Acrescimo_des,
       Porc_itsi * Parc_Proc.DescParc_Proc AS Desconto_des,
       Porc_itsi * (Parc_Proc.ValorParc_Proc + Parc_Proc.AcrescParc_Proc - Parc_Proc.descParc_Proc) AS TotalLiq_des,
       Porc_itsi * Parc_Proc.ValorParc_Proc AS TotalBruto_des,
       Porc_itsi AS Porc_des,
       Contrato_itsi AS ContratoPL_des,
       Prod_itsi AS ProdutoPL_des,
       Item_itsi AS ItemPL_des,
       Comp_itsi AS CompPL_des,
       PLMes_itsi AS PlMes_des,
       InsumoPL_itsi AS InsumoPL_des,
       Qtde_itsi AS QtdeItem_des,
       Preco_itsi AS ValorUnitItem_des,
       Parc_Proc.StatusParc_proc AS StatusParc_des,
       banContParc_proc AS Banco_des,  --Banco_Des
       Conta_Proc AS ContaCorr_des,  --ContaCorr_Des
       Dados_Proc.TipoDoc_Proc AS TipoProc_Des,
       Itens_Proc.CapInsProc_Item AS Cap_des,
       COALESCE(AplicacaoInsumoPisCofins.PorcPis_aipc, Insumo.PorcPis_aipc) AS PorcPis_Des,
       COALESCE(AplicacaoInsumoPisCofins.PorcCofins_aipc, Insumo.PorcCofins_aipc) AS PorcCofins_Des,
       COALESCE(AplicacaoInsumoPisCofins.NumSTPis_aipc, Insumo.NumSTPis_aipc) AS NumSTPis_Des,
       COALESCE(AplicacaoInsumoPisCofins.NumSTCofins_aipc, Insumo.NumSTCofins_aipc) AS NumSTCofins_Des,
       CodForn_Proc AS CodForn_Des,
       Parc_Proc.CategMovFin_Proc AS CategMovFin_Des,
       Parc_Proc.TipoChq_Proc AS TipoEmissao_Des,
       Parc_Proc.DtVencParc_Proc AS DataVencimento_Des
	   ,Parc_Proc.CHQNOME_PROC AS NumChq_Des	--NominalProc_Des
	   ,Parc_Proc.DOCFISCAL_PROC AS NumFiscal_Des	 --DocFiscal_Des
	 ,PlanTotal.Descr_plt AS Desc_Servico
	 ,Dados_Proc.Data_Proc AS DtGeracao_Des
	 ,Parc_Proc.VlDocFisc_Proc AS VlDocFisc
	 ,Dados_Proc.Contrato_Proc AS ContratoServ
	 ,Itens_Proc.UnidProc_Item AS UnidItemProc_Des
	 ,Dados_Proc.OrdemCompra_Proc AS NumOc_Des
	 ,Dados_Proc.NumCot_Proc AS NumCot_Des
	 ,CASE 
		WHEN TipoDoc_Proc = 7 THEN Composicoes.Descr_comp 
		ELSE InsumosGeral.Descr_ins END AS DescItemProc_Des
	 ,Insumos.Descr_ins AS DescInsPl_Des
	 ,PlanTotal.Descr_plt AS DescCompPl_Des
	 ,Dados_Proc.User_Proc AS User_Des
	 -- '' AS NumCheque
	 ,Data_Doc

FROM UAU.dbo.ItemProcSI
    INNER JOIN UAU.dbo.Parc_Proc
        ON ItemProcSI.Empresa_itsi = Parc_Proc.Empresa_proc
           AND ItemProcSI.Obra_itsi = Parc_Proc.Obra_Proc
           AND ItemProcSI.NumProc_itsi = Parc_Proc.Num_Proc
    INNER JOIN UAU.dbo.Dados_Proc
        ON Parc_Proc.Empresa_proc = Dados_Proc.Empresa_proc
           AND Parc_Proc.Obra_Proc = Dados_Proc.Obra_Proc
           AND Parc_Proc.Num_Proc = Dados_Proc.Num_Proc
    INNER JOIN UAU.dbo.Itens_Proc
        ON Itens_Proc.Empresa_item = ItemProcSI.Empresa_itsi
           AND Itens_Proc.NumProc_Item = ItemProcSI.NumProc_itsi
           AND Itens_Proc.ObraProc_Item = ItemProcSI.Obra_itsi
           AND Itens_Proc.CodInsProc_Item = ItemProcSI.InsumoProc_itsi
    LEFT JOIN UAU.dbo.Composicoes
        ON Itens_Proc.CodInsProc_Item = Composicoes.Cod_comp
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins
        ON AplicacaoInsumoPisCofins.Num_aipc = composicoes.NumApi_comp
    LEFT JOIN UAU.dbo.InsumosGeral
        ON Itens_Proc.CodInsProc_Item = InsumosGeral.Cod_ins
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins Insumo
        ON Insumo.Num_aipc = insumosgeral.NumApi_ins
    LEFT OUTER JOIN UAU.dbo.PlanTotal
        ON PlanTotal.Empresa_plt = ItemProcSI.Empresa_itsi
            AND PlanTotal.Obra_plt = ItemProcSI.Obra_itsi
            AND PlanTotal.Item_plt = ItemProcSI.Item_itsi
            AND PlanTotal.Serv_plt = ItemProcSI.Comp_itsi
            AND PlanTotal.Prod_plt = ItemProcSI.Prod_itsi
            AND PlanTotal.Contrato_plt = ItemProcSI.Contrato_itsi
	LEFT OUTER JOIN UAU.dbo.CategoriasDeInsumo 
	RIGHT OUTER JOIN UAU.dbo.Insumos 
		ON CategoriasDeInsumo.Codigo_cger = Insumos.CatIns_ins 
		ON Empresa_itsi = Insumos.Empresa_ins 
			AND Obra_itsi = Insumos.Obra_ins 
			AND InsumoPL_itsi = Insumos.Cod_ins
	LEFT JOIN UAU.dbo.Extrato 
	ON Empresa_itsi = Empresa_Doc
	AND Conta_Proc = Conta_Doc
	AND CHQNOME_PROC = Numero_Doc
	AND banContParc_proc = Banco_Doc

WHERE StatusParc_proc <> 2

--and Empresa_itsi = 1
--and Obra_itsi = 'FATUR'
--and NumProc_itsi = 169

UNION ALL


SELECT Empresa_itsi AS Empresa_des,
       Obra_itsi AS Obra_des,
       NumProc_itsi AS NumProc_des,
       Parc_Proc.NumParc_Proc AS NumParc_des,
	   Composicoes.Cod_comp,
	   Composicoes.descr_comp,
       CodInsProc_item AS ItemProc_des,
	   InsumosGeral.Descr_ins,
       Parc_Proc.DtPagParc_Proc AS DtPgto_des,
       Porc_itsi * Parc_Proc.AcrescParc_Proc AS Acrescimo_des,
       Porc_itsi * Parc_Proc.DescParc_Proc AS Desconto_des,
       Porc_itsi * (Parc_Proc.ValorParc_Proc + Parc_Proc.AcrescParc_Proc - Parc_Proc.descParc_Proc) AS TotalLiq_des,
       Porc_itsi * Parc_Proc.ValorParc_Proc AS TotalBruto_des,
       Porc_itsi AS Porc_des,
       Contrato_itsi AS ContratoPL_des,
       Prod_itsi AS ProdutoPL_des,
       Item_itsi AS ItemPL_des,
       Comp_itsi AS CompPL_itsi,
       PLMes_itsi AS PlMes_des,
       InsumoPL_itsi AS InsumoPL_des,
       0 AS QtdeItem_des,
       0 AS ValorUnitItem_des,
       Parc_Proc.StatusParc_proc AS StatusParc,
       banContParc_proc AS Banco,  --Banco_Des
       Conta_Proc AS ContaCorr,		--ContaCorr_des
       TipoDoc_Proc AS TipoProc_Des,  --**
       Itens_Proc.CapInsProc_Item AS Cap_des,
       COALESCE(AplicacaoInsumoPisCofins.PorcPis_aipc, Insumo.PorcPis_aipc) AS PorcPis_Des,
       COALESCE(AplicacaoInsumoPisCofins.PorcCofins_aipc, Insumo.PorcCofins_aipc) AS PorcCofins_Des,
       COALESCE(AplicacaoInsumoPisCofins.NumSTPis_aipc, Insumo.NumSTPis_aipc) AS NumSTPis_Des,
       COALESCE(AplicacaoInsumoPisCofins.NumSTCofins_aipc, Insumo.NumSTCofins_aipc) AS NumSTCofins_Des,
       CodForn_Proc,
       Parc_Proc.CategMovFin_Proc,
       Parc_Proc.TipoChq_Proc AS TipoEmissao_Des,
       Parc_Proc.DtVencParc_Proc
	   ,Parc_Proc.CHQNOME_PROC AS NumChq_Des --NominalProc_Des
	   ,Parc_Proc.DOCFISCAL_PROC AS NumFiscal_Des	 --DocFiscal_Des
	 ,PlanTotal.Descr_plt AS Desc_Servico
	 ,ItemProcSIVinc.Data_Proc AS DtGeracao_Des
	 ,Parc_Proc.VlDocFisc_Proc AS VlDocFisc
	 ,ContratoServ as ContratoServ
	 ,Itens_Proc.UnidProc_Item AS UnidItemProc_Des
	 ,NumOc_Des
	 ,NumCot_Des
	 ,CASE 
		WHEN TipoDoc_Proc = 7 THEN Composicoes.Descr_comp 
		ELSE InsumosGeral.Descr_ins END AS DescItemProc_Des
	 ,Insumos.Descr_ins AS DescInsPl_Des
	 ,PlanTotal.Descr_plt AS DescCompPl_Des
	 ,User_Des
	 -- '' AS NumCheque
	 ,Data_Doc

FROM
(
    SELECT Empresa_itsi,
           Obra_itsi,
           NumProcVinc_PrVinc AS NumProc_itsi,
           SUM(Porc_itsi) AS Porc_itsi,
           Contrato_itsi,
           Prod_itsi,
           Item_itsi,
           Comp_itsi,
           PLMes_itsi,
           InsumoPL_itsi,
           Dados_Proc.TipoDoc_Proc,
		   Dados_Proc.Data_Proc,
           CodForn_Proc,
		   Contrato_Proc AS ContratoServ,
		   Dados_Proc.OrdemCompra_Proc AS NumOc_Des,
		   Dados_Proc.NumCot_Proc AS NumCot_Des, --**
		   Dados_Proc.User_Proc AS User_Des

    FROM UAU.dbo.Dados_Proc
        INNER JOIN UAU.dbo.ProcVinc
            ON Dados_Proc.Empresa_proc = ProcVinc.Empresa_PrVinc
               AND Dados_Proc.Obra_Proc = ProcVinc.Obra_PrVinc
               AND Dados_Proc.Num_Proc = ProcVinc.NumProcVinc_PrVinc
        INNER JOIN UAU.dbo.ItemProcSI
            ON ProcVinc.Empresa_PrVinc = ItemProcSI.Empresa_itsi
               AND ProcVinc.Obra_PrVinc = ItemProcSI.Obra_itsi
               AND ProcVinc.InsumoProc_PrVinc = ItemProcSI.InsumoProc_itsi
               AND ProcVinc.Item_PrVinc = ItemProcSI.Item_itsi
               AND ProcVinc.Prod_PrVinc = ItemProcSI.Prod_itsi
               AND ProcVinc.Contrato_PrVinc = ItemProcSI.Contrato_itsi
               AND ProcVinc.Comp_PrVinc = ItemProcSI.Comp_itsi
               AND ProcVinc.InsumoPL_PrVinc = ItemProcSI.InsumoPL_itsi
               AND ProcVinc.PLMes_PrVinc = ItemProcSI.PLMes_itsi
               AND ProcVinc.NumProc_PrVinc = ItemProcSI.NumProc_itsi
    GROUP BY Empresa_itsi,
             Obra_itsi,
             NumProcVinc_PrVinc,
             Contrato_itsi,
             Item_itsi,
             Comp_itsi,
             PLMes_itsi,
             InsumoPL_itsi,
             Prod_itsi,
             Dados_Proc.TipoDoc_Proc,
			 Dados_Proc.Data_Proc,
             CodForn_Proc,
			 Contrato_Proc,
			 Dados_Proc.OrdemCompra_Proc,
			 Dados_Proc.NumCot_Proc, --**
			 Dados_Proc.User_Proc
) AS ItemProcSIVinc
    INNER JOIN UAU.dbo.Parc_Proc
        ON Empresa_itsi = Parc_Proc.Empresa_proc
           AND Obra_itsi = Parc_Proc.Obra_Proc
           AND NumProc_itsi = Parc_Proc.Num_Proc
    INNER JOIN UAU.dbo.Itens_Proc
        ON Parc_Proc.Empresa_proc = Itens_Proc.Empresa_item
           AND Parc_Proc.Obra_Proc = Itens_Proc.ObraProc_Item
           AND Parc_Proc.Num_Proc = Itens_Proc.NumProc_Item
    LEFT JOIN UAU.dbo.Composicoes
        ON Itens_Proc.CodInsProc_Item = Composicoes.Cod_comp
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins
        ON AplicacaoInsumoPisCofins.Num_aipc = composicoes.NumApi_comp
    LEFT JOIN UAU.dbo.InsumosGeral
        ON Itens_Proc.CodInsProc_Item = InsumosGeral.Cod_ins
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins Insumo
        ON Insumo.Num_aipc = insumosgeral.NumApi_ins
    LEFT OUTER JOIN UAU.dbo.PlanTotal
        ON PlanTotal.Empresa_plt = ItemProcSIVinc.Empresa_itsi
            AND PlanTotal.Obra_plt = ItemProcSIVinc.Obra_itsi
            AND PlanTotal.Item_plt = ItemProcSIVinc.Item_itsi
            AND PlanTotal.Serv_plt = ItemProcSIVinc.Comp_itsi
            AND PlanTotal.Prod_plt = ItemProcSIVinc.Prod_itsi
            AND PlanTotal.Contrato_plt = ItemProcSIVinc.Contrato_itsi
	LEFT OUTER JOIN UAU.dbo.CategoriasDeInsumo 
	RIGHT OUTER JOIN UAU.dbo.Insumos 
		ON CategoriasDeInsumo.Codigo_cger = Insumos.CatIns_ins 
		ON Empresa_itsi = Insumos.Empresa_ins 
			AND Obra_itsi = Insumos.Obra_ins 
			AND InsumoPL_itsi = Insumos.Cod_ins 
	LEFT JOIN UAU.dbo.Extrato 
	ON Empresa_itsi = Empresa_Doc
	AND Conta_Proc = Conta_Doc
	AND CHQNOME_PROC = Numero_Doc
	AND banContParc_proc = Banco_Doc

WHERE StatusParc_proc <> 2

--and Empresa_itsi = 1
--and Obra_itsi = 'FATUR'
--and NumProc_itsi = 169


go

