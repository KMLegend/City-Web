


CREATE VIEW [dbo].[VW_GER_CONTROLE_RELACAO_FUNCIONARIOS_CLT] AS 

SELECT DISTINCT  
	CapacitacaoRh.Empresa_CapRH,
	(CAST(Empresa_CapRh AS VARCHAR) +' - '+ Desc_Emp) AS Empresa,
	(CAST(Obra_CapRh AS VARCHAR) +' - '+ Descr_Obr) AS Obra, 
	CapacitacaoRh.Obra_CapRH,
	ender_obr [EnderecoObra],
	Pessoas.cod_pes,
	Pessoas.nome_pes [Nome], 
	Capacitacaorh.NomeAbrev_CapRh [Nome Reduzido],  
	RG.Registro_Doc + ' - ' + RG.OrgaoEmissor_Doc [RG], 
	RG.UF_Doc [UF_RG], 
	RG.DataEmissao_Doc [Data de Emissão], 
	Pessoas.dtnasc_pes [Data Nascimento], 
	PesFis.naturalid_pf [Local de Nasc.], 
	PesFis.UfNasc_pf [UF Nascimento], 
	PesFis.pai_pf [Nome do Pai], 
	PesFis.mae_pf [Nome da Mãe], 
	Descr_cad [Cargo],
	CASE 
		WHEN CapacitacaoRh.Estagiario_CapRH = 1 THEN 'ESTAGIO'
		ELSE 'CLT' END AS [REGIME],
	CASE	
		WHEN LEN(Pessoas.cpf_pes) = 11 
			THEN SUBSTRING(Pessoas.cpf_pes,1,3) + '.' + SUBSTRING(Pessoas.cpf_pes,4,3) + '.' + SUBSTRING(Pessoas.cpf_pes,7,3) + '-' + SUBSTRING(Pessoas.cpf_pes,10,2) 
		WHEN LEN(Pessoas.cpf_pes) = 14
			THEN SUBSTRING(Pessoas.cpf_pes,1,2) + '.' + SUBSTRING(Pessoas.cpf_pes,3,3) + '.' + SUBSTRING(Pessoas.cpf_pes,6,3) + '/' + SUBSTRING(Pessoas.cpf_pes,9,4) + '-' + SUBSTRING(Pessoas.cpf_pes,13,2)
		ELSE '' END AS CPF,
	CASE  
		WHEN PesFis.estciv_pf = 0 THEN 'Separado' 
		WHEN PesFis.estciv_pf = 1 THEN 'Solteiro'
		WHEN PesFis.estciv_pf = 2 THEN 'Casado'
		WHEN PesFis.estciv_pf = 3 THEN 'Desquitado'
		WHEN PesFis.estciv_pf = 4 THEN 'Viuvo'
		WHEN PesFis.estciv_pf = 5 THEN 'Divorciado'
		ELSE 'Outros' 
	END [Estado Civil],
	CASE 
		WHEN(PesFis.sexo_pf = 0)
			THEN 'M' 
		ELSE 'F' END [Sexo], 
	CapacitacaoRH.PisPasep_CapRh [Pis], 
	CapacitacaoRH.CartTrab_CapRh [Cart. Trab.], 
	COALESCE(Descr_pro, '') [Ocupação], 
	CapacitacaoRH.dtAdimissao_CapRH [Data Admissão],
	dtDemissao_CapRH [DataDemissao], 
		CASE  
		WHEN Funcionario_CapRH = 1 THEN 'Ativo' 
		WHEN Funcionario_CapRH = 2 THEN 'Cancelado' END as [Result_Ficha],
	CAST(CodSitF_CapRh AS VARCHAR)  +' - '+ Descricao_SitF [Situacao],
	PisPasep_CapRh,
	ISNULL(PesEndereco.Endereco_pend, '') + ' ' + ISNULL(PesEndereco.ComplEndereco_pend, '') [Enredeço],
	PesEndereco.NumEnd_pend [NumEnd], 
	PesEndereco.Bairro_pend [Setor], 
	PesEndereco.Cidade_pend [Cidade], 
	PesEndereco.UF_pend [UF], 
	PesEndereco.CEP_pend [CEP], 
	Pessoas.Email_pes [Email],
	NumFunc_CapRH, 
	Descricao_func, 
	(
		SELECT	TOP 1 Nome_pes 
		FROM	UAU.dbo.Dependente 
				INNER JOIN UAU.dbo.Pessoas 
					ON Cod_pes = CodDepCad_Dep 
		WHERE	CodFunc_Dep = CodPes_CapRh 
				AND NumGPar_Dep = 1
	) [Conjugue],
	Descricao_grau [Escolaridade], 
	(
		SELECT	TOP 1 Renda_SalF
		FROM	UAU.dbo.Salariofunc 
		WHERE	NumCapRH_SalF = Num_CapRH 
		   		AND CodPes_SalF = Cod_Pes
		ORDER BY Num_SalF DESC
	) [Renda],
	Telefone, 
	'' AS Banco, 
	'' AS Agencia, 
	'' As Conta, 
	RG.Registro_Doc AS Ci_pf, 
	RG.OrgaoEmissor_Doc AS OrgExp_pf, 
	RG.UF_Doc AS UfCi_pf,
	CONCAT(SUBSTRING(CAST(COALESCE(SL.renda_SalF,0) AS VARCHAR),0,(CHARINDEX ('.', COALESCE(SL.renda_SalF,0), 0))),',',SUBSTRING(CAST(COALESCE(SL.renda_SalF,0) AS VARCHAR),(CHARINDEX ('.', COALESCE(SL.renda_SalF,0), 0))+1,2)) AS [Salario]
	--CAST(<DataInicio> AS DATETIME) [DataInicio], 
	--CAST(<DataTermino> AS DATETIME) [DataTermino]	   
FROM UAU.dbo.CapacitacaoRh
LEFT JOIN UAU.dbo.Cargos
	ON COALESCE(Cargos.Cod_cad,'') = COALESCE(CapacitacaoRh.CodCargo_CapRh,'')
LEFT JOIN UAU.dbo.Funcao
	ON COALESCE(CapacitacaoRh.NumFunc_CapRH,'') = COALESCE(Funcao.Num_Func,'')
INNER JOIN UAU.dbo.Pessoas 
	ON  COALESCE(Pessoas.cod_pes,'') = COALESCE(CapacitacaoRH.CodPes_CapRH,'')
LEFT JOIN UAU.dbo.PesEndereco
	ON COALESCE(CodPes_pend,'') = COALESCE(Pessoas.cod_pes,'')
	AND COALESCE(Tipo_pend,'') = 0 /* Endereço principal */
LEFT JOIN (
			SELECT	pes_tel, MIN(DDD_tel + '-' + Fone_tel) AS Telefone 
			FROM	UAU.dbo.PesTel
			GROUP BY pes_tel
) AS PesTel
	ON COALESCE(PesTel.pes_tel,'') = COALESCE(Pessoas.cod_pes,'') 
INNER JOIN UAU.dbo.PesFis 
	ON COALESCE(Pessoas.cod_pes,'') = COALESCE(PesFis.cod_pf,'')
LEFT JOIN UAU.dbo.PessoasDoc AS RG
	ON COALESCE(CodPes_Doc,'') = COALESCE(PesFis.cod_pf,'')
	AND COALESCE(RG.Tipo_Doc,'') = 1
LEFT JOIN UAU.dbo.SituacaoFunc
	ON COALESCE(Codigo_SitF,'') = COALESCE(CodSitF_CapRh,'')
LEFT JOIN UAU.dbo.Profissao
	ON COALESCE(PesFis.NumPro_pf,'') = COALESCE(Profissao.Num_pro,'')
LEFT JOIN UAU.dbo.GrauInstrucao
	ON COALESCE(GrauInstrucao.Codigo_grau,'') = COALESCE(PesFis.CodGrau_pf,'')
LEFT JOIN UAU.dbo.SalarioFunc AS SL
	ON COALESCE(SL.CodPes_SalF,'') = COALESCE(CapacitacaoRh.CodPes_CapRH,'') 
	AND COALESCE(SL.NumCapRH_SalF,'') = COALESCE(CapacitacaoRh.Num_CapRH,'')
INNER JOIN UAU.dbo.Empresas
	ON COALESCE(Codigo_emp,'') = COALESCE(Empresa_CapRh,'')
INNER JOIN UAU.dbo.Obras
	ON COALESCE(Cod_obr,'') = COALESCE(Obra_CapRh,'')
	AND COALESCE(Empresa_Obr,'') = COALESCE(Empresa_CapRh,'')
--WHERE	CapacitacaoRh.Empresa_CapRH
--	AND CapacitacaoRh.Obra_CapRH
--	AND CapacitacaoRH.Num_CapRH IN (<CodFuncionario>)
--	AND CapacitacaoRH.dtAdimissao_CapRH BETWEEN <DataInicio> AND <DataTermino>
--	AND CodSitF_CapRH IN(<Situacao>) 

--order by Pessoas.nome_pes


go

