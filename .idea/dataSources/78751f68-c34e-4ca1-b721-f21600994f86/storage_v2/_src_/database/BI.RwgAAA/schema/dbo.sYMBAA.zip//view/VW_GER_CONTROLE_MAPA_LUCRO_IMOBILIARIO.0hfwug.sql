


CREATE VIEW [dbo].[VW_GER_CONTROLE_MAPA_LUCRO_IMOBILIARIO] AS (

SELECT *
FROM
(
    SELECT MapaOrcamentoAtualizado.NumMpprj_moa
         , MapaProjeto.Descr_mpprj
         , MapaOrcamentoAtualizado.DataSaldo_moa
         , MapaOrcamentoAtualizado.UsrCad_moa
         , MapaOrcamentoAtualizado.DataCad_moa
         , MapaOrcamentoAtualizado.PorcCorrecao_moa
         , MapaOrcamentoAtualizado.ValCustoOrcado_moa
         , MapaOrcamentoAtualizado.ValCustoIncorrido_moa
         , MapaOrcamentoAtualizado.ValCustoOrcadoAjuste_moa
         , MapaOrcamentoAtualizado.ValCustoOrcadoAtualizado_moa
         , CapsMapaOrcamentoAtualizado.ValProvManut_moa
         , MapaOrcamentoAtualizado.ValCustoIncorridoAcum_moa
         , MapaOrcamentoAtualizado.PorcObraComplet_moa
         , CapsMapaOrcamentoAtualizado.ValCustoIncorrAprop_moa
         , MapaOrcamentoAtualizado.ValSaldoImovConst_moa
         , MapaOrcamentoAtualizado.ValConstComisMes_moa
         , CapsMapaOrcamentoAtualizado.ValDespComisResult_moa
         , MapaOrcamentoAtualizado.ValSaldoComis_moa
         , MapaOrcamentoAtualizado.PorcCustoImovelVend_moa
         , MapaOrcamentoAtualizado.ValPermutaBaixa_moa
         , CapsMapaOrcamentoAtualizado.ValPermutaCalculo_moa
         , MapaOrcamentoAtualizado.AvpAteHabite_moa
         , MapaOrcamentoAtualizado.AvpTipoDesc_moa
         , MapaOrcamentoAtualizado.ValAvpTaxaDesc_moa
         , CapsMapaOrcamentoAtualizado.ValTotAVP_moa
         , CapsMapaOrcamentoAtualizado.ValProvMntApropriada_moa
         , CapsMapaOrcamentoAtualizado.ValCustoIncorridoEstorno_moa
         , MapaOrcamentoAtualizado.ValTotRecContrAcumulada_moa
         , MapaOrcamentoAtualizado.ValTotRecContrMes_moa
         , MapaOrcamentoAtualizado.ValTotRecContrMesDistrato_moa
         , MapaOrcamentoAtualizado.ValTotRecContrPeriodoPrincipal_moa
         , MapaOrcamentoAtualizado.ValTotRecContrPeriodoJuros_moa
         , MapaOrcamentoAtualizado.ValTotRecContrPeriodoCorrecao_moa
         , MapaOrcamentoAtualizado.ValTotRecContrPeriodoTaxaBoleto_moa
         , MapaOrcamentoAtualizado.ValTotRecContrPeriodoAcrescimo_moa
         , MapaOrcamentoAtualizado.ValTotRecContrPeriodoDescontoCusta_moa
         , MapaOrcamentoAtualizado.ValTotRecContrPeriodoJurosAtraso_moa
         , MapaOrcamentoAtualizado.ValTotRecContrPeriodoMulta_moa
         , MapaOrcamentoAtualizado.ValTotRecContrPeriodoCorrecaoAtraso_moa
         , MapaOrcamentoAtualizado.ValTotRecContrPeriodoDesconto_moa
         , MapaOrcamentoAtualizado.ValTotRecContrPeriodoDescontoCondicional_moa
         , CapsMapaOrcamentoAtualizado.ValTotDistrato_moa
         , MapaOrcamentoAtualizado.ValTotFimCliente_moa
         , MapaOrcamentoAtualizado.ValTotFimAdiantCli_moa
         , CapsMapaOrcamentoAtualizado.ValTotFimAdiantCliMes_moa
         , MapaOrcamentoAtualizado.ValTotFimClienteMes_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoPrincipal_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoJuros_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoCorrecao_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoTaxaBoleto_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoAcrescimo_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoDescontoCusta_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoJurosAtraso_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoMulta_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoCorrecaoAtraso_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoDescontoRecebido_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoDescontoCondicional_moa
         , MapaOrcamentoAtualizado.PorcBaseIRPJ_moa
         , MapaOrcamentoAtualizado.PorcBaseCSLL_moa
         , MapaOrcamentoAtualizado.ValLimiteAdicIRPJ_moa
         , CASE
               WHEN (ROUND(
                              MapaOrcamentoAtualizado.PorcBaseIRPJ_moa / 100
                              * (MapaOrcamentoAtualizado.ValTotRecContrAcumulada_moa - CapsMapaOrcamentoAtualizado.ValTotDistrato_moa + CapsMapaOrcamentoAtualizado.ValPermutaCalculo_moa
                                 - CapsMapaOrcamentoAtualizado.ValTotAVP_moa
                                )
                            , 2
                          ) - ROUND((MapaOrcamentoAtualizado.ValLimiteAdicIRPJ_moa / 12 * MONTH(MapaOrcamentoAtualizado.DataSaldo_moa)), 2)
                    ) < 0 THEN
                   0
               ELSE
         (ROUND(
                   MapaOrcamentoAtualizado.PorcBaseIRPJ_moa / 100
                   * (MapaOrcamentoAtualizado.ValTotRecContrAcumulada_moa - CapsMapaOrcamentoAtualizado.ValTotDistrato_moa + CapsMapaOrcamentoAtualizado.ValPermutaCalculo_moa - CapsMapaOrcamentoAtualizado.ValTotAVP_moa)
                 , 2
               ) - ROUND((MapaOrcamentoAtualizado.ValLimiteAdicIRPJ_moa / 12 * MONTH(MapaOrcamentoAtualizado.DataSaldo_moa)), 2)
         )
           END AS ValorBaseAdicIRPJ
         , MapaOrcamentoAtualizado.PorcAliqAdicIRPJ_moa
         , MapaOrcamentoAtualizado.ValAdicIrpjImpDif_moa
         , MapaOrcamentoAtualizado.PorcAliqIRPJ_moa
         , MapaOrcamentoAtualizado.ValIrpjImpDif_moa
         , CapsMapaOrcamentoAtualizado.ValIrpjResultado_moa
         , MapaOrcamentoAtualizado.PorcAliqCSLL_moa
         , MapaOrcamentoAtualizado.ValCSLLImpDif_moa
         , CapsMapaOrcamentoAtualizado.ValCSLLResultado_moa
         , MapaOrcamentoAtualizado.PorcAliqPIS_moa
         , MapaOrcamentoAtualizado.ValPISImpDif_moa
         , CapsMapaOrcamentoAtualizado.ValPISResultado_moa
         , MapaOrcamentoAtualizado.PorcAliqCOFINS_moa
         , MapaOrcamentoAtualizado.ValCOFINSImpDif_moa
         , CapsMapaOrcamentoAtualizado.ValCOFINSResultado_moa
         , CapsMapaOrcamentoAtualizado.CapTotDistrato_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucao_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoJuros_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoCorrecao_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoTaxaBoleto_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoAcrescimo_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoDescontoCusta_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoJurosAtraso_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoMulta_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoCorrecaoAtraso_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoDescontoRecebido_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoDescontoCondicional_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoLongo_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoLongoJuros_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoLongoCorrecao_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoLongoTaxaBoleto_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoLongoAcrescimo_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoLongoDescontoCusta_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoLongoJurosAtraso_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoLongoMulta_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoLongoCorrecaoAtraso_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoLongoDescontoRecebido_moa
         , CapsMapaOrcamentoAtualizado.CapTotClienteResolucaoLongoDescontoCondicional_moa
         , CapsMapaOrcamentoAtualizado.CapAdiantCliente_moa
         , CapsMapaOrcamentoAtualizado.CapTotAVP_moa
         , CapsMapaOrcamentoAtualizado.CapCustoIncorrAprop_moa
         , CapsMapaOrcamentoAtualizado.CapDespComisResult_moa
         , CapsMapaOrcamentoAtualizado.CapProvManut_moa
         , CapsMapaOrcamentoAtualizado.CapProvMntApropriada_moa
         , CapsMapaOrcamentoAtualizado.CapCustoIncorridoEstorno_moa
         , CapsMapaOrcamentoAtualizado.CapPermutaBaixa_moa
         , CapsMapaOrcamentoAtualizado.CapPISResultado_moa
         , CapsMapaOrcamentoAtualizado.CapCOFINSResultado_moa
         , CapsMapaOrcamentoAtualizado.CapIrpjResultado_moa
         , CapsMapaOrcamentoAtualizado.CapCSLLResultado_moa
         , CAST(MapaOrcamentoAtualizado.CalculoAVPpeloPOC_moa AS TINYINT) AS CalculoAVPpeloPOC_moa
         , MapaOrcamentoAtualizado.PorcProvManutencao_moa
         , MapaOrcamentoAtualizado.ValTotClienteResolucaoLongo_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoLongoPrincipal_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoLongoJuros_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoLongoJurosAtraso_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoLongoCorrecao_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoLongoTaxaBoleto_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoLongoAcrescimo_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoLongoDescontoCusta_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoLongoMulta_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoLongoCorrecaoAtraso_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoLongoDescontoRecebido_moa
         , CapsMapaOrcamentoAtualizado.ValTotClienteResolucaoLongoDescontoCondicional_moa
         , MapaOrcamentoAtualizado.ValProvManutAcumulado_moa
         , MapaOrcamentoAtualizado.ConsiderarPermutaBaseImposto_moa
         , CAST(MapaOrcamentoAtualizado.AjusteRecebimento_moa AS TINYINT) AS AjusteRecebimento_moa
         , MapaOrcamentoAtualizado.TipoDataDeposito_moa
         , MapaOrcamentoAtualizado.TipoRegraCurtoLongoPrazo_moa
         , ISNULL(ResolucaoMesAnt.AvpDiferido, 0) AS AvpDiferido_moa
         , MapaOrcamentoAtualizado.ValorCurtoPrazoAcumulado_moa
         , MapaOrcamentoAtualizado.ValorLongoPrazoAcumulado_moa
         , CAST(MapaOrcamentoAtualizado.Status_moa AS TINYINT) AS Status_moa
         , Empresas.Codigo_emp
         , MapaOrcamentoAtualizado.ConsiderarCurvaDeObra_moa
         , MapaOrcamentoAtualizado.ValTotiniReceitaContrato_moa
         , MapaOrcamentoAtualizado.ValTotSaldoIniRecCorrMes_moa
         , (MapaOrcamentoAtualizado.ValTotiniReceitaContrato_moa + MapaOrcamentoAtualizado.ValTotSaldoIniRecCorrMes_moa) AS ValTotReceitaContrato
         , MapaOrcamentoAtualizado.ValTotAjusteRecebimento_moa
         , MapaOrcamentoAtualizado.ValTotRecebeMes_moa
         , MapaOrcamentoAtualizado.ValTotRecebeAcum_moa
         , ISNULL(MapaUnidade.FracaoIdeal_unid, 0) AS FracaoIdeal_unid
    FROM UAU.dbo.MapaOrcamentoAtualizado
        INNER JOIN UAU.dbo.fn_RetornaCapsMapaOrcamentoAtualizado() AS CapsMapaOrcamentoAtualizado
            ON MapaOrcamentoAtualizado.NumMpprj_moa = CapsMapaOrcamentoAtualizado.NumeroProjeto
               AND MapaOrcamentoAtualizado.DataSaldo_moa = CapsMapaOrcamentoAtualizado.DataSaldo
        INNER JOIN UAU.dbo.MapaProjeto
            ON MapaOrcamentoAtualizado.NumMpprj_moa = MapaProjeto.Num_mpprj
        INNER JOIN UAU.dbo.Empresas
            ON MapaProjeto.Empresa_mpprj = Empresas.Codigo_emp
        LEFT JOIN
        (
            SELECT MapaOrcamentoAtualizado.NumMpprj_moa
                 , MapaOrcamentoAtualizado.DataSaldo_moa
                 , SUM(ISNULL(CapsMapaOrcamentoAtualizado.ValTotAVP_moa, 0)) - ISNULL(MP.ValTotAVP_moa, 0) AS AvpDiferido
            FROM UAU.dbo.MapaOrcamentoAtualizado
                INNER JOIN UAU.dbo.fn_RetornaCapsMapaOrcamentoAtualizado() AS CapsMapaOrcamentoAtualizado
                    ON MapaOrcamentoAtualizado.NumMpprj_moa = CapsMapaOrcamentoAtualizado.NumeroProjeto
                       AND MapaOrcamentoAtualizado.DataSaldo_moa = CapsMapaOrcamentoAtualizado.DataSaldo
                LEFT JOIN
                (
                    SELECT DataSaldo_moa
                         , NumMpprj_moa
                         , SUM(ValTotAVP_moa) AS ValTotAVP_moa
                    FROM UAU.dbo.MapaOrcamentoAtualizado                           AS MP
                        INNER JOIN UAU.dbo.fn_RetornaCapsMapaOrcamentoAtualizado() AS CapsMapaOrcamentoAtualizado
                            ON MP.NumMpprj_moa = CapsMapaOrcamentoAtualizado.NumeroProjeto
                               AND MP.DataSaldo_moa = CapsMapaOrcamentoAtualizado.DataSaldo
                    GROUP BY DataSaldo_moa
                           , NumMpprj_moa
                )                                                  AS MP
                    ON MP.NumMpprj_moa = MapaOrcamentoAtualizado.NumMpprj_moa
                       AND MP.DataSaldo_moa = DATEADD(MONTH, -1, MapaOrcamentoAtualizado.DataSaldo_moa)
            GROUP BY MapaOrcamentoAtualizado.NumMpprj_moa
                   , MapaOrcamentoAtualizado.DataSaldo_moa
                   , MP.ValTotAVP_moa
        )                                                  AS ResolucaoMesAnt
            ON MapaOrcamentoAtualizado.NumMpprj_moa = ResolucaoMesAnt.NumMpprj_moa
               AND MapaOrcamentoAtualizado.DataSaldo_moa = ResolucaoMesAnt.DataSaldo_moa
        LEFT JOIN
        (
            SELECT MapaCustoIncorrido.NumMpprj_mci
                 , MapaCustoIncorrido.DataSaldo_mci
                 , SUM(UnidadePer.FracaoIdeal_unid) AS FracaoIdeal_unid
            FROM UAU.dbo.MapaCustoIncorrido
                INNER JOIN UAU.dbo.UnidadePer
                    ON UnidadePer.Empresa_unid = MapaCustoIncorrido.Empresa_mci
                       AND UnidadePer.Prod_unid = MapaCustoIncorrido.ProdUnid_mci
                       AND UnidadePer.NumPer_unid = MapaCustoIncorrido.NumPerUnid_mci
            --WHERE MapaCustoIncorrido.NumMpprj_mci IN ( 20 )
            GROUP BY MapaCustoIncorrido.NumMpprj_mci
                   , MapaCustoIncorrido.DataSaldo_mci
        )                                                  AS MapaUnidade
            ON MapaOrcamentoAtualizado.NumMpprj_moa = MapaUnidade.NumMpprj_mci
               AND MapaOrcamentoAtualizado.DataSaldo_moa = MapaUnidade.DataSaldo_mci
    --WHERE MapaOrcamentoAtualizado.NumMpprj_moa IN ( 20 )
) AS MapaOrcamentoAtualizado
--ORDER BY NumMpprj_moa
--       , DataSaldo_moa

)

go

