
CREATE VIEW [dbo].[VW_GER_CONTROLE_SEG_TRAB_ASO_EXAMES] AS 

SELECT AsoExames.*,
       TabelasESocial.Descricao_tes,
       TabelasESocial.Codigo_tes,
       Pessoas.cod_pes,
       Pessoas.nome_pes
FROM UAU.dbo.AsoExames
    LEFT JOIN UAU.dbo.TabelasESocial
        ON AsoExames.CodTes_eAso = TabelasESocial.Codigo_tes
           AND AsoExames.TipoTabTes_eAso = TabelasESocial.TipoTabela_tes
    LEFT JOIN UAU.dbo.CapacitacaoRH
        ON AsoExames.NumCapRH_eAso = CapacitacaoRH.Num_CapRH
    LEFT JOIN UAU.dbo.Pessoas
        ON CapacitacaoRH.CodPes_CapRH = Pessoas.cod_pes

--WHERE NumAso_eAso IN (3400)

--ORDER BY Numero_eAso

go

