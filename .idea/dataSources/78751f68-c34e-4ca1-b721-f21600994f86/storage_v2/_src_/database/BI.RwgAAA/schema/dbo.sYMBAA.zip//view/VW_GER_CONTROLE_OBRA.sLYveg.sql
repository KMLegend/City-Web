



CREATE VIEW [dbo].[VW_GER_CONTROLE_OBRA] AS 

SELECT DISTINCT 
	cod_obr,
	descr_obr, 
	Empresa_obr
FROM UAU.dbo.Obras 
--WHERE Empresa_obr IN (1,4,62,91)

go

