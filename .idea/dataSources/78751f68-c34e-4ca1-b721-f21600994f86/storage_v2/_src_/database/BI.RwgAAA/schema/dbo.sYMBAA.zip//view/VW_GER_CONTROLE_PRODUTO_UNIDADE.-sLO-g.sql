

CREATE VIEW [dbo].[VW_GER_CONTROLE_PRODUTO_UNIDADE] AS 

SELECT  *
FROM
(
    SELECT Anexos_unid,
           Prod_unid,
           Empresa_unid,
           NumPer_unid,
           Obra_unid,
           NumObe_unid,
           Cod_obe,
           FracaoIdeal_unid,
           FracaoIdealDecimal_unid,
           Identificador_unid,
           Qtde_unid,
           Codigo_unid,
           PorcentPr_Unid,
           Vendido_unid,
           TipoContrato_udt,
           NumCategStatus_unid,
           Desc_csup,
           CodTipProd_unid,
           Descricao_tipprod,
           ReterPrimAluguel_udt,
           PorcentComissao_unid,
           DataReconhecimentoReceitaMapa_unid,
           DataEntregaChaves_unid,
           DataCad_unid,
           UsrCad_unid,
           COALESCE(TipoUnidMultipropriedade_udt, 0) AS TipoUnidMultipropriedade_udt,
           NumUnidFisica_udt,
           c1_unid,
           c2_unid,
           c3_unid,
           c4_unid,
           c5_unid,
           c6_unid,
           c7_unid,
           c8_unid,
           c9_unid,
           ValPreco_Unid AS PrecoMin,
           CASE
               WHEN UnidadePer.Vendido_unid = 0 THEN
                   'Disponível'
               WHEN UnidadePer.Vendido_unid = 1 THEN
                   CASE
                       WHEN UnidadeDetalhe.TipoContrato_udt IN ( 1, 2, 5 ) THEN
                           'Locada'
                       ELSE
                           'Vendida'
                   END
               WHEN UnidadePer.Vendido_unid = 2 THEN
                   'Reservado'
               WHEN UnidadePer.Vendido_unid = 3 THEN
                   'Proposta'
               WHEN UnidadePer.Vendido_unid = 4 THEN
                   'Quitado'
               WHEN UnidadePer.Vendido_unid = 5 THEN
                   'Escriturado'
               WHEN UnidadePer.Vendido_unid = 6 THEN
                   'Em venda'
               WHEN UnidadePer.Vendido_unid = 7 THEN
                   'Suspenso'
               WHEN UnidadePer.Vendido_unid = 8 THEN
                   'Fora de venda'
               WHEN UnidadePer.Vendido_unid = 9 THEN
                   'Em acerto'
               WHEN UnidadePer.Vendido_unid = 10 THEN
                   'Dação'
           END AS Descr_status,
           CASE
               WHEN UnidadePer.UnidadeVendidaDacao_unid = 1 THEN
                   1
               ELSE
                   0
           END AS UnidadeVendidaDacao_unid,
           ObjEspelhoTop_unid,
           ObjEspelhoLeft_unid,
           Usr_uo
    FROM UAU.dbo.UnidadePer WITH (NOLOCK)
        LEFT JOIN UAU.dbo.ObrUsr WITH (NOLOCK)
            ON Empresa_unid = Emp_uo
               AND Obra_unid = Obr_uo
        LEFT JOIN UAU.dbo.UnidadeDetalhe WITH (NOLOCK)
            ON UnidadePer.Empresa_unid = UnidadeDetalhe.Empresa_udt
               AND UnidadePer.Prod_unid = UnidadeDetalhe.Prod_udt
               AND UnidadePer.NumPer_unid = UnidadeDetalhe.NumPer_udt
        LEFT JOIN UAU.dbo.ObraBlocoEtapa WITH (NOLOCK)
            ON ObraBlocoEtapa.Empresa_obe = UnidadePer.Empresa_unid
               AND ObraBlocoEtapa.Obra_obe = UnidadePer.Obra_unid
               AND ObraBlocoEtapa.Num_obe = UnidadePer.NumObe_unid
        LEFT JOIN UAU.dbo.TipologiaProducao WITH (NOLOCK)
            ON TipologiaProducao.Codigo_tipprod = UnidadePer.CodTipProd_unid
        LEFT JOIN UAU.dbo.CategoriaStatusUnidadePer WITH (NOLOCK)
            ON UnidadePer.NumCategStatus_unid = CategoriaStatusUnidadePer.Num_csup
) AS TotalPerson
WHERE (Prod_unid = 68)
      --AND (Empresa_Unid IN (10,28,26,34))
      --AND (
      --        (Usr_uo = 'JULIA')
      --        OR (Usr_uo IS NULL)
      --    )
      AND (NumPer_unid >= 1)
--ORDER BY NumPer_unid


go

