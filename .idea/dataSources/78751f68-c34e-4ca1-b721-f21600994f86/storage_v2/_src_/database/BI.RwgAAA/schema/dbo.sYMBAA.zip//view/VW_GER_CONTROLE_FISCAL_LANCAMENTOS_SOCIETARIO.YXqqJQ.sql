

CREATE VIEW [dbo].[VW_GER_CONTROLE_FISCAL_LANCAMENTOS_SOCIETARIO] AS 

-- VISUALIZAÇÃO DE LANÇAMENTO SOCIETARIO DO MODULO FISCAL DO UAU.
-- DATA CRIACAO: 19/11/2024.
-- CRIADO POR: KEICY SIMAO

-- Razão Societario

SELECT 
	LancSocietario.*, 
	PlanoContas.Desc_plc, 
	EmpresaInvestida.Desc_emp AS DescricaoEmpresaInvestida,
    PlanoContas.ContaReduz_plc, 
	PlanoContas.Anexos_plc, 
    Empresas.Desc_emp, 
	MascaraPlcEmp.MostrarContaReduzida_msc
FROM UAU.dbo.LancSocietario
LEFT JOIN UAU.dbo.PlanoContas
	ON PlanoContas.NumMsc_plc = LancSocietario.NumMsc_ls
		AND PlanoContas.Ano_plc = LancSocietario.Ano_ls
		AND PlanoContas.Conta_plc = LancSocietario.Conta_ls
INNER JOIN UAU.dbo.Empresas 
	ON LancSocietario.Empresa_ls = Empresas.Codigo_emp 
INNER JOIN UAU.dbo.MascaraPlcEmp 
	ON MascaraPlcEmp.Num_msc = LancSocietario.NumMsc_ls
		AND MascaraPlcEmp.Ano_msc = LancSocietario.Ano_ls
LEFT JOIN UAU.dbo.Empresas AS EmpresaInvestida 
	ON LancSocietario.EmpresaInvestida_ls = EmpresaInvestida.Codigo_emp 

 --WHERE LancSocietario.Empresa_ls IN (28) 
 --  AND LancSocietario.NumMsc_ls = 25
 --  AND LancSocietario.Ano_ls = 2024
 --  AND LancSocietario.Data_ls BETWEEN '01/01/2024'   AND '01/31/2024'

go

