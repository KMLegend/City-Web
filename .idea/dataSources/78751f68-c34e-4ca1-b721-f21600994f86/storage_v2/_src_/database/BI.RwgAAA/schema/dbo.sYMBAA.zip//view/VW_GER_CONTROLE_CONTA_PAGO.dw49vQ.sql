


--811926



CREATE VIEW [dbo].[VW_GER_CONTROLE_CONTA_PAGO] AS 
--create view UAU.DBO.VWDESEMBOLSOPAGO

SELECT
	   Empresa_itsi                                                                                    AS Empresa_des
     , Obra_itsi                                                                                       AS Obra_des
     , NumProc_itsi                                                                                    AS NumProc_des
     , ContasPagas.NumParc_pag                                                                         AS NumParc_des
	 , Composicoes.Cod_comp
	 , Composicoes.descr_comp
     , InsumoProc_itsi                                                                                 AS ItemProc_des
	 , InsumosGeral.Descr_ins
     , ContasPagas.DataEmissao_pag                                                                     AS DtPgto_des
     , Porc_itsi * ContasPagas.AcrescParc_pag                                                          AS Acrescimo_des
     , Porc_itsi * ContasPagas.DescParc_pag                                                            AS Desconto_des
     , Porc_itsi * ContasPagas.ValorProc_Pag                                                           AS TotalLiq_des
     , Porc_itsi * (ContasPagas.ValorProc_Pag - ContasPagas.AcrescParc_pag + ContasPagas.DescParc_Pag) AS TotalBruto_des
     , Porc_itsi                                                                                       AS Porc_des
     , Contrato_itsi                                                                                   AS ContratoPL_des
     , Prod_itsi                                                                                       AS ProdutoPL_des
     , Item_itsi                                                                                       AS ItemPL_des
     , Comp_itsi                                                                                       AS CompPL_des
     , PLMes_itsi                                                                                      AS PlMes_des
     , InsumoPL_itsi                                                                                   AS InsumoPL_des
     , Qtde_itsi                                                                                       AS QtdeItem_des
     , Preco_itsi                                                                                      AS ValorUnitItem_des
     , 2                                                                                               AS StatusParc_des
     , BancoProc_Pag                                                                                   AS Banco_des  --Banco_Des
     , Conta_Pag                                                                                       AS ContaCorr_des    --ContaCorr_Des
     , ContasPagas.TipoProc_pag                                                                        AS TipoProc_des --**
     , Itens_Proc.CapInsProc_Item                                                                      AS Cap_des
     , COALESCE(AplicacaoInsumoPisCofins.PorcPis_aipc, insumo.PorcPis_aipc)                            AS PorcPis_Des
     , COALESCE(AplicacaoInsumoPisCofins.PorcCofins_aipc, insumo.PorcCofins_aipc)                      AS PorcCofins_Des
     , COALESCE(AplicacaoInsumoPisCofins.NumSTPis_aipc, insumo.NumSTPis_aipc)                          AS NumSTPis_Des
     , COALESCE(AplicacaoInsumoPisCofins.NumSTCofins_aipc, insumo.NumSTCofins_aipc)                    AS NumSTCofins_Des
     , CodForn_Pag                                                                                     AS CodForn_Des
     , NumFiscal_Pag                                                                                   AS NumFiscal_Des  --DocFiscal_Des
     , CategMovFin_Pag                                                                                 AS CategMovFin_Des
     , ChqNome_Pag                                                                                     AS ChqNome_Des	--NominalProc_Des
     , NumChq_Pag                                                                                      AS NumChq_Des	--NumCheque_Des
     , DataVencParc_Pag                                                                                AS DataVencParc_Des
     , DtDocFisc_Pag                                                                                   AS DtDocFisc_Des
     , DocFiscal_Pag                                                                                   AS DocFiscal_Des
	 ,CAP.Desc_cger
	 ,ContasPagas.DataPag_pag AS DataPag --**
	 ,ContasPagas.DataAprovEmissao_pag AS DataAprovEmissao
	 ,PlanTotal.Descr_plt AS Desc_Servico
	 ,ContasPagas.DataProc_Pag AS DtGeracao_Des --**
 	 ,ContasPagas.DocFiscal_Pag AS VlDocFisc
	 ,ContasPagas.DataConfVl_Pag  AS DataAprovV
	 ,ContasPagas.Contrato_Pag AS ContratoServ
	 ,Itens_Proc.UnidProc_Item AS UnidItemProc_Des
	 ,ContasPagas.OrdemCompra_Pag AS NumOc_Des
	 ,ContasPagas.NumCot_Pag AS NumCot_Des --**
	 ,CASE 
		WHEN ContasPagas.TipoProc_pag = 7 THEN Composicoes.Descr_comp 
		ELSE InsumosGeral.Descr_ins END AS DescItemProc_Des
	 ,AA.Descr_ins AS DescInsPl_Des
	 ,PlanTotal.Descr_plt AS DescCompPl_Des
	 ,ContasPagas.Status_Pag AS Status_Des --**
	 ,ContasPagas.User_Pag AS User_Des --**
	 ,Data_Doc

FROM UAU.dbo.ItemProcSI
    INNER JOIN UAU.dbo.ContasPagas
        ON Empresa_itsi = ContasPagas.Empresa_pag
           AND NumProc_itsi = ContasPagas.NumProc_Pag
           AND Obra_itsi = ContasPagas.ObraProc_Pag
    INNER JOIN UAU.dbo.Itens_Proc
        ON Itens_Proc.Empresa_item = ItemProcSI.Empresa_itsi
           AND Itens_Proc.NumProc_Item = ItemProcSI.NumProc_itsi
           AND Itens_Proc.ObraProc_Item = ItemProcSI.Obra_itsi
           AND Itens_Proc.CodInsProc_Item = ItemProcSI.InsumoProc_itsi
    LEFT JOIN UAU.dbo.Composicoes
        ON Itens_Proc.CodInsProc_Item = Composicoes.Cod_comp
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins
        ON AplicacaoInsumoPisCofins.Num_aipc = Composicoes.NumApi_comp
    LEFT JOIN UAU.dbo.InsumosGeral
        ON Itens_Proc.CodInsProc_Item = InsumosGeral.Cod_ins
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins insumo
        ON insumo.Num_aipc = InsumosGeral.NumApi_ins
    INNER JOIN UAU.dbo.CAP WITH (NOLOCK)
         ON ContasPagas.CAP_Pag = CAP.Codigo_cger
    LEFT OUTER JOIN UAU.dbo.PlanTotal
        ON PlanTotal.Empresa_plt = ItemProcSI.Empresa_itsi
            AND PlanTotal.Obra_plt = ItemProcSI.Obra_itsi
            AND PlanTotal.Item_plt = ItemProcSI.Item_itsi
            AND PlanTotal.Serv_plt = ItemProcSI.Comp_itsi
            AND PlanTotal.Prod_plt = ItemProcSI.Prod_itsi
            AND PlanTotal.Contrato_plt = ItemProcSI.Contrato_itsi
	LEFT OUTER JOIN UAU.dbo.CategoriasDeInsumo 
	RIGHT OUTER JOIN UAU.dbo.Insumos as AA
		ON CategoriasDeInsumo.Codigo_cger = AA.CatIns_ins 
		ON Empresa_itsi = AA.Empresa_ins 
			AND Obra_itsi = AA.Obra_ins 
			AND InsumoPL_itsi = AA.Cod_ins 
	LEFT JOIN UAU.dbo.Extrato 
		ON Empresa_itsi = Empresa_Doc
		AND Conta_Pag = Conta_Doc
		AND NumChq_Pag = Numero_Doc
		AND BancoProc_Pag = Banco_Doc

--WHERE CAP.Desc_cger in ('REFEIÇÕES E LANCHES','SALARIOS A PAGAR')

--where (Empresa_itsi = 1
--and Obra_itsi = 'CIADM'
--and NumProc_itsi = 88)
--or (Empresa_itsi = 27
--and Obra_itsi = '2701C'
--and NumProc_itsi = 17328)


UNION ALL

SELECT Empresa_itsi                                                                                    AS Empresa_des
     , Obra_itsi                                                                                       AS Obra_des
     , NumProc_itsi                                                                                    AS NumProc_des
     , ContasPagas.NumParc_pag                                                                         AS NumParc_des
	 , Composicoes.Cod_comp
	 , Composicoes.descr_comp
     , CodInsProc_item                                                                                 AS ItemProc_des
	 , InsumosGeral.Descr_ins
     , ContasPagas.DataEmissao_pag                                                                     AS DtPgto_des
     , Porc_itsi * ContasPagas.AcrescParc_pag                                                          AS Acrescimo_des
     , Porc_itsi * ContasPagas.DescParc_pag                                                            AS Desconto_des
     , Porc_itsi * ContasPagas.ValorProc_Pag                                                           AS TotalLiq_des
     , Porc_itsi * (ContasPagas.ValorProc_Pag - ContasPagas.AcrescParc_pag + ContasPagas.DescParc_Pag) AS TotalBruto_des
     , Porc_itsi                                                                                       AS Porc_des
     , Contrato_itsi                                                                                   AS ContratoPL_des
     , Prod_itsi                                                                                       AS ProdutoPL_des
     , Item_itsi                                                                                       AS ItemPL_des
     , Comp_itsi                                                                                       AS CompPL_itsi
     , PLMes_itsi                                                                                      AS PlMes_des
     , InsumoPL_itsi                                                                                   AS InsumoPL_des
     , 0                                                                                               AS QtdeItem_des
     , 0                                                                                               AS ValorUnitItem_des
     , 2                                                                                               AS StatusParc_des
     , BancoProc_Pag                                                                                   AS Banco_des  --Banco_Des
     , Conta_Pag                                                                                       AS ContaCorr_des  --ContaCorr_Des
     , ContasPagas.TipoProc_pag                                                                        AS TipoProc_des
     , Itens_Proc.CapInsProc_Item                                                                      AS Cap_des
     , COALESCE(AplicacaoInsumoPisCofins.PorcPis_aipc, insumo.PorcPis_aipc)                            AS PorcPis_Des
     , COALESCE(AplicacaoInsumoPisCofins.PorcCofins_aipc, insumo.PorcCofins_aipc)                      AS PorcCofins_Des
     , COALESCE(AplicacaoInsumoPisCofins.NumSTPis_aipc, insumo.NumSTPis_aipc)                          AS NumSTPis_Des
     , COALESCE(AplicacaoInsumoPisCofins.NumSTCofins_aipc, insumo.NumSTCofins_aipc)                    AS NumSTCofins_Des
     , CodForn_Pag                                                                                     AS CodForn_Des
     , NumFiscal_Pag                                                                                   AS NumFiscal_Des  --DocFiscal_Des
     , CategMovFin_Pag                                                                                 AS CategMovFin_Des
     , ChqNome_Pag                                                                                     AS ChqNome_Des	--NominalProc_Des
     , NumChq_Pag                                                                                      AS NumChq_Des --NumCheque_Des
     , DataVencParc_Pag                                                                                AS DataVencParc_Des
     , DtDocFisc_Pag                                                                                   AS DtDocFisc_Des
     , DocFiscal_Pag                                                                                   AS DocFiscal_Des
	 ,CAP.Desc_cger
	 ,ContasPagas.DataPag_pag AS DataPag
	 ,ContasPagas.DataAprovEmissao_pag AS DataAprovEmissao
	 ,PlanTotal.Descr_plt AS Desc_Servico
	 ,ContasPagas.DataProc_Pag AS DtGeracao_Des
	 ,ContasPagas.DocFiscal_Pag AS VlDocFisc
	 ,ContasPagas.DataConfVl_Pag  AS DataAprovV
	 ,ContasPagas.Contrato_Pag AS ContratoServ
	 ,Itens_Proc.UnidProc_Item AS UnidItemProc_Des
	 ,ContasPagas.OrdemCompra_Pag AS NumOc_Des
	 ,ContasPagas.NumCot_Pag AS NumCot_Des
	 ,CASE 
		WHEN ContasPagas.TipoProc_pag = 7 THEN Composicoes.Descr_comp 
		ELSE InsumosGeral.Descr_ins END AS DescItemProc_Des
	 ,AA.Descr_ins AS DescInsPl_Des
	 ,PlanTotal.Descr_plt AS DescCompPl_Des
	 ,ContasPagas.Status_Pag AS Status_Des --**
	 ,ContasPagas.User_Pag AS User_Des --**
	 ,Data_Doc

FROM UAU.dbo.Itens_Proc
    INNER JOIN
    (
        SELECT Empresa_itsi
             , Obra_itsi
             , NumProcVinc_PrVinc AS NumProc_itsi
             , SUM(Porc_itsi)     AS Porc_itsi
             , Contrato_itsi
             , Prod_itsi
             , Item_itsi
             , Comp_itsi
             , PLMes_itsi
             , InsumoPL_itsi
        FROM
        (
            SELECT DISTINCT
                Empresa_pag
              , ObraProc_pag
              , NumProc_pag
              , IntExt_Pag
            FROM UAU.dbo.ContasPagas
        ) AS ContasPagas
            INNER JOIN UAU.dbo.ProcVinc
                ON ContasPagas.Empresa_pag = ProcVinc.Empresa_PrVinc
                   AND ContasPagas.ObraProc_Pag = ProcVinc.Obra_PrVinc
                   AND ContasPagas.NumProc_Pag = ProcVinc.NumProcVinc_PrVinc
            INNER JOIN UAU.dbo.ItemProcSI
                ON ProcVinc.Empresa_PrVinc = ItemProcSI.Empresa_itsi
                   AND ProcVinc.Obra_PrVinc = ItemProcSI.Obra_itsi
                   AND ProcVinc.InsumoProc_PrVinc = ItemProcSI.InsumoProc_itsi
                   AND ProcVinc.Item_PrVinc = ItemProcSI.Item_itsi
                   AND ProcVinc.Prod_PrVinc = ItemProcSI.Prod_itsi
                   AND ProcVinc.Contrato_PrVinc = ItemProcSI.Contrato_itsi
                   AND ProcVinc.Comp_PrVinc = ItemProcSI.Comp_itsi
                   AND ProcVinc.InsumoPL_PrVinc = ItemProcSI.InsumoPL_itsi
                   AND ProcVinc.PLMes_PrVinc = ItemProcSI.PLMes_itsi
                   AND ProcVinc.NumProc_PrVinc = ItemProcSI.NumProc_itsi

        GROUP BY Empresa_itsi
               , Obra_itsi
               , NumProcVinc_PrVinc
               , Contrato_itsi
               , Item_itsi
               , Comp_itsi
               , PLMes_itsi
               , InsumoPL_itsi
               , Prod_itsi
    ) AS ItemProcSIVinc
        ON Itens_Proc.Empresa_item = Empresa_itsi
           AND Itens_Proc.NumProc_Item = NumProc_itsi
           AND Itens_Proc.ObraProc_Item = Obra_itsi
    INNER JOIN UAU.dbo.ContasPagas
        ON Itens_Proc.Empresa_item = ContasPagas.Empresa_pag
           AND Itens_Proc.NumProc_Item = ContasPagas.NumProc_Pag
           AND Itens_Proc.ObraProc_Item = ContasPagas.ObraProc_Pag
    LEFT JOIN UAU.dbo.Composicoes
        ON Itens_Proc.CodInsProc_Item = Composicoes.Cod_comp
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins
        ON AplicacaoInsumoPisCofins.Num_aipc = Composicoes.NumApi_comp
    LEFT JOIN UAU.dbo.InsumosGeral
        ON Itens_Proc.CodInsProc_Item = InsumosGeral.Cod_ins
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins insumo
        ON insumo.Num_aipc = InsumosGeral.NumApi_ins
    INNER JOIN UAU.dbo.CAP WITH (NOLOCK)
         ON ContasPagas.CAP_Pag = CAP.Codigo_cger
    LEFT OUTER JOIN UAU.dbo.PlanTotal
        ON PlanTotal.Empresa_plt = ItemProcSIVinc.Empresa_itsi
            AND PlanTotal.Obra_plt = ItemProcSIVinc.Obra_itsi
            AND PlanTotal.Item_plt = ItemProcSIVinc.Item_itsi
            AND PlanTotal.Serv_plt = ItemProcSIVinc.Comp_itsi
            AND PlanTotal.Prod_plt = ItemProcSIVinc.Prod_itsi
            AND PlanTotal.Contrato_plt = ItemProcSIVinc.Contrato_itsi
	LEFT OUTER JOIN UAU.dbo.CategoriasDeInsumo 
	RIGHT OUTER JOIN UAU.dbo.Insumos as AA
		ON CategoriasDeInsumo.Codigo_cger = AA.CatIns_ins 
		ON Empresa_itsi = AA.Empresa_ins 
			AND Obra_itsi = AA.Obra_ins 
			AND InsumoPL_itsi = AA.Cod_ins 
	LEFT JOIN UAU.dbo.Extrato 
		ON Empresa_itsi = Empresa_Doc
		AND Conta_Pag = Conta_Doc
		AND NumChq_Pag = Numero_Doc
		AND BancoProc_Pag = Banco_Doc

--WHERE CAP.Desc_cger in ('REFEIÇÕES E LANCHES','SALARIOS A PAGAR')

--where (Empresa_itsi = 1
--and Obra_itsi = 'CIADM'
--and NumProc_itsi = 88)
--or (Empresa_itsi = 27
--and Obra_itsi = '2701C'
--and NumProc_itsi = 17328)




go

