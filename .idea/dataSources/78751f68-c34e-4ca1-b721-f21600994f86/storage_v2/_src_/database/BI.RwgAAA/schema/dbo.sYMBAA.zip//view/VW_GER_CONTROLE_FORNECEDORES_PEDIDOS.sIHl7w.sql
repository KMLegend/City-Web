






CREATE VIEW [dbo].[VW_GER_CONTROLE_FORNECEDORES_PEDIDOS] AS
--View Lista de fornecedores de acordo com pedidos

WITH CONTAS_A_PAGAR AS (

SELECT 
	Empresa_itsi AS Empresa_des,
	Obra_itsi AS Obra_des,
	ContasPagas.DataProc_Pag AS [Data Geração],
	DocFiscal_Proc AS DocFiscal_Des,
	ContasPagas.ChqNome_Pag AS NominalProc,
	CAP.Desc_cger AS DescCap_Des,
	'CONTAS_A_PAGAR' AS status_conta
FROM UAU.dbo.ItemProcSI
    INNER JOIN UAU.dbo.Parc_Proc
        ON ItemProcSI.Empresa_itsi = Parc_Proc.Empresa_proc
           AND ItemProcSI.Obra_itsi = Parc_Proc.Obra_Proc
           AND ItemProcSI.NumProc_itsi = Parc_Proc.Num_Proc
    INNER JOIN UAU.dbo.Dados_Proc
        ON Parc_Proc.Empresa_proc = Dados_Proc.Empresa_proc
           AND Parc_Proc.Obra_Proc = Dados_Proc.Obra_Proc
           AND Parc_Proc.Num_Proc = Dados_Proc.Num_Proc
    INNER JOIN UAU.dbo.Itens_Proc
        ON Itens_Proc.Empresa_item = ItemProcSI.Empresa_itsi
           AND Itens_Proc.NumProc_Item = ItemProcSI.NumProc_itsi
           AND Itens_Proc.ObraProc_Item = ItemProcSI.Obra_itsi
           AND Itens_Proc.CodInsProc_Item = ItemProcSI.InsumoProc_itsi
    INNER JOIN UAU.dbo.ContasPagas
        ON ContasPagas.Empresa_pag = Itens_Proc.Empresa_item
            AND ContasPagas.ObraProc_Pag = Itens_Proc.ObraProc_Item
            AND ContasPagas.NumProc_Pag = Itens_Proc.NumProc_Item
    LEFT JOIN UAU.dbo.Composicoes
        ON Itens_Proc.CodInsProc_Item = Composicoes.Cod_comp
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins
        ON AplicacaoInsumoPisCofins.Num_aipc = composicoes.NumApi_comp
    LEFT JOIN UAU.dbo.InsumosGeral
        ON Itens_Proc.CodInsProc_Item = InsumosGeral.Cod_ins
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins Insumo
        ON Insumo.Num_aipc = insumosgeral.NumApi_ins
    LEFT OUTER JOIN UAU.dbo.CAP
        ON Itens_Proc.CapInsProc_Item   = CAP.Codigo_cger
WHERE StatusParc_proc <> 2


UNION ALL


SELECT 

	Empresa_itsi AS Empresa_des,
	Obra_itsi AS Obra_des,
	ContasPagas.DataProc_Pag AS [Data Geração],
	DocFiscal_Proc AS DocFiscal_Des,
	ContasPagas.ChqNome_Pag AS NominalProc,
	CAP.Desc_cger AS DescCap_Des,
	'CONTAS_A_PAGAR' AS status_conta
FROM
(
    SELECT Empresa_itsi,
           Obra_itsi,
           NumProcVinc_PrVinc AS NumProc_itsi,
           SUM(Porc_itsi) AS Porc_itsi,
           Contrato_itsi,
           Prod_itsi,
           Item_itsi,
           Comp_itsi,
           PLMes_itsi,
           InsumoPL_itsi,
           Dados_Proc.TipoDoc_Proc,
           CodForn_Proc
    FROM UAU.dbo.Dados_Proc
        INNER JOIN UAU.dbo.ProcVinc
            ON Dados_Proc.Empresa_proc = ProcVinc.Empresa_PrVinc
               AND Dados_Proc.Obra_Proc = ProcVinc.Obra_PrVinc
               AND Dados_Proc.Num_Proc = ProcVinc.NumProcVinc_PrVinc
        INNER JOIN UAU.dbo.ItemProcSI
            ON ProcVinc.Empresa_PrVinc = ItemProcSI.Empresa_itsi
               AND ProcVinc.Obra_PrVinc = ItemProcSI.Obra_itsi
               AND ProcVinc.InsumoProc_PrVinc = ItemProcSI.InsumoProc_itsi
               AND ProcVinc.Item_PrVinc = ItemProcSI.Item_itsi
               AND ProcVinc.Prod_PrVinc = ItemProcSI.Prod_itsi
               AND ProcVinc.Contrato_PrVinc = ItemProcSI.Contrato_itsi
               AND ProcVinc.Comp_PrVinc = ItemProcSI.Comp_itsi
               AND ProcVinc.InsumoPL_PrVinc = ItemProcSI.InsumoPL_itsi
               AND ProcVinc.PLMes_PrVinc = ItemProcSI.PLMes_itsi
               AND ProcVinc.NumProc_PrVinc = ItemProcSI.NumProc_itsi
    GROUP BY Empresa_itsi,
             Obra_itsi,
             NumProcVinc_PrVinc,
             Contrato_itsi,
             Item_itsi,
             Comp_itsi,
             PLMes_itsi,
             InsumoPL_itsi,
             Prod_itsi,
             Dados_Proc.TipoDoc_Proc,
             CodForn_Proc
) AS ItemProcSIVinc
    INNER JOIN UAU.dbo.Parc_Proc
        ON Empresa_itsi = Parc_Proc.Empresa_proc
           AND Obra_itsi = Parc_Proc.Obra_Proc
           AND NumProc_itsi = Parc_Proc.Num_Proc
    INNER JOIN UAU.dbo.Itens_Proc
        ON Parc_Proc.Empresa_proc = Itens_Proc.Empresa_item
           AND Parc_Proc.Obra_Proc = Itens_Proc.ObraProc_Item
           AND Parc_Proc.Num_Proc = Itens_Proc.NumProc_Item
    INNER JOIN UAU.dbo.ContasPagas
        ON ContasPagas.Empresa_pag = Itens_Proc.Empresa_item
            AND ContasPagas.ObraProc_Pag = Itens_Proc.ObraProc_Item
            AND ContasPagas.NumProc_Pag = Itens_Proc.NumProc_Item
    LEFT JOIN UAU.dbo.Composicoes
        ON Itens_Proc.CodInsProc_Item = Composicoes.Cod_comp
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins
        ON AplicacaoInsumoPisCofins.Num_aipc = composicoes.NumApi_comp
    LEFT JOIN UAU.dbo.InsumosGeral
        ON Itens_Proc.CodInsProc_Item = InsumosGeral.Cod_ins
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins Insumo
        ON Insumo.Num_aipc = insumosgeral.NumApi_ins
    LEFT OUTER JOIN UAU.dbo.CAP
        ON Itens_Proc.CapInsProc_Item   = CAP.Codigo_cger
WHERE StatusParc_proc <> 2
),

CONTAS_PAGAS as (
SELECT
	Empresa_itsi AS Empresa_des,
	Obra_itsi AS Obra_des,
	ContasPagas.DataProc_Pag AS [Data Geração],
    NumFiscal_Pag AS DocFiscal_Des,
	ContasPagas.ChqNome_Pag AS NominalProc,
	CAP.Desc_cger	AS DescCap_des,
	'CONTAS_PAGAS' AS status_conta
FROM UAU.dbo.ItemProcSI
    INNER JOIN UAU.dbo.ContasPagas
        ON Empresa_itsi = ContasPagas.Empresa_pag
           AND NumProc_itsi = ContasPagas.NumProc_Pag
           AND Obra_itsi = ContasPagas.ObraProc_Pag
    INNER JOIN UAU.dbo.Itens_Proc
        ON Itens_Proc.Empresa_item = ItemProcSI.Empresa_itsi
           AND Itens_Proc.NumProc_Item = ItemProcSI.NumProc_itsi
           AND Itens_Proc.ObraProc_Item = ItemProcSI.Obra_itsi
           AND Itens_Proc.CodInsProc_Item = ItemProcSI.InsumoProc_itsi
    LEFT JOIN UAU.dbo.Composicoes
        ON Itens_Proc.CodInsProc_Item = Composicoes.Cod_comp
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins
        ON AplicacaoInsumoPisCofins.Num_aipc = Composicoes.NumApi_comp
    LEFT JOIN UAU.dbo.InsumosGeral
        ON Itens_Proc.CodInsProc_Item = InsumosGeral.Cod_ins
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins insumo
        ON insumo.Num_aipc = InsumosGeral.NumApi_ins
    LEFT OUTER JOIN UAU.dbo.CAP
        ON Itens_Proc.CapInsProc_Item   = CAP.Codigo_cger


UNION ALL

SELECT
	Empresa_itsi AS Empresa_des,
	Obra_itsi AS Obra_des,
	ContasPagas.DataProc_Pag AS [Data Geração],
    NumFiscal_Pag AS DocFiscal_Des,
	ContasPagas.ChqNome_Pag AS NominalProc,
	CAP.Desc_cger AS DescCap_Des,
	'CONTAS_PAGAS' AS status_conta
FROM UAU.dbo.Itens_Proc
    INNER JOIN
    (
        SELECT Empresa_itsi
             , Obra_itsi
             , NumProcVinc_PrVinc AS NumProc_itsi
             , SUM(Porc_itsi)     AS Porc_itsi
             , Contrato_itsi
             , Prod_itsi
             , Item_itsi
             , Comp_itsi
             , PLMes_itsi
             , InsumoPL_itsi
        FROM
        (
            SELECT DISTINCT
                Empresa_pag
              , ObraProc_pag
              , NumProc_pag
              , IntExt_Pag
            FROM UAU.dbo.ContasPagas
        ) AS ContasPagas
            INNER JOIN UAU.dbo.ProcVinc
                ON ContasPagas.Empresa_pag = ProcVinc.Empresa_PrVinc
                   AND ContasPagas.ObraProc_Pag = ProcVinc.Obra_PrVinc
                   AND ContasPagas.NumProc_Pag = ProcVinc.NumProcVinc_PrVinc
            INNER JOIN UAU.dbo.ItemProcSI
                ON ProcVinc.Empresa_PrVinc = ItemProcSI.Empresa_itsi
                   AND ProcVinc.Obra_PrVinc = ItemProcSI.Obra_itsi
                   AND ProcVinc.InsumoProc_PrVinc = ItemProcSI.InsumoProc_itsi
                   AND ProcVinc.Item_PrVinc = ItemProcSI.Item_itsi
                   AND ProcVinc.Prod_PrVinc = ItemProcSI.Prod_itsi
                   AND ProcVinc.Contrato_PrVinc = ItemProcSI.Contrato_itsi
                   AND ProcVinc.Comp_PrVinc = ItemProcSI.Comp_itsi
                   AND ProcVinc.InsumoPL_PrVinc = ItemProcSI.InsumoPL_itsi
                   AND ProcVinc.PLMes_PrVinc = ItemProcSI.PLMes_itsi
                   AND ProcVinc.NumProc_PrVinc = ItemProcSI.NumProc_itsi
        GROUP BY Empresa_itsi
               , Obra_itsi
               , NumProcVinc_PrVinc
               , Contrato_itsi
               , Item_itsi
               , Comp_itsi
               , PLMes_itsi
               , InsumoPL_itsi
               , Prod_itsi
    )                                  AS ItemProcSIVinc
        ON Itens_Proc.Empresa_item = Empresa_itsi
           AND Itens_Proc.NumProc_Item = NumProc_itsi
           AND Itens_Proc.ObraProc_Item = Obra_itsi
    INNER JOIN UAU.dbo.ContasPagas
        ON Itens_Proc.Empresa_item = ContasPagas.Empresa_pag
           AND Itens_Proc.NumProc_Item = ContasPagas.NumProc_Pag
           AND Itens_Proc.ObraProc_Item = ContasPagas.ObraProc_Pag
    LEFT JOIN UAU.dbo.Composicoes
        ON Itens_Proc.CodInsProc_Item = Composicoes.Cod_comp
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins
        ON AplicacaoInsumoPisCofins.Num_aipc = Composicoes.NumApi_comp
    LEFT JOIN UAU.dbo.InsumosGeral
        ON Itens_Proc.CodInsProc_Item = InsumosGeral.Cod_ins
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins insumo
        ON insumo.Num_aipc = InsumosGeral.NumApi_ins
    LEFT OUTER JOIN UAU.dbo.CAP
        ON Itens_Proc.CapInsProc_Item   = CAP.Codigo_cger

)


SELECT DISTINCT 
	base.Empresa_des,
	base.Obra_des,
	base.[Data Geração],
	base.DocFiscal_Des,
	base.NominalProc,
	base.DescCap_Des
from (
SELECT DISTINCT 
	Empresa_des,
	Obra_des,
	[Data Geração],
    CAST(DocFiscal_Des AS VARCHAR) AS DocFiscal_Des,
	NominalProc,
	DescCap_des,
	status_conta
FROM CONTAS_PAGAS

union all

SELECT DISTINCT 
	Empresa_des,
	Obra_des,
	[Data Geração],
    CAST(DocFiscal_Des AS VARCHAR) AS DocFiscal_Des,
	NominalProc,
	DescCap_des,
	status_conta
FROM CONTAS_A_PAGAR
) as base



go

