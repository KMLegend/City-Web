
CREATE VIEW [dbo].[VW_GER_CONTROLE_COTACAO_COMPRAS] AS (
SELECT    
	Empresa_cot AS CODEMP,
	Desc_emp AS Empresa,
	Obra_Ocp AS CODOBR,
	descr_obr AS Obra,    
	Num_cot AS Cotacao,
	COALESCE(Descricao_cot, '') AS DescrCotacao,
	MAX(ValorTot_Smlc) AS VlrSimulCotacao,
	MAX(Valor_ioc) AS ValorOC,
	COALESCE(MAX(UsrConf_smlc), 'NÃO ENC') AS UsrConfSimul,
	COALESCE(MAX(DataConf_apPedM), MAX(DataConf_temp)) AS DataConfPed,
	MAX(Data_smlc) AS DataSimul,
	MAX(DataConf_smlc) AS DataConfSimul
FROM   UAU.dbo.Cotacao 
      INNER JOIN UAU.dbo.ItensCotacao 
        ON ItensCotacao.Empresa_item = Empresa_Cot
        AND ItensCotacao.NumCot_item = Num_cot 
      INNER JOIN UAU.dbo.ItensCot_Temp
        ON Empresa_Temp = Empresa_Cot
        AND Cotacao_Temp = Num_Cot
        AND Insumo_Temp = CodIns_item 
      LEFT JOIN
      (
        SELECT    Empresa_smlc, NumCot_smlc, MAX(Data_Smlc) AS Data_Smlc, MAX(DataConf_smlc) DataConf_smlc, 
              MAX(UsrConf_smlc) UsrConf_smlc, SUM(ValorTot_Smlc) AS ValorTot_Smlc
        FROM    UAU.dbo.Cotacao 
              INNER JOIN UAU.dbo.SimulacoesConf
                ON Empresa_Smlc = Empresa_Cot 
                AND NumCot_Smlc = Num_cot
        GROUP BY  Empresa_smlc, NumCot_smlc, DataConf_smlc, UsrConf_smlc      
 
      ) AS AprovacaoPedMat
        ON Empresa_cot = Empresa_smlc
        AND Num_cot = NumCot_smlc 
      LEFT JOIN
      (
        SELECT    Empresa_apPedM, Obra_apPedM, NumPedido_apPedM, MAX(DataAprov_apPedM) AS DataConf_apPedM, 
              (
                SELECT  MAX(UsrAprov_apPedM) AS UsrAprov_apPedM
                FROM  UAU.dbo.AprovacaoPedMat AS APM 
                WHERE APM.Empresa_apPedM = APM1.Empresa_apPedM 
                    AND APM.Obra_apPedM = APM1.Obra_apPedM 
                    AND APM.NumPedido_apPedM = APM1.NumPedido_apPedM 
                    AND APM.DataAprov_apPedM = MAX(APM1.DataAprov_apPedM)
              ) AS QuemConf_apPedM
        FROM    UAU.dbo.AprovacaoPedMat AS APM1
        GROUP BY  Empresa_apPedM, Obra_apPedM, NumPedido_apPedM
      ) AS AprovPedMat
        ON Empresa_temp = Empresa_apPedM
        AND Obra_temp = Obra_apPedM     
        AND NumPedido_temp = NumPedido_apPedM 
      LEFT JOIN
      (
        SELECT    Empresa_Ocp,
              Obra_Ocp,     
              NumCot_ocp,     
              SUM((Qtde_Ioc * Preco_Ioc)) Valor_ioc     
        FROM    UAU.dbo.OrdemCompra 
              INNER JOIN UAU.dbo.ItensOrdemCompra 
                ON OrdemCompra.Empresa_Ocp = ItensOrdemCompra.Empresa_Ioc 
                AND OrdemCompra.Obra_Ocp = ItensOrdemCompra.Obra_Ioc 
                AND OrdemCompra.NumeroOC_Ocp = ItensOrdemCompra.NumeroOC_Ioc 
        GROUP BY  Empresa_Ocp, Obra_Ocp, NumCot_ocp
      ) AS OrdemCompra
        ON Empresa_cot = Empresa_Ocp 
        AND Num_cot = NumCot_Ocp 
      INNER JOIN UAU.dbo.Empresas
        ON Empresa_cot = Codigo_emp 
      INNER JOIN UAU.dbo.Obras
        ON Empresa_cot = Empresa_obr 
        AND Obra_Ocp = cod_obr
WHERE   CondPag_item = 1
--      AND DataConf_smlc >= '2024-01-01'
     GROUP BY  Empresa_Cot, Desc_emp, Obra_Ocp, descr_obr, Num_cot, Descricao_cot
--ORDER BY    Empresa_Cot, Obra_ocp, MAX(DataConf_smlc)

)
go

