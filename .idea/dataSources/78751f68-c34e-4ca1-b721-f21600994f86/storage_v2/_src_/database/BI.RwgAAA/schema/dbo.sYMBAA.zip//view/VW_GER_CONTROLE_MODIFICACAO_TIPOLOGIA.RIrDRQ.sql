
CREATE VIEW [dbo].[VW_GER_CONTROLE_MODIFICACAO_TIPOLOGIA] AS 

SELECT  --696
	RIGHT(C.NumDoc_com, LEN(C.NumDoc_Com) - CHARINDEX('-',C.NumDoc_Com)) as Produto
	,SUBSTRING(C.NumDoc_Com, CHARINDEX(' ',C.NumDoc_Com), (CHARINDEX('-',C.NumDoc_Com) - CHARINDEX(' ',C.NumDoc_Com))) as Perso
	,C.NumDoc_Com
	,C.User_Com
	,C.DataHora_Com
	,C.Tipo_Com
	,C.UsrLogin_Com
	,C.CodGrupo_Com
	,C.Empresa_Com
	,C.Comentario_Com
	,C.Categoria_Com
	,C.Excluido_Com
	,U.CodTipProd_unid
	,U.Identificador_unid
	,CASE 
		WHEN U.Vendido_unid = 0 THEN '0-Disponível'
		WHEN U.Vendido_unid = 1 THEN '1-Vendido'
		WHEN U.Vendido_unid = 2 THEN '2-Reservado'
		WHEN U.Vendido_unid = 3 THEN '3-Proposta'
		WHEN U.Vendido_unid = 4 THEN '4-Quitado'
		WHEN U.Vendido_unid = 5 THEN '5-Escriturado'
		WHEN U.Vendido_unid = 6 THEN '6-Em Venda'
		WHEN U.Vendido_unid = 7 THEN '7-Suspenso p/ Venda'
		WHEN U.Vendido_unid = 8 THEN '8-Fora de Venda'
		WHEN U.Vendido_unid = 9 THEN '9-Em acerto'
		WHEN U.Vendido_unid = 10 THEN '10-Dação'
END AS Vendido_unid
FROM UAU.dbo.Comentario AS C
    LEFT JOIN UAU.dbo.UnidadePer AS U
        ON RIGHT(C.NumDoc_com, LEN(C.NumDoc_Com) - CHARINDEX('-', C.NumDoc_Com)) = U.Prod_unid
           AND SUBSTRING(
                            C.NumDoc_Com,
                            CHARINDEX(' ',C.NumDoc_Com),
                            (CHARINDEX('-',C.NumDoc_Com) - CHARINDEX(' ',C.NumDoc_Com))
                        ) = U.NumPer_unid
           AND C.Empresa_Com = U.Empresa_unid
WHERE C.numdoc_com like 'PersonProduto%'
      AND C.excluido_com = 0
      AND C.Comentario_Com like '%Tipologia atualizada para: %'
--ORDER BY C.datahora_com DESC


go

