
 CREATE VIEW [dbo].[VW_GER_CONTROLE_ITENS_ORDEM_COMPRA] AS 
 
select DISTINCT
	oc.Empresa_Ocp, 
	oc.Obra_Ocp, 
	oc.NumeroOC_Ocp,  
	io.Preco_Ioc, 
	io.Qtde_Ioc, 
	io.CodInsumo_Ioc 
from  UAU.dbo.OrdemCompra oc 
left join UAU.dbo.ItensOrdemCompra io 
	on  oc.Empresa_Ocp  = io.Empresa_Ioc
		and oc.Obra_Ocp   = io.Obra_Ioc
		and oc.NumeroOC_Ocp = io.NumeroOC_Ioc
--where oc.Obra_Ocp = '0501C'--:obraUAU
--	and oc.Empresa_Ocp = 12 --:empresa
go

