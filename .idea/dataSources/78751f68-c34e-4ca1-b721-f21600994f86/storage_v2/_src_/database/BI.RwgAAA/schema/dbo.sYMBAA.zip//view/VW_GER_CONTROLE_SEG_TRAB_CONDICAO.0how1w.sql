




CREATE VIEW [dbo].[VW_GER_CONTROLE_SEG_TRAB_CONDICAO] AS 

SELECT CondicaoAmbientalTrabalho.Anexo_cAmbTrab,
       CondicaoAmbientalTrabalho.CodEmp_cAmbTrab,
       CondicaoAmbientalTrabalho.CodObra_cAmbTrab,
       CapacitacaoRH.Empresa_CapRH,
       CapacitacaoRH.Obra_CapRH,
       CapacitacaoRH.CodPes_CapRH,
       pessoas.nome_pes,
       CapacitacaoRH.MatFunc_CapRh,
       CondicaoAmbientalTrabalho.Num_cAmbTrab,
       CondicaoAmbientalTrabalho.DataInicio_cAmbTrab,
       CondicaoAmbientalTrabalho.DescrAtivDes_cAmbTrab,
       CondicaoAmbientalTrabalho.TipoEstabAmb_cAmbTrab,
       CASE
           WHEN CondicaoAmbientalTrabalho.CodObra_cAmbTrab IS NULL THEN
               EmpresaAmbiente.Desc_emp
           ELSE
               ObraAmbiente.descr_obr
       END AS DescAmbTrabalho,
       CondicaoAmbientalTrabalho.NumGExp_cAmbTrab,
       GrupoExposicao.Descricao_gExp,
       GrupoExposicao.ObsCompl_gExp,
       CondicaoAmbientalTrabalho.UsrAlt_cAmbTrab,
       CondicaoAmbientalTrabalho.DataAlt_cAmbTrab,
       EmpresaLotacao.Desc_emp,
       ObraLotacao.descr_obr,
       CondicaoAmbientalTrabalho.NumCapRH_cAmbTrab
FROM UAU.dbo.CondicaoAmbientalTrabalho
    INNER JOIN UAU.dbo.GrupoExposicao
        ON GrupoExposicao.Num_gExp = CondicaoAmbientalTrabalho.NumGExp_cAmbTrab
    INNER JOIN UAU.dbo.CapacitacaoRH
        ON CapacitacaoRH.Num_CapRH = CondicaoAmbientalTrabalho.NumCapRH_cAmbTrab
           AND CapacitacaoRH.Funcionario_CapRH = 1
    INNER JOIN UAU.dbo.Empresas As EmpresaLotacao
        ON EmpresaLotacao.Codigo_emp = CapacitacaoRH.Empresa_CapRH
    INNER JOIN UAU.dbo.Obras As ObraLotacao
        ON ObraLotacao.Empresa_obr = CapacitacaoRH.Empresa_CapRH
           AND ObraLotacao.cod_obr = CapacitacaoRH.Obra_CapRH
    INNER JOIN UAU.dbo.Empresas AS EmpresaAmbiente
        ON EmpresaAmbiente.Codigo_emp = CondicaoAmbientalTrabalho.CodEmp_cAmbTrab
    LEFT JOIN UAU.dbo.Obras AS ObraAmbiente
        ON ObraAmbiente.Empresa_obr = CondicaoAmbientalTrabalho.CodEmp_cAmbTrab
           AND ObraAmbiente.cod_obr = CondicaoAmbientalTrabalho.CodObra_cAmbTrab
    INNER JOIN UAU.dbo.Pessoas
        ON Pessoas.cod_pes = CapacitacaoRH.CodPes_CapRH

      --WHERE [CapacitacaoRH].[Empresa_CapRH] = 53
      --AND [CapacitacaoRH].[Obra_CapRH] = '5301C'

--ORDER BY Pessoas.Nome_pes,
--         CondicaoAmbientalTrabalho.Num_cAmbTrab
go

