

CREATE VIEW [dbo].[VW_GER_CONTROLE_MEDIACAO_CONTRATO] AS

--Busca processos vinculados às medições do contrato. 
/* Variaveis:
Contrato - numero de contrato(% para todos contratos) - texto
Data Inicio - data inicial da busca - datetime
Data Termino - data inicial da busca - datetime
Empresa e Obra - busca emp e obra -- texto/numerico
TipoData - tipo de data (0=vencimento; 1=prorrogação ) -- numerico
*/


SELECT DISTINCT
    --			CAST(<DataInicio> AS DATETIME) [DataInicio], 
    --			CAST(<DataTermino> AS DATETIME) [DataTermino], 
    --TipoData, 
    --TipoPeriodo, 
    Empresa_Cont,
    UPPER(Desc_Emp) [Desc_Emp],
    CAST(Empresa_Cont AS VARCHAR) + ' - ' + UPPER(Desc_Emp) [Empresa],
    Obra_Cont,
    UPPER(Descr_Obr) [Descr_Obr],
    Obra_Cont + ' - ' + UPPER(Descr_Obr) [Obra],
    Cod_Cont,
    UPPER(Objeto_Cont) [Objeto_Cont],
    CAST(Cod_Cont AS VARCHAR) + ' - ' + UPPER(Objeto_Cont) [Contrato],
    CodPes_Cont,
    UPPER(Nome_Pes) [Nome_Pes],
    CAST(CodPes_Cont AS VARCHAR) + ' - ' + UPPER(Nome_Pes) [Fornecedor],
    CodMed,
    Num_Proc,
    NumParc_Proc,
    Data_Vencimento,
	Data_Prorrogacao,
    SUM(Valor) [Valor_Proc],
    CASE StatusParc
        WHEN 0 THEN
            '0 - CONTAS A PAGAR'
        WHEN 1 THEN
            '1 - EMISSÃO DE PAGAMENTOS'
        WHEN 2 THEN
            '2 - CONTAS PAGAS'
        WHEN 3 THEN
            '3 - EXCLUÍDO'
    END [Status]

FROM UAU.dbo.Contratos
INNER JOIN
(
SELECT 
	Dados_Proc.Empresa_Proc as Empresa,
	Dados_Proc.Obra_Proc as Obra,
	Dados_Proc.CodForn_Proc as CodForn,
	Dados_Proc.Contrato_Proc as Contrato,
	Dados_Proc.CodMed_Proc as CodMed,
	Dados_Proc.Num_Proc as Num_Proc,
	Parc_Proc.NumParc_Proc as NumParc_Proc,
	--0 as TipoData,
	--'vencimento' as TipoPeriodo,
	Parc_Proc.DtVencParc_Proc as Data_Vencimento,
	Parc_Proc.DtPagParc_Proc as Data_Prorrogacao, 
	Parc_Proc.ValorParc_Proc + Parc_Proc.AcrescParc_Proc - Parc_Proc.DescParc_Proc as Valor,
	Parc_Proc.StatusParc_Proc as StatusParc
FROM UAU.dbo.Dados_Proc
INNER JOIN UAU.dbo.Parc_Proc
	ON Dados_Proc.Empresa_Proc = Parc_Proc.Empresa_Proc
		AND Dados_Proc.Obra_Proc = Parc_Proc.Obra_Proc
		AND Dados_Proc.Num_Proc = Parc_Proc.Num_Proc
WHERE Parc_Proc.StatusParc_Proc <> 2

UNION

SELECT 
	Empresa_Pag as Empresa,
	ObraProc_Pag as Obra,
	CodForn_Pag as CodForn,
	Contrato_Pag as Contrato,
	CodMed_Pag as CodMed,
	NumProc_Pag as Num_Proc,
	NumParc_Pag as NumParc_Proc,
	--0 as TipoData,
	--'vencimento' as TipoPeriodo,
	DataVencParc_Pag as Data_Vencimento,
	DataEmissao_Pag as Data_Prorrogacao, 
	ValorProc_Pag as Valor,
	2 as StatusParc
FROM UAU.dbo.ContasPagas

) [Processos]
        ON Empresa_Cont = Empresa
           AND Obra_Cont = Obra
           AND Cod_Cont = Contrato
           AND CodPes_Cont = CodForn
    INNER JOIN UAU.dbo.Empresas
        ON Empresa_Cont = Codigo_Emp
    INNER JOIN UAU.dbo.Obras
        ON Empresa_Cont = Empresa_Obr
           AND Obra_Cont = Cod_Obr
    INNER JOIN UAU.dbo.Pessoas
        ON CodPes_Cont = Cod_Pes

--WHERE CAST(Cod_Cont AS VARCHAR) LIKE <Contrato> 

--WHERE Obra_Cont in ('3401C','5501C','4701C','7601C')


GROUP BY 
	--TipoData, 
	--TipoPeriodo, 
	Empresa_Cont,
	Desc_Emp,
	Obra_Cont,
	Descr_Obr,
	Cod_Cont,
	Objeto_Cont,
	CodPes_Cont,
	Nome_Pes,
	CodMed,
	Num_Proc,
	NumParc_Proc,
    Data_Vencimento,
	Data_Prorrogacao,
	StatusParc
--ORDER BY 
--	Empresa_Cont,
--	Obra_Cont,
--	Cod_Cont,
--	CodPes_Cont,
--	CodMed,
--	Num_Proc,
--	NumParc_Proc
go

