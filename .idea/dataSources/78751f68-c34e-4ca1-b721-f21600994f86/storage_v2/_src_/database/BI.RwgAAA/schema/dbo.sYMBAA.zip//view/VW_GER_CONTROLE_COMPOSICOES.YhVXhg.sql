
CREATE VIEW [dbo].[VW_GER_CONTROLE_COMPOSICOES] AS

SELECT DISTINCT   
	Composicoes.COD_COMP AS COD_COMP,
	Composicoes.DESCR_COMP AS COMPOSICAO,
    Composicoes.Unid_comp
    --Composicoes.Prod_comp,
    --Composicoes.Obrig_comp,
    --Composicoes.Acab_comp,
    --Composicoes.Custo_comp,
    --ComposicoesSGQ.Controlar_Comp,
    --Composicoes.Status_comp,
    --Composicoes.UsrCad_comp,
    --Composicoes.AtInat_comp,
    --Composicoes.DataCad_comp,
    --Composicoes.UsrAlt_comp,
    --Composicoes.DataAlt_comp,
    --Composicoes.Anexos_Comp,
    --Case
    --    When Composicoes.CivilPes_comp IS null Then
    --        0
    --    Else
    --        Composicoes.CivilPes_comp
    --End CivilPes_comp,
    --ComposicoesSGQ.crite_comp,
    --ComposicoesSGQ.iden_comp,
    --ComposicoesSGQ.obs_comp,
    --ComposicoesSGQ.Orienta_comp,
    --ComposicoesSGQ.tipo_comp,
    --ComposicoesSGQ.verifi_comp,
    --Composicoes.Categ_comp,
    --Composicoes.Cap_Comp,
    --ComposicoesSGQ.iden_comp,
    --Composicoes.NCM_comp,
    --Composicoes.CapEstorno_comp,
    --CapEstorno.Desc_cger AS [CapEstorno.Desc_cger],
    --Composicoes.NumApi_comp,
    --AplicacaoProdInsumo.Descr_api,
    --Composicoes.NumCsf_comp,
    --CodigoServicoFiscal.Descr_csf,
    --Composicoes.CEST_comp,
    --TabNCm.Descr_ncm,
    --Composicoes.CapTransacaoFin_comp,
    --CAPTransacaoFin.Desc_cger AS [CAPTransacaoFin.Desc_cger],
    --Composicoes.CategMovFin_comp,
    --CategoriasDeMovFin.Desc_cmf,
    --CodigoServicoFiscal.CodigoCsrf_csf,
    --Composicoes.PorcTolEntrega_comp,
    --Composicoes.PorcTotPrecoUnit_comp,
    --Composicoes.PorcTotPrecoUnitReducao_comp
FROM UAU.dbo.Composicoes
    LEFT OUTER JOIN UAU.dbo.ComposicoesSGQ
        ON Composicoes.Cod_comp = ComposicoesSGQ.codComp_comp
    LEFT JOIN UAU.dbo.AplicacaoProdInsumo
        ON AplicacaoProdInsumo.Num_api = Composicoes.NumApi_comp
           AND AplicacaoProdInsumo.Tipo_api = 1
    LEFT JOIN UAU.dbo.CodigoServicoFiscal
        ON Composicoes.NumCsf_comp = CodigoServicoFiscal.Num_csf
    LEFT JOIN UAU.dbo.TabNCm
        ON Composicoes.NCM_comp = TabNCm.Codigo_ncm
    LEFT JOIN UAU.dbo.CAP AS CapEstorno
        ON Composicoes.CapEstorno_comp = CapEstorno.Codigo_cger
    LEFT JOIN UAU.dbo.CAP AS CAPTransacaoFin
        ON Composicoes.CapTransacaoFin_comp = CAPTransacaoFin.Codigo_cger
    LEFT JOIN UAU.dbo.CategoriasDeMovFin
        ON CategoriasDeMovFin.Codigo_cmf = CategMovFin_comp

go

