
CREATE VIEW [dbo].[VW_GER_CONTROLE_ITENS_PL_CONTRATO] AS 

--SALDO DE CONTRATO DAS OBRAS

SELECT 
SC.Empresa_ContPl as CodEmpresa,
E.Desc_Emp as DescEmpresa,
SC.Obra_ContPL as CodObra,
O.Descr_Obr as DescObra,
SC.Item_ContPl as ItemPl,
SC.Serv_ContPl as ServiçoPl,
PL.Descr_plt as DescriçãoItem,
SC.ValorVinc_ContPl as Vinculado,
SC.ValorAprov_ContPl as Aprovado,
SC.ValorVinc_ContPl - ValorAprov_ContPl AS Saldo,
SC.Contrato_ContPl as ContratoPl,
SC.Produto_ContPl as ProdPl,
C.Objeto_Cont as Objeto,
C.Cod_Cont as Contrato,
C.CodPes_Cont as CodContratado,
P.Nome_pes as Contratado,
I.Cod_ins,
I.Descr_ins,
CASE 
    WHEN C.Situacao_cont = 0 THEN 'Andamento'
    WHEN C.Situacao_cont = 1 THEN 'Paralisado'
    WHEN C.Situacao_cont = 2 THEN 'Cancelado'
    WHEN C.Situacao_cont = 3 THEN 'Concluído'
END AS Situacao_cont 
FROM UAU.dbo.ContratoPL as SC
    INNER JOIN UAU.dbo.Contratos as C
        ON SC.Empresa_ContPl = C.Empresa_Cont
           AND SC.CodCont_ContPl = C.Cod_Cont
    INNER JOIN UAU.dbo.PlanTotal as PL
        ON PL.Empresa_plt = SC.Empresa_ContPl
           AND PL.Obra_plt = SC.Obra_ContPL
           AND PL.Contrato_plt = SC.Contrato_ContPl
           AND PL.Prod_plt = SC.Produto_ContPl
           AND PL.Item_plt = SC.Item_ContPl
           AND PL.Serv_plt = SC.Serv_ContPL
    LEFT JOIN UAU.dbo.Empresas as E
        ON SC.Empresa_ContPl = E.Codigo_Emp
    LEFT JOIN UAU.dbo.Obras as O
        ON SC.Empresa_ContPl = O.Empresa_Obr
           AND SC.Obra_ContPl = O.Cod_Obr
    INNER JOIN UAU.dbo.Insumos as I
        ON I.Empresa_ins = SC.Empresa_ContPl
           AND I.Obra_ins = SC.Obra_ContPl
           AND I.Cod_ins = SC.Ins_ContPl
    LEFT JOIN UAU.dbo.Pessoas as P
        ON C.CodPes_Cont = P.Cod_Pes
WHERE C.Situacao_cont IN ( 0, 1, 2, 3 )
--AND  O.cod_obr = '5401C'
--AND E.Codigo_emp = '54'
--ORDER BY SC.Empresa_ContPl,
--         SC.Obra_ContPl,
--         SC.Item_ContPl


go

