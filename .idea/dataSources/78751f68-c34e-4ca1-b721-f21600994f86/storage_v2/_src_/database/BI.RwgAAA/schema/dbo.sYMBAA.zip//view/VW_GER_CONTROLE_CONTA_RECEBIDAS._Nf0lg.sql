


CREATE VIEW [dbo].[VW_GER_CONTROLE_CONTA_RECEBIDAS] AS 


WITH RecebePgto AS (
SELECT 
	Extrato.data_doc AS DataConcil
	, RecebePgto_1.empresa_rpg
	, RecebePgto_1.numreceb_rpg
	, RecebePgto_1.tipo_rpg -- tipo de negociação (renegociação)
	, RecebePgto_1.numcont_rpg
	, RecebePgto_1.bancochq_rpg
	, RecebePgto_1.agenciachq_rpg
	, RecebePgto_1.contachq_rpg
	, RecebePgto_1.prorrogachq_rpg
	, RecebePgto_1.cheque_rpg
	, RecebePgto_1.datacad_rpg
	, RecebePgto_1.valor_rpg
	, RecebePgto_1.desctit_rpg
	, RecebePgto_1.userresp_rpg
	, RecebePgto_1.user_rpg
	, RecebePgto_1.status_rpg
	, RecebePgto_1.bancodep_rpg
	, RecebePgto_1.datadep_rpg
	, RecebePgto_1.agenciadep_rpg
	, RecebePgto_1.contadep_rpg
	, RecebePgto_1.numdep_rpg
	, RecebePgto_1.datadev_rpg
	, RecebePgto_1.cliente_rpg
FROM UAU.dbo.RecebePgto AS RecebePgto_1 WITH (NOLOCK)
    INNER JOIN UAU.dbo.Extrato WITH (NOLOCK)
        ON RecebePgto_1.empresa_rpg = Extrato.empresa_doc
            AND RecebePgto_1.bancodep_rpg = Extrato.banco_doc
            AND RecebePgto_1.contadep_rpg = Extrato.conta_doc
            AND Cast(RecebePgto_1.numdep_rpg AS VARCHAR) = Extrato.numero_doc
)

SELECT 
	--Cast(Recebidas.Empresa_Rec AS VARCHAR) + '-' + Recebidas.Obra_Rec  AS CHAVE
	--Cast(Recebidas.Empresa_Rec AS VARCHAR) + '-' + Recebidas.Obra_Rec + '-' + Cast(Recebidas.NumVend_Rec AS VARCHAR) AS CHAVE_VENDA
	--Cast(Recebidas.Empresa_Rec AS VARCHAR) + '-' + Recebidas.Obra_Rec + '-' + Cast(UnidadePer.prod_unid AS VARCHAR) AS CHAVE_PROD,
	Recebidas.Empresa_Rec AS CODEMP, -- codigo da empresa
	UPPER(Empresas.desc_emp) AS EMPRESA,
	UnidadePer.identificador_unid,
	Pessoas.nome_pes AS Cliente,
	Recebidas.Obra_Rec AS Obra_Rpd, -- codigo da obra
	UPPER(Obras.descr_obr)  AS OBRA,
	Recebidas.NumVend_Rec AS VENDA, -- codigo do contrato de venda
	Recebidas.Cliente_Rec, -- codigo da cliente
	Pessoas.nome_pes  AS Nome_Pes,
	Recebidas.DataVenci_Rec AS [DATA VENCIMENTO],
	RecebePgto.datadep_rpg, --AS [DATA_PAGAMENTO],
	UPPER(Parcelas.descricao_par) AS Tipo, -- tipo_rec (descricao de tipo exemplo: Renegociacao)
	UPPER(TipoVenc.Descr_tv) AS Frequencia,
	Recebidas.NumParc_Rec AS PARCELARECEBIDA, --ref de qual parcela do contrato de venda
	Recebidas.NumParcGer_Rec, --total de parcelas do contrato de venda
	RecebePgto.dataconcil AS dataconcil,
	CAST(RecebePgtoDiv.percentvalor_rpd * ItensRecebidas.porcentitem_itr AS numeric(18,2)) AS VALORDEPOSITADO,
	RecebePgto.numdep_rpg AS numdep_rpg,
	Parcelas.tipo_par AS TIPOPARC,
	Recebidas.TotParc_Rec,
	ItensRecebidas.produto_itr AS produto_itr,
	RecebePgtoDiv.numparc_rpd AS numparc_rpd,
	RecebePgtoDiv.numparcger_rpd AS numparcger_rpd,
	CAST(Recebidas.VlMultaConf_Rec AS numeric(18,2)) AS vlmultaconf_rec,
	CAST((CASE 
		WHEN Recebidas.Tipo_Rec IN ( 'R', 'A' )
			THEN (
				CASE 
					WHEN VendasRecebidas.AniversarioContr_VRec = 0 
						THEN Recebidas.ValorConf_Rec
					ELSE Recebidas.ValorConf_Rec + Recebidas.VlJurosParcEmbConf_Rec + Recebidas.VlCorrecaoEmbConf_Rec END
			) + (
				CASE 
					WHEN VendasRecebidas.AniversarioContr_VRec = 0 
						THEN Recebidas.VlCorrecaoConf_Rec
						ELSE Recebidas.VlCorrecaoConf_Rec - Recebidas.VlCorrecaoEmbConf_Rec END
			)
			ELSE (
				CASE 
					WHEN VendasRecebidas.AniversarioContr_VRec = 0 
						THEN Recebidas.VlCorrecaoConf_Rec
						ELSE Recebidas.VlCorrecaoConf_Rec - Recebidas.VlCorrecaoEmbConf_Rec END
			)
	END) AS numeric(18,2)) AS vlcorrecaoconf_rec,
	CAST((CASE 
		WHEN VendasRecebidas.AniversarioContr_VRec = 0 
			THEN Recebidas.VlJurosParcConf_Rec
			ELSE Recebidas.VlJurosParcConf_Rec - Recebidas.VlJurosParcEmbConf_Rec
	END) AS numeric(18,2)) AS vljurosparcconf_rec,
	CAST(Recebidas.VlJurosConf_Rec AS numeric(18,2))  AS vljurosconf_rec,
	CAST(Recebidas.VlDescontoConf_Rec AS numeric(18,2))  AS vldescontoconf_rec,
	CAST(Recebidas.VlAcresConf_Rec AS numeric(18,2))  AS vlacresconf_rec,
	CAST(Recebidas.ValorPrincipalPrice_rec AS numeric(18,2))  AS valorprincipalprice_rec -- valor principal

/*DEMAIS COLUNAS*/
/*
Tipo_Rec,
Data_Rec,
ParcType_Rec,
Status_Rec,
VlrDescAdiant_Rec,
Valor_Rec = CASE
WHEN Recebidas.Tipo_Rec IN ( 'R', 'A' ) THEN
0
ELSE
(CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
Recebidas.Valor_Rec
ELSE
Recebidas.Valor_Rec + Recebidas.VlJurosParcEmb_Rec + Recebidas.VlCorrecaoEmb_Rec
END
)
END,
ValorConf_Rec = CASE
WHEN Recebidas.Tipo_Rec IN ( 'R', 'A' ) THEN
0
ELSE
(CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
Recebidas.ValorConf_Rec
ELSE
Recebidas.ValorConf_Rec + Recebidas.VlJurosParcEmbConf_Rec + Recebidas.VlCorrecaoEmbConf_Rec
END
)
END,
VlCorrecao_Rec = CASE
WHEN Recebidas.Tipo_Rec IN ( 'R', 'A' ) THEN
(CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
Recebidas.Valor_Rec
ELSE
Recebidas.Valor_Rec + Recebidas.VlJurosParcEmb_Rec + Recebidas.VlCorrecaoEmb_Rec
END
) + (CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
Recebidas.VlCorrecao_Rec
ELSE
Recebidas.VlCorrecao_Rec - Recebidas.VlCorrecaoEmb_Rec
END
)
ELSE
(CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
Recebidas.VlCorrecao_Rec
ELSE
Recebidas.VlCorrecao_Rec - Recebidas.VlCorrecaoEmb_Rec
END
)
END,
VlCorrecaoConf_Rec = CASE
WHEN Recebidas.Tipo_Rec IN ( 'R', 'A' ) THEN
(CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
Recebidas.ValorConf_Rec
ELSE
Recebidas.ValorConf_Rec + Recebidas.VlJurosParcEmbConf_Rec + Recebidas.VlCorrecaoEmbConf_Rec
END
) + (CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
Recebidas.VlCorrecaoConf_Rec
ELSE
Recebidas.VlCorrecaoConf_Rec - Recebidas.VlCorrecaoEmbConf_Rec
END
)
ELSE
(CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
Recebidas.VlCorrecaoConf_Rec
ELSE
Recebidas.VlCorrecaoConf_Rec - Recebidas.VlCorrecaoEmbConf_Rec
END
)
END,
(CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
Recebidas.VlJurosParc_Rec
ELSE
Recebidas.VlJurosParc_Rec - Recebidas.VlJurosParcEmb_Rec
END
) AS VlJurosParc_Rec,
(CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
Recebidas.VlJurosParcConf_Rec
ELSE
Recebidas.VlJurosParcConf_Rec - Recebidas.VlJurosParcEmbConf_Rec
END
) AS VlJurosParcConf_Rec,
VlMulta_Rec,
VlJuros_Rec,
VlDesconto_Rec,
VlAcres_Rec,
NumReceb_Rec,
OrigParc_Rec,
User_Rec,
PorcentVl_Rec,
GrupoParc_Rec,
UserDesc_Rec,
JurosParc_Rec,
IdxReaj_Rec,
ValorResiduo_Rec,
GrupoIdx_Rec,
DtIdxParc_Rec,
DtCalReaj_Rec,
AmortParc_Rec,
--JurosParc_Rec,
DtParc_Rec,
DtJurParc_Rec,
ComoParc_Rec,
Cap_Rec,
EParte_Rec,
VlCorrecaoAtr_Rec,
VlTaxaBol_Rec,
VlCorrecaoAtrConf_Rec,
VlTaxaBolConf_Rec,
Anexos_Rec,
BegEndParc_Rec,
AniversarioContr_VRec,
OrigemCusta_Rec,
ValDescontoCusta_Rec,
ValDescontoCustaConf_Rec,
ValDescontoImposto_Rec,
ValDescontoImpostoConf_Rec,
Descr_ctp,
TotParcGrupo_Rec,
DataCad_Rec,
DtJurosComJuros_Rec,
Obs_Rec,
DataSegJuros_Rec,
PorcSegJuros_Rec,
CarenciaAtraso_Rec,
CarenciaAtrasoCorrecao_Rec,
CobrarJurosProRata_Rec,
TipoSeguro_Rec,
CobrarJurosProRataPrimeiroMes_Rec,
ValDescontoCondicional_Rec,
ValDescontoCondicionalConf_Rec,
DataIniPeriodoAluguel_rec,
ValorJurosPrice_rec,
NumMdrPreferencial_rec,
(Recebidas.ValDescontoCondicional_rec + Recebidas.ValDescontoCondicionalConf_rec) AS TotDescCondic,
TipoVenc.Cod_tv,
TipoVenc.Freq_tv,
TipoVenc.Fixo_tv,
TipoVenc.Dia_tv,
TipoVenc.Interv_tv,
TipoVenc.TipoInt_tv,
TipoVenc.TipoCont_tv,
TipoVenc.Inicio_tv,
TipoVenc.Util_tv,
TipoVenc.AtInat_tv,
TipoVenc.Anexos_Tv,
TipoVenc.AntProrr_tv,
Obras.ValidaFeriado_Obr,
Indices.Tipo_idx,
Empresa_vvc,
Obra_vvc,
NumVend_vvc,
TipoValor_dcv,
Valor_dcv,
ReferenciaDataLimite_dcv,
Dia_dcv,
ISNULL(PesVenda.RecebeBoletoCorreio_pven, CAST(1 As BIT)) As RecebeBoletoCorreio_pven,
ISNULL(PesVenda.RecebeBoletoEmail_pven, CAST(0 As BIT)) As RecebeBoletoEmail_pven,
Obras.NumPcbAvulso_obr,
ParamCobBoletoAvulso.Descr_pcb As DescrPcbAvulso,
NotasFiscais.NumNfAux_nf AS NumNFAux,
NotasFiscais.Num_nf As Num_nf,
VendaCarteiraReceberRecebida.NumeroContrato_vc
(((Recebidas.Valor_Rec + Recebidas.VlJurosParc_Rec + Recebidas.VlCorrecao_Rec + Recebidas.VlAcres_Rec
+ Recebidas.VlTaxaBol_Rec + Recebidas.VlMulta_Rec + Recebidas.VlJuros_Rec + Recebidas.VlCorrecaoAtr_Rec
)
- (Recebidas.VlDesconto_Rec + Recebidas.ValDescontoCusta_Rec + Recebidas.ValDescontoImposto_Rec
+ Recebidas.ValDescontoCondicional_rec
)
)
+ ((Recebidas.ValorConf_Rec + Recebidas.VlJurosParcConf_Rec + Recebidas.VlCorrecaoConf_Rec
+ Recebidas.VlAcresConf_Rec + Recebidas.VlTaxaBolConf_Rec + Recebidas.VlMultaConf_Rec
+ Recebidas.VlJurosConf_Rec + Recebidas.VlCorrecaoAtrConf_Rec
)
- (Recebidas.VlDescontoConf_Rec + Recebidas.ValDescontoCustaConf_Rec + Recebidas.ValDescontoImpostoConf_Rec
+ Recebidas.ValDescontoCondicionalConf_rec
)
)
) AS TotParcel,
((Recebidas.ValorConf_Rec + Recebidas.VlJurosParcConf_Rec + Recebidas.VlCorrecaoConf_Rec
+ Recebidas.VlAcresConf_Rec + Recebidas.VlTaxaBolConf_Rec + Recebidas.VlMultaConf_Rec
+ Recebidas.VlJurosConf_Rec + Recebidas.VlCorrecaoAtrConf_Rec
)
- (Recebidas.VlDescontoConf_Rec + Recebidas.ValDescontoCustaConf_Rec + Recebidas.ValDescontoImpostoConf_Rec
+ Recebidas.ValDescontoCondicionalConf_rec
)
) AS TotConf,
((Recebidas.Valor_Rec + Recebidas.VlJurosParc_Rec + Recebidas.VlCorrecao_Rec + Recebidas.VlAcres_Rec
+ Recebidas.VlTaxaBol_Rec + Recebidas.VlMulta_Rec + Recebidas.VlJuros_Rec + Recebidas.VlCorrecaoAtr_Rec
)
- (Recebidas.VlDesconto_Rec + Recebidas.ValDescontoCusta_Rec + Recebidas.ValDescontoImposto_Rec
+ Recebidas.ValDescontoCondicional_rec
)
) AS TotNConf,
((Recebidas.VlDesconto_Rec + Recebidas.VlDescontoConf_Rec)
+ (Recebidas.ValDescontoCondicional_rec + Recebidas.ValDescontoCondicionalConf_rec)
) AS TotDesc,
(Recebidas.ValDescontoCusta_Rec + Recebidas.ValDescontoCustaConf_Rec) AS TotDescCusta,
(Recebidas.ValDescontoImposto_Rec + Recebidas.ValDescontoImpostoConf_Rec) AS TotDescImposto,
TotPrinc = CASE
WHEN Recebidas.Tipo_Rec IN ( 'R', 'A' ) THEN
0
ELSE
(CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
(Recebidas.Valor_Rec + Recebidas.ValorConf_Rec)
ELSE
((Recebidas.Valor_Rec + Recebidas.ValorConf_Rec)
+ (Recebidas.VlJurosParcEmb_Rec + Recebidas.VlJurosParcEmbConf_Rec)
+ (Recebidas.VlCorrecaoEmb_Rec + Recebidas.VlCorrecaoEmbConf_Rec)
)
END
)
END,
(CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
(Recebidas.VlJurosParc_Rec + Recebidas.VlJurosParcConf_Rec)
ELSE
(Recebidas.VlJurosParc_Rec + Recebidas.VlJurosParcConf_Rec)
- (Recebidas.VlJurosParcEmb_Rec + Recebidas.VlJurosParcEmbConf_Rec)
END
) AS TotJurParc,
TotCorrecao = CASE
WHEN Recebidas.Tipo_Rec IN ( 'R', 'A' ) THEN
(CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
(Recebidas.VlCorrecao_Rec + Recebidas.VlCorrecaoConf_Rec)
ELSE
(Recebidas.VlCorrecao_Rec + Recebidas.VlCorrecaoConf_Rec)
- (Recebidas.VlCorrecaoEmb_Rec + Recebidas.VlCorrecaoEmbConf_Rec)
END
)
+ (CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
(Recebidas.Valor_Rec + Recebidas.ValorConf_Rec)
ELSE
((Recebidas.Valor_Rec + Recebidas.ValorConf_Rec)
+ (Recebidas.VlJurosParcEmb_Rec + Recebidas.VlJurosParcEmbConf_Rec)
+ (Recebidas.VlCorrecaoEmb_Rec + Recebidas.VlCorrecaoEmbConf_Rec)
)
END
)
ELSE
(CASE VendasRecebidas.AniversarioContr_VRec
WHEN 0 THEN
(Recebidas.VlCorrecao_Rec + Recebidas.VlCorrecaoConf_Rec)
ELSE
(Recebidas.VlCorrecao_Rec + Recebidas.VlCorrecaoConf_Rec)
- (Recebidas.VlCorrecaoEmb_Rec + Recebidas.VlCorrecaoEmbConf_Rec)
END
)
END,
(Recebidas.VlMulta_Rec + Recebidas.VlMultaConf_Rec) AS TotMulta,
(Recebidas.VlJuros_Rec + Recebidas.VlJurosConf_Rec) AS TotJuros,
(Recebidas.VlAcres_Rec + Recebidas.VlAcresConf_Rec) AS TotAcresc,
(Recebidas.VlCorrecaoAtr_Rec + Recebidas.VlCorrecaoAtrConf_Rec) AS TotCorrAtr,
(Recebidas.VlTaxaBol_Rec + Recebidas.VlTaxaBolConf_Rec) AS TotTaxaBol,
(Recebidas.VlJurosParcEmb_Rec + Recebidas.VlJurosParcEmbConf_Rec) AS JurosEmb,
*/

FROM UAU.dbo.VendasRecebidas WITH (NOLOCK)

INNER JOIN UAU.dbo.Recebidas WITH (NOLOCK)
	ON VendasRecebidas.Empresa_VRec = Recebidas.Empresa_Rec
	AND VendasRecebidas.Obra_VRec = Recebidas.Obra_Rec
	AND VendasRecebidas.Num_VRec = Recebidas.NumVend_Rec

INNER JOIN UAU.dbo.RecebePgtoDiv WITH (NOLOCK)
	ON RecebePgtoDiv.empresa_rpd = Recebidas.empresa_rec
		AND RecebePgtoDiv.numvend_rpd = Recebidas.numvend_rec
		AND RecebePgtoDiv.obra_rpd = Recebidas.obra_rec
		AND RecebePgtoDiv.numparc_rpd = Recebidas.numparc_rec
		AND RecebePgtoDiv.parctype_rpd = Recebidas.parctype_rec
		AND RecebePgtoDiv.tipo_rpd = Recebidas.tipo_rec
		AND RecebePgtoDiv.numparcger_rpd = Recebidas.numparcger_rec

INNER JOIN RecebePgto WITH (NOLOCK)
	ON RecebePgto.empresa_rpg = RecebePgtoDiv.empresa_rpd
		AND RecebePgto.numreceb_rpg = RecebePgtoDiv.numreceb_rpd
		AND RecebePgto.tipo_rpg = RecebePgtoDiv.tiporpg_rpd
		AND RecebePgto.numcont_rpg = RecebePgtoDiv.numcont_rpd

INNER JOIN UAU.dbo.Parcelas WITH (NOLOCK)
	ON Recebidas.tipo_rec = Parcelas.tipo_par

INNER JOIN UAU.dbo.ItensRecebidas WITH (NOLOCK)
	ON VendasRecebidas.Empresa_VRec = ItensRecebidas.empresa_itr
		AND VendasRecebidas.Obra_VRec = ItensRecebidas.obra_itr
		AND VendasRecebidas.Num_VRec = ItensRecebidas.numvend_itr

LEFT OUTER JOIN UAU.dbo.UnidadePer WITH (NOLOCK)
	ON ItensRecebidas.empresa_itr = UnidadePer.empresa_unid
		AND ItensRecebidas.produto_itr = UnidadePer.prod_unid
		AND ItensRecebidas.codperson_itr = UnidadePer.numper_unid

INNER JOIN UAU.dbo.Empresas WITH (NOLOCK)
	ON Recebidas.empresa_rec = Empresas.codigo_emp

INNER JOIN UAU.dbo.Obras WITH (NOLOCK)
	ON VendasRecebidas.Empresa_vrec = Obras.Empresa_obr
		AND VendasRecebidas.Obra_VRec = Obras.cod_obr

INNER JOIN UAU.dbo.TipoVenc WITH (NOLOCK)
	ON Recebidas.ComoParc_Rec = TipoVenc.cod_tv

INNER JOIN UAU.dbo.Indices WITH (NOLOCK)
	ON Recebidas.IdxReaj_Rec = Indices.Cod_idx

INNER JOIN UAU.dbo.Pessoas WITH (NOLOCK)
	ON Pessoas.Cod_pes = Recebidas.Cliente_Rec

LEFT JOIN UAU.dbo.CustasTipo WITH (NOLOCK)
	ON CustasTipo.Num_Ctp = Recebidas.NumCtp_Rec

LEFT JOIN (
	SELECT 
		EmpresaLink_vvc,
		ObraLink_vvc,
		NumVendLink_vvc,
		Empresa_vvc,
		Obra_vvc,
		NumVend_vvc
	FROM UAU.dbo.VendasVinculo WITH (NOLOCK)

	UNION

	SELECT 
		Empresa_vvc,
		Obra_vvc,
		NumVend_vvc,
		Empresa_vvc,
		Obra_vvc,
		NumVend_vvc
	FROM UAU.dbo.VendasVinculo WITH (NOLOCK)
) VendasVinculo
	ON VendasVinculo.EmpresaLink_vvc = VendasRecebidas.Empresa_vrec
		AND VendasVinculo.ObraLink_vvc = VendasRecebidas.Obra_vrec
		AND VendasVinculo.NumVendLink_vvc = VendasRecebidas.Num_vrec

LEFT JOIN UAU.dbo.DescontoCondicionalVinculado AS DCV WITH (NOLOCK)
	ON Recebidas.Empresa_rec = DCV.Empresa_dcv
		AND Recebidas.Obra_rec = DCV.Obra_dcv
		AND Recebidas.NumVend_rec = DCV.NumVend_dcv
		AND Recebidas.NumParc_rec = DCV.NumParc_dcv
		AND Recebidas.NumParcGer_rec = DCV.NumParcGer_dcv
		AND Recebidas.Tipo_rec = DCV.Tipo_dcv

LEFT JOIN UAU.dbo.PesVenda WITH (NOLOCK)
	ON PesVenda.CodPes_pven = VendasRecebidas.Cliente_VRec

LEFT JOIN UAU.dbo.ParametroCobranca AS ParamCobBoletoAvulso WITH (NOLOCK)
	ON ParamCobBoletoAvulso.Empresa_pcb = Obras.Empresa_obr
		AND ParamCobBoletoAvulso.Num_pcb = Obras.NumPcbAvulso_obr

LEFT JOIN UAU.dbo.VinculoNotaVendaParcela With (NOLOCK)
	ON VinculoNotaVendaParcela.Empresa_vnvp = Recebidas.Empresa_rec
		AND VinculoNotaVendaParcela.ObraVend_vnvp = Recebidas.Obra_Rec
		AND VinculoNotaVendaParcela.NumVend_vnvp = Recebidas.NumVend_Rec
		AND VinculoNotaVendaParcela.NumParc_vnvp = Recebidas.NumParc_Rec
		AND VinculoNotaVendaParcela.NumParcGer_vnvp = Recebidas.NumParcGer_Rec
		AND VinculoNotaVendaParcela.TipoParc_vnvp = Recebidas.Tipo_Rec

LEFT JOIN UAU.dbo.NotasFiscais With (NOLOCK)
	ON NotasFiscais.Empresa_nf = VinculoNotaVendaParcela.Empresa_vnvp
		AND NotasFiscais.Num_nf = VinculoNotaVendaParcela.NumNF_vnvp

LEFT JOIN (
	SELECT 
		Empresa_vcr,
		Obra_vcr,
		NumVend_vcr,
		Tipo_vcr,
		NumParc_vcr,
		NumParcGer_vcr,
		NumeroContrato_vc
	FROM UAU.dbo.vwVendaCarteira_status_parcela_operacao With (NOLOCK)
) VendaCarteiraReceberRecebida
	ON VendaCarteiraReceberRecebida.Empresa_vcr = Recebidas.Empresa_rec
		AND VendaCarteiraReceberRecebida.Obra_vcr = Recebidas.Obra_Rec
		AND VendaCarteiraReceberRecebida.NumVend_vcr = Recebidas.NumVend_Rec
		AND VendaCarteiraReceberRecebida.NumParc_vcr = Recebidas.NumParc_Rec
		AND VendaCarteiraReceberRecebida.NumParcGer_vcr = Recebidas.NumParcGer_Rec
		AND VendaCarteiraReceberRecebida.Tipo_vcr = Recebidas.Tipo_Rec

--WHERE Recebidas.Obra_Rec = '5201I'
--	AND Recebidas.NumVend_Rec = 29
--	AND Recebidas.Empresa_Rec = 52

--ORDER BY Recebidas.Data_Rec
go

