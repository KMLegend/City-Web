create view dbo.VW_GER_CONTROLE_DESCONTO_CONTA_RECEBIDAS as 

SELECT DISTINCT
	Empresas.Codigo_emp,
	--Empresas.Desc_emp,
	--Empresas.NomeFantasia_emp,
	Pessoas.cod_pes AS cod_pes,
	Pessoas.nome_pes AS Nome,
	Recebidas.User_Rec AS UsuárioRecebeu,
	CASE
		WHEN ((CAST((DATEDIFF(dd, Recebidas.DataVenci_Rec, Recebidas.Data_Rec)) AS int)) < 0) THEN 'Antecipação'
		ELSE 'Desconto' END AS Tipo,
	Parcelas.Descricao_par AS [Tipo Parcela],
	Recebidas.NumVend_Rec,
	Recebidas.NumParc_Rec AS Parcela,
	Recebidas.DataVenci_Rec AS DataVencimento,
	Recebidas.Data_Rec AS DataRecebimento,
	--Recebidas.ValorConf_Rec,
	Recebidas.Valor_Rec + Recebidas.ValorConf_Rec AS [ValorOriginalContratoReceber-R$],  -- valor original da parcela do contrato
	(CASE 
		WHEN VendasRecebidas.AniversarioContr_VRec = 0 
			THEN (Recebidas.VlJurosParc_Rec + Recebidas.VlJurosParcConf_Rec)
		ELSE (Recebidas.VlJurosParc_Rec + Recebidas.VlJurosParcConf_Rec) - (Recebidas.VlJurosParcEmb_Rec + Recebidas.VlJurosParcEmbConf_Rec)
	END) --AS TotJurParc,
	+
    (CASE 
		WHEN VendasRecebidas.AniversarioContr_VRec = 0 
			THEN (Recebidas.VlCorrecao_Rec + Recebidas.VlCorrecaoConf_Rec)
		ELSE
			(Recebidas.VlCorrecao_Rec + Recebidas.VlCorrecaoConf_Rec)
			- (Recebidas.VlCorrecaoEmb_Rec + Recebidas.VlCorrecaoEmbConf_Rec)
	END) --AS ValorCorrecao_Prc,
	+
    (CASE 
        WHEN VendasRecebidas.AniversarioContr_VRec = 0 
		THEN (Recebidas.Valor_Rec + Recebidas.ValorConf_Rec)
        ELSE
			((Recebidas.Valor_Rec + Recebidas.ValorConf_Rec)
			+ (Recebidas.VlJurosParcEmb_Rec + Recebidas.VlJurosParcEmbConf_Rec)
			+ (Recebidas.VlCorrecaoEmb_Rec + Recebidas.VlCorrecaoEmbConf_Rec))
    END) --AS VlrPrincipal_Prc 	
	 AS [ValorOriginalContratoCorrigido-R$],  -- valor original da parcela do contrato
	Recebidas.VlAcres_Rec + Recebidas.VlAcresConf_Rec AS [Acrescimo-R$],
	Recebidas.VlDesconto_Rec + Recebidas.VlDescontoConf_Rec AS [ValorDesconto-R$],
	RecebePgtoDiv.percentvalor_rpd * ItensRecebidas.porcentitem_itr  AS [ValorRecebido-R$]


	--CAST((DATEDIFF(dd, Recebidas.DataVenci_Rec, GETDATE())) AS int) AS [Dif. dias até hoje]
FROM UAU.dbo.Recebidas
INNER JOIN UAU.dbo.Pessoas
    ON Recebidas.Cliente_Rec = Pessoas.cod_pes
INNER JOIN UAU.dbo.Parcelas
    ON Recebidas.Tipo_Rec = Parcelas.Tipo_par
LEFT OUTER JOIN UAU.dbo.Empresas
    ON Recebidas.Empresa_rec = Empresas.Codigo_emp


INNER JOIN UAU.dbo.VendasRecebidas WITH (NOLOCK)
	ON VendasRecebidas.Empresa_VRec = Recebidas.Empresa_Rec
	AND VendasRecebidas.Obra_VRec = Recebidas.Obra_Rec
	AND VendasRecebidas.Num_VRec = Recebidas.NumVend_Rec

INNER JOIN UAU.dbo.ItensRecebidas WITH (NOLOCK)
	ON VendasRecebidas.Empresa_VRec = ItensRecebidas.empresa_itr
		AND VendasRecebidas.Obra_VRec = ItensRecebidas.obra_itr
		AND VendasRecebidas.Num_VRec = ItensRecebidas.numvend_itr

INNER JOIN UAU.dbo.RecebePgtoDiv WITH (NOLOCK)
	ON RecebePgtoDiv.empresa_rpd = Recebidas.empresa_rec
		AND RecebePgtoDiv.numvend_rpd = Recebidas.numvend_rec
		AND RecebePgtoDiv.obra_rpd = Recebidas.obra_rec
		AND RecebePgtoDiv.numparc_rpd = Recebidas.numparc_rec
		AND RecebePgtoDiv.parctype_rpd = Recebidas.parctype_rec
		AND RecebePgtoDiv.tipo_rpd = Recebidas.tipo_rec
		AND RecebePgtoDiv.numparcger_rpd = Recebidas.numparcger_rec



WHERE 
--Empresa_rec = 13
--and NumVend_Rec = 72
--and (
((Recebidas.VlDesconto_Rec + Recebidas.VlDescontoConf_Rec > 0)
--AND (DATEDIFF(dd, Recebidas.Data_Rec, GETDATE()) <= 7)
--AND (DATEDIFF(dd, Recebidas.Data_Rec, GETDATE()) >= 0))
OR 
--((DATEDIFF(dd, Recebidas.Data_Rec, GETDATE()) <= 7)
--AND (DATEDIFF(dd, Recebidas.Data_Rec, GETDATE()) >= 0)
 (Recebidas.VlAcresConf_Rec + Recebidas.VlAcres_Rec > 100))
 --)
--ORDER BY 1,2,7,8,9
	--Tipo,
	--[Dif. dias até hoje],
	--UsuárioRecebeu DESC
go

