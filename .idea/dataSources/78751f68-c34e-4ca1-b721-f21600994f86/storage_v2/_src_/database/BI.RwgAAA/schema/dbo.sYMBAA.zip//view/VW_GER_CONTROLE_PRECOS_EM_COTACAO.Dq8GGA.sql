


 CREATE VIEW [dbo].[VW_GER_CONTROLE_PRECOS_EM_COTACAO] AS 
 
SELECT		
		Empresa_temp,				
		Obra_temp,				
		NumPedido_temp AS Pedido,
		Cotacao_temp,
		Insumo_temp,
		InsumosGeral.Descr_ins  Insumo,
		Qtde_temp Qtde,
		'0 - Não Cotado' Localizacao,
		Unid_temp,
		'Insumo' Tipo
	FROM UAU.dbo.ItensCot_temp			
	LEFT JOIN UAU.dbo.Empresas	
		ON Empresa_temp = Codigo_emp
	LEFT JOIN UAU.dbo.Obras	
		ON Obra_temp = cod_obr
			AND Empresa_temp = Empresa_obr
	LEFT JOIN UAU.dbo.InsumosGeral 
		ON Cod_ins = Insumo_temp
	LEFT JOIN UAU.dbo.Entrega
		ON Empresa_ent = Empresa_temp
			AND NumCot_ent = Cotacao_temp
	/*Avalia retirar e aplicar como filtro*/
	--INNER JOIN (
	--	SELECT * 
	--	FROM fn_ListEmpObr('28|2801C', ',')
	--) AS EmprObr
	--	ON Empresa = Empresa_temp
	--	AND Obra = Obra_temp
		/**/
	WHERE Estagio_temp <= 4	
		--Filtra por pedidos que não foram excluídos
		AND Excluido_temp <> 1
		and Cotacao_temp = 0
		--AND Empresa_temp = 28 --:empresa
		--AND Obra_temp = '2801C'--:obraUAU

	union all
    
	SELECT	
		Empresa_temp,
		Obra_temp,
		NumPedido_temp  Pedido,
		Cotacao_temp,
		Insumo_temp,
		InsumosGeral.Descr_ins Insumo,
		Qtde_temp Qtde,
		'1 - Cotado' Localizacao,
		Unid_temp,
		'Insumo' Tipo
	FROM UAU.dbo.ItensCot_temp		
	LEFT JOIN UAU.dbo.Empresas 
		ON Empresa_temp = Codigo_emp
	LEFT JOIN UAU.dbo.Obras
		ON Obra_temp = cod_obr
			AND Empresa_temp = Empresa_obr
	LEFT JOIN UAU.dbo.InsumosGeral
		ON Cod_ins = Insumo_temp
	LEFT JOIN UAU.dbo.Entrega
		ON Empresa_ent = Empresa_temp
			AND NumCot_ent = Cotacao_temp
	/*Avalia retirar e aplicar como filtro*/
	--INNER JOIN (
	--	SELECT * 
	--	FROM fn_ListEmpObr('28|2801C', ',')
	--) AS EmprObr
	--	ON Empresa = Empresa_temp
	--		AND Obra = Obra_temp
			/**/
	WHERE Estagio_temp <= 4	
	--Filtra por pedidos que não foram excluídos
		AND Excluido_temp <> 1
		AND cotacao_temp >0
		--AND Empresa_temp = 28 --:empresa
		--AND Obra_temp = '2801C'--:obraUAU

	union ALL

	SELECT	         	
		ic.Empresa_ServTemp ,
		ic.Obra_ServTemp ,
		ic.NumPedido_ServTemp Pedido,
		ic.Cotacao_ServTemp ,
		ic.Serv_ServTemp ,
		c.Descr_comp Insumo,
		ic.Qtde_ServTemp Qtde,
		'0 - Não Cotado' Localizacao,
		ic.Unid_ServTemp,
		'Serviço' Tipo
	FROM UAU.dbo.ItensCotServ_temp ic			
	LEFT JOIN UAU.dbo.Composicoes c 
		ON ic.Serv_ServTemp = c.Cod_comp 
	WHERE ic.Estagio_ServTemp <= 4
		--and ic.Empresa_ServTemp = 28 --:empresa
		--and ic.Obra_ServTemp = '2801C'--:obraUAU
		AND ic.Excluido_Servtemp <> 1
		and coalesce(ic.Cotacao_ServTemp,0) = 0

	union all

	SELECT	         	
		ic.Empresa_ServTemp ,
		ic.Obra_ServTemp ,
		ic.NumPedido_ServTemp Pedido,
		ic.Cotacao_ServTemp ,
		ic.Serv_ServTemp ,
		c.Descr_comp Insumo,
		ic.Qtde_ServTemp Qtde,
		'0 - Não Cotado' Localizacao,
		ic.Unid_ServTemp,
		'Serviço' Tipo
	FROM UAU.dbo.ItensCotServ_temp ic			
	LEFT JOIN UAU.dbo.Composicoes c 
		ON ic.Serv_ServTemp = c.Cod_comp 
	inner join UAU.dbo.Cotacao c2 
		on  ic.Empresa_ServTemp  = c2.empresa_cot
			and ic.Cotacao_ServTemp = c2.Num_cot    
	WHERE ic.Estagio_ServTemp <= 5
		--and ic.Empresa_ServTemp = 28 --:empresa
		--and ic.Obra_ServTemp = '2801C'--:obraUAU
		AND ic.Excluido_Servtemp <> 1
		and coalesce(ic.Cotacao_ServTemp,0) > 0
		and c2.Status_cot<2		



-- rev03 larsson 
/*


select 
    s.Empresa_ServTemp Empresa_temp,
    s.Obra_ServTemp Obra_temp,
    s.Serv_ServTemp Insumo_temp,
    c.Descr_comp Insumo,
    s.Qtde_ServTemp Qtde, 
    '0- Não cotato' Localizacao,
    s.Unid_ServTemp Unid_temp,
    '0- Contrato' Origem,
    0.00000 Preco
  from ItensCotServ_temp s
  inner join Composicoes c on s.Serv_ServTemp  = c.Cod_comp 
  where s.Excluido_Servtemp  = 0
    and coalesce(s.Cotacao_ServTemp,0) = 0
    --and s.Obra_ServTemp  = :obrauau 
    --and s.Empresa_ServTemp  = :empresa

  UNION ALL

  select 
    s.Empresa_ServTemp Empresa_temp,
    s.Obra_ServTemp Obra_temp,
    s.Serv_ServTemp Insumo_temp,
    c.Descr_comp Insumo,
    ics.QtdeCot_ItemServ Qtde, 
    '1 - Cotado' Localizacao,
    ics.Unid_ItemServ Unid_temp,
    '0- Contrato' Origem,
    COALESCE (ics.Preco_ItemServ,0) Preco 
  from ItensCotServ_temp s
  inner join Composicoes c 
    on s.Serv_ServTemp  = c.Cod_comp 
  INNER JOIN Cotacao c2 
    on  s.Empresa_ServTemp =  c2.Empresa_cot
      and c2.Num_cot = s.Cotacao_ServTemp                           
  inner join ItensCotacaoServ ics 
    on  s.Serv_ServTemp = ics.serv_itemserv 
			and  s.Empresa_ServTemp = ics.Empresa_ItemServ
			and s.Cotacao_ServTemp = ics.NumCot_ItemServ 
	left join ItensSimuladosConfServ iscs 
    on s.Empresa_ServTemp = iscs.Empresa_SimcServ
	    and s.Serv_ServTemp  = iscs.Serv_SimcServ 
	    and s.Cotacao_ServTemp  = iscs.Cotacao_SimcServ 
  where iscs.Empresa_SimcServ  is null 
    and  coalesce(s.Cotacao_ServTemp,0) >0
    --and s.Obra_ServTemp  = :obrauau 
    --and s.Empresa_ServTemp  = :empresa
 
  union all   

  select 
    s.Empresa_temp Empresa_temp,
    s.Obra_Temp Obra_temp,
    s.Insumo_temp Insumo_temp,
    c.Descr_ins Insumo,
    ics.QtdeCot_item Qtde, 
    '1 - Cotado' Localizacao,
    ics.Unid_item Unid_temp,
    '1- Pedido' Origem,
    COALESCE (ics.Preco_item ,0) Preco
  from ItensCot_temp s
  inner join InsumosGeral c 
    on s.Insumo_temp = c.Cod_ins 
  INNER JOIN Cotacao c2 
    on  s.Empresa_temp =  c2.Empresa_cot
      and c2.Num_cot = s.Cotacao_temp 
  inner join ItensCotacao ics 
    on  s.Insumo_temp = ics.CodIns_item 
      and  s.Empresa_temp = ics.Empresa_item 
      and s.Cotacao_temp = ics.NumCot_item 
  left join ItensSimuladosConf iscs 
    on s.Empresa_Temp = iscs.Empresa_Simc 
      and s.Insumo_temp = iscs.CodIns_Simc 
      and s.Cotacao_temp = iscs.Condicao_Simc 
  left join OrdemCompra oc 
    on  s.Empresa_temp  = oc.Empresa_Ocp 
      and s.Obra_temp  = oc.Obra_Ocp 
      and s.Cotacao_temp  = oc.NumCot_Ocp 
  where s.Estagio_temp <=4 
    and iscs.Empresa_Simc is null 
    and COALESCE (s.Cotacao_temp,0) >0
    and oc.Empresa_Ocp is null 
    --and s.Obra_Temp =:obrauau 
    --and s.Empresa_temp =  :empresa
  
  union all
  
  select 
    s.Empresa_temp Empresa_temp,
    s.Obra_Temp Obra_temp,
    s.Insumo_temp Insumo_temp,
    c.Descr_ins Insumo,
    s.Qtde_temp Qtde, 
    '0 - Não cotado' Localizacao,
    s.Unid_temp Unid_temp,
    '1- Pedido' Origem,
    0.00000 Preco_item 
  from ItensCot_temp s
  inner join InsumosGeral c 
    on s.Insumo_temp = c.Cod_ins 
  where coalesce(s.Cotacao_temp,0) =0
    --and s.Obra_temp  = :obrauau 
    --and s.Empresa_temp = :empresa
	
*/
go

