

CREATE VIEW [dbo].[VW_GER_CONTROLE_STATUS_CONTRATO] AS

--Busca dados dos contratos por empresa, obra, número, situação e status do contrato no período.  
/* Variaveis:
Contrato - numero de contrato(% para todos contratos) - texto
Data Inicio - data inicial da busca - datetime
Data Termino - data inicial da busca - datetime
Empresa e Obra - busca emp e obra -- texto/numerico
Situação - Situação do contrato  (0=andamento; 1=paralizado; 2=cancelado; 3=concluído; 0,1,2,3=todos). -- numerico
Status - Status do contrato (0=não aprovado; 1=apovado; 2=em aditivo).  -- numerico
*/


SELECT
    --CAST(<DataInicio> AS DATETIME) [DataInicio], 
    --CAST(<DataTermino> AS DATETIME) [DataTermino], 
    Empresa_Cont,
    UPPER(CAST(Empresa_Cont AS VARCHAR) + ' - ' + Desc_Emp) [Empresa],
    Obra_Cont,
    UPPER(Obra_Cont + ' - ' + Descr_Obr) [Obra],
    Cod_Cont,
    UPPER(CAST(Cod_Cont AS VARCHAR) + ' - ' + Objeto_Cont) [Contrato],
    CodPes_Cont,
    UPPER(Nome_Pes) [Fornecedor],
    DtInicio_Cont,
    DtFim_Cont,
    CASE 
        WHEN Situacao_Cont = 0 THEN '0 - ANDAMENTO'
        WHEN Situacao_Cont = 1 THEN '1 - PARALIZADO'
        WHEN Situacao_Cont = 2 THEN '2 - CANCELADO'
        WHEN Situacao_Cont = 3 THEN '3 - CONCLUÍDO'
    ELSE NULL END [Situacao],
    CASE 
        WHEN Status_Cont = 0 THEN '0 - NÃO APROVADO'
        WHEN Status_Cont = 1 THEN '1 - APROVADO'
        WHEN Status_Cont = 2 THEN '2 - EM ADITIVO'
	ELSE NULL END [Status],
    Item_Itens,
    Serv_Itens,
    UPPER(Descr_Itens) [Descr_Itens],
    Unid_Itens,
    Qtde_Itens,
    Preco_Itens,
    Qtde_Itens * Preco_Itens [ValorServico]
FROM UAU.dbo.Contratos
    INNER JOIN UAU.dbo.ItensContrato
        ON Empresa_Cont = Empresa_Itens
           AND Cod_Cont = Contrato_Itens
    INNER JOIN UAU.dbo.Empresas
        ON Empresa_Cont = Codigo_Emp
    INNER JOIN UAU.dbo.Obras
        ON Empresa_Cont = Empresa_Obr
           AND Obra_Cont = Cod_Obr
    INNER JOIN UAU.dbo.Pessoas
        ON CodPes_Cont = Cod_Pes

WHERE Situacao_Cont IN (0,1,2,3) 
-- AND Obra_Cont in ('3401C','5501C','4701C','7601C')
-- AND Status_Cont IN(<Status>) 
-- AND DtInicio_Cont >= <DataInicio> 
-- AND DtFim_Cont <= <DataTermino> 
-- AND CAST(Cod_Cont AS VARCHAR) LIKE <Contrato> 

--ORDER BY Empresa_Cont,
--         Obra_Cont,
--         Cod_Cont,
--         Item_Itens
go

