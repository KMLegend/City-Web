

-- Lista preço unitario
 CREATE VIEW [dbo].[VW_GER_CONTROLE_LISTA_PRECO_UNITARIO]
AS 

with subConsultaPrecoItensContrato as (
SELECT 
	im.Ins_Item CodigoInsumo, 
	im.PrecoUnit_Item Preco, 
	im.Unid_Item  Unid, 
	DATEADD(day, 1, EOMONTH(m.DataAprov_med)) dia,   
	1 Linha, 
	'0- Contrato' Origem,
	m.DataAprov_med
FROM UAU.dbo.ItensMedicao im 

inner join UAU.dbo.Medicoes m 
	on  im.Empresa_Item  = m.Empresa_med 
    and im.Contrato_Item = m.Contrato_med
    and im.CodMed_Item  = m.Cod_med 
inner join UAU.dbo.Contratos c 
	on  m.Empresa_med = c.Empresa_cont
    and m.Contrato_med = c.Cod_cont 
inner join (
		select distinct 
			ic1.Empresa_itens, 
			ic1.Contrato_itens, 
			ic1.Serv_itens 
    from  UAU.dbo.ItensContrato ic1 
) ic 
	on  im.Empresa_Item = ic.Empresa_itens
    and im.Contrato_Item = ic.Contrato_itens
    and im.Ins_Item = ic.Serv_itens
),
subConsultaPrecosUAU as (
SELECT 
	pic.CodigoInsumo, 
	pic.Preco, 
	pic.Unid, 
	pic.dia,   
	pic.Linha, 
	pic.Origem
FROM subConsultaPrecoItensContrato pic 

where  pic.DataAprov_med >= '2024-01-01'   --:InicioDaBusca    Periodo a ser analisado de cotação (definição da Engenharia) ou pode ser realizado o calculo de INCC (juros conforme parcelas de venda)  

union all

SELECT 
	up.CodigoInsumo,
	up.Preco,
	up.Unid,
	up.Dia,
	up.Linha, 
	up.Origem
from (
	select distinct 
		isc.CodIns_Simc CodigoInsumo,
		isc.Preco_Simc Preco,
		pd.Unid_temp Unid,
		DATEADD(day, 1, EOMONTH(sc.Data_Smlc, -1)) Dia,
		ROW_NUMBER () over (PARTITION by isc.CodIns_Simc, Unid_temp order by sc.Data_Smlc desc ) Linha, 
		'1- Pedido' Origem
 	from UAU.dbo.ItensSimuladosConf isc 
  
	  inner join UAU.dbo.ItensCot_temp pd  
  		on  isc.Empresa_Simc = pd.Empresa_temp 
    		and isc.Obra_Simc  = pd.Obra_temp 
    		and isc.CodIns_Simc  = pd.Insumo_temp 
	  inner join UAU.dbo.SimulacoesConf sc 
  		on  isc.Empresa_Simc  = sc.Empresa_Smlc 
		  and isc.Cotacao_simc  = sc.Numcot_Smlc 
		  and isc.NumSimu_Simc  = sc.Numero_Smlc
    
	  where sc.Data_Smlc>= '2024-01-01'   --:InicioDaBusca    Periodo a ser analisado de cotação (definição da Engenharia) ou pode ser realizado o calculo de INCC (juros conforme parcelas de venda)                        
 
 	union all
 
 	select distinct 
 		ict.CodIns_Sim CodigoInsumo,
		ict.Preco_Sim Preco,
		pd.Unid_temp  Unid,
		DATEADD(day, 1, EOMONTH(s.Data_Sml, -1)) Dia,
		ROW_NUMBER () over (PARTITION by ict.CodIns_Sim, Unid_temp order by s.Data_Sml desc ) Linha, 
		'1- Pedido' Origem
 	from  UAU.dbo.ItensSimulados  ict 
  
	  inner join UAU.dbo.ItensCot_temp pd  
  		on  ict.Empresa_sim = pd.Empresa_temp 
		  and  ict.CodIns_Sim = pd.Insumo_temp 
	  inner join UAU.dbo.Simulacoes s      
  		on  ict.empresa_sim = s.Empresa_sml
		  and ict.cotacao_sim = s.NumCot_sml
		  and ict.NumSimu_sim = s.Numero_sml  
	where ict.CodIns_Sim not in ( 
		select 
			isc1.CodIns_Simc  
		from UAU.dbo.ItensSimuladosConf isc1 
	)
) as up 
)

select 
	up.CodigoInsumo,
	up.Preco,
	up.Unid,
	up.Dia,
	up.Linha, 
	up.Origem
from subConsultaPrecosUAU up 
where up.linha<=3 -- Quantidade de compras pra tras a ser avaliado na cotação definição da Engenharia.



go

