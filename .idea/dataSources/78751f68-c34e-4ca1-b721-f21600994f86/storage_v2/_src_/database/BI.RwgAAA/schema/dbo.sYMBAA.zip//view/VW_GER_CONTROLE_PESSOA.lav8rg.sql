
CREATE view [dbo].[VW_GER_CONTROLE_PESSOA] AS (

SELECT 
cod_pes AS COD_PES,
nome_pes AS PESSOA
FROM UAU.dbo.Pessoas
)

go

