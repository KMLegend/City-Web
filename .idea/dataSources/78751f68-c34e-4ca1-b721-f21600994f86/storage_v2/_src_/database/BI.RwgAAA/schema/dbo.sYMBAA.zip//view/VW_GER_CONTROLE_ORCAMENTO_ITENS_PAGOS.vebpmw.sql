CREATE VIEW dbo.VW_GER_CONTROLE_ORCAMENTO_ITENS_PAGOS AS 

-- CRIA LISTA DE ITENS PAGOS PARA AVALIACAO DE PREÇO UNITARIO DE CADA ITEM POR MES
-- DATA CRIACAO: 08/11/2024.
-- CRIADO POR: KEICY SIMAO

SELECT DISTINCT
	BASE.Empresa_des,
	BASE.Obra_des,
	--BASE.NumProc_des,
	--BASE.NumParc_des,
	BASE.ItemProc_des,                                                                               
	BASE.DescItemProc_Des,
	BASE.CompPL_des,
	BASE.DescCompPl_Des,
	BASE.CodForn_Des,
	p.nome_pes AS Fornecedor_Des,
	MIN(BASE.DataRef_Des) AS DataRef_Des,
	MIN(BASE.DataAprovEmissao) AS DataAprovEmissao,
	BASE.UnidItemProc_Des,
	BASE.QtdeItemProc_des,
	BASE.ValorUnitItem_des,
	BASE.ValorTotalItem_des
FROM (
SELECT DISTINCT
	Itens_Proc.Empresa_item AS Empresa_des,
	Itens_Proc.ObraProc_Item AS Obra_des,
	Itens_Proc.NumProc_Item AS NumProc_des,
	--ContasPagas.NumParc_pag AS NumParc_des,
	ItemProcSI.InsumoProc_itsi AS ItemProc_des,                                                                               
	CASE 
		WHEN ContasPagas.TipoProc_pag = 7 THEN Composicoes.Descr_comp 
		ELSE InsumosGeral.Descr_ins END AS DescItemProc_Des,
	ItemProcSI.Comp_itsi AS CompPL_des,
	PlanTotal.Descr_plt AS DescCompPl_Des,
	ContasPagas.CodForn_Pag AS CodForn_Des,  
	--ItemProcSI.PLMes_itsi AS PlMes_des,
	DATEADD(MONTH,-1,DATEADD(DAY,1,(EOMONTH(ContasPagas.DataAprovEmissao_pag,0)))) AS DataRef_Des,
	ContasPagas.DataAprovEmissao_pag AS DataAprovEmissao,
	Itens_Proc.UnidProc_Item AS UnidItemProc_Des,
	Itens_Proc.QtdeProc_Item AS QtdeItemProc_des,
	Itens_Proc.ValUnitProc_Item  AS ValorUnitItem_des,
	(Itens_Proc.ValUnitProc_Item * Itens_Proc.QtdeProc_Item) AS ValorTotalItem_des
	--Itens_Proc.Total_Item AS ValorTotalItem_des
	--ItemProcSI.Preco_itsi AS ValorTotalItem_des

FROM UAU.dbo.ItemProcSI
    INNER JOIN UAU.dbo.ContasPagas
        ON Empresa_itsi = ContasPagas.Empresa_pag
           AND NumProc_itsi = ContasPagas.NumProc_Pag
           AND Obra_itsi = ContasPagas.ObraProc_Pag
    INNER JOIN UAU.dbo.Itens_Proc
        ON Itens_Proc.Empresa_item = ItemProcSI.Empresa_itsi
           AND Itens_Proc.NumProc_Item = ItemProcSI.NumProc_itsi
           AND Itens_Proc.ObraProc_Item = ItemProcSI.Obra_itsi
           AND Itens_Proc.CodInsProc_Item = ItemProcSI.InsumoProc_itsi
    LEFT JOIN UAU.dbo.Composicoes
        ON Itens_Proc.CodInsProc_Item = Composicoes.Cod_comp
    LEFT JOIN UAU.dbo.InsumosGeral
        ON Itens_Proc.CodInsProc_Item = InsumosGeral.Cod_ins
    LEFT OUTER JOIN UAU.dbo.PlanTotal
        ON PlanTotal.Empresa_plt = ItemProcSI.Empresa_itsi
            AND PlanTotal.Obra_plt = ItemProcSI.Obra_itsi
            AND PlanTotal.Item_plt = ItemProcSI.Item_itsi
            AND PlanTotal.Serv_plt = ItemProcSI.Comp_itsi
            AND PlanTotal.Prod_plt = ItemProcSI.Prod_itsi
            AND PlanTotal.Contrato_plt = ItemProcSI.Contrato_itsi
 --   LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins insumo
 --       ON insumo.Num_aipc = InsumosGeral.NumApi_ins
 --   INNER JOIN UAU.dbo.CAP WITH (NOLOCK)
 --        ON ContasPagas.CAP_Pag = CAP.Codigo_cger
 --   LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins
 --       ON AplicacaoInsumoPisCofins.Num_aipc = Composicoes.NumApi_comp
	--LEFT OUTER JOIN UAU.dbo.CategoriasDeInsumo 
	--RIGHT OUTER JOIN UAU.dbo.Insumos as AA
	--	ON CategoriasDeInsumo.Codigo_cger = AA.CatIns_ins 
	--	ON Empresa_itsi = AA.Empresa_ins 
	--		AND Obra_itsi = AA.Obra_ins 
	--		AND InsumoPL_itsi = AA.Cod_ins 
	--LEFT JOIN UAU.dbo.Extrato 
	--	ON Empresa_itsi = Empresa_Doc
	--	AND Conta_Pag = Conta_Doc
	--	AND NumChq_Pag = Numero_Doc
	--	AND BancoProc_Pag = Banco_Doc

--WHERE CAP.Desc_cger in ('REFEIÇÕES E LANCHES','SALARIOS A PAGAR')

WHERE (ItemProcSI.Obra_itsi LIKE '%C' AND ItemProcSI.Obra_itsi NOT LIKE 'HOLVC')
AND ContasPagas.DataAprovEmissao_pag IS NOT NULL
--AND ItemProcSI.InsumoProc_itsi = '1010302067'
--AND ItemProcSI.Empresa_itsi = 55
--AND ItemProcSI.Obra_itsi = '5501C'
--AND ItemProcSI.NumProc_itsi = 3099--4360



) AS BASE 

LEFT JOIN  UAU.dbo.Pessoas as p
on COALESCE(P.cod_pes,'') = COALESCE(BASE.CodForn_Des,'')

WHERE base.DataRef_Des >= DATEADD(year,-3,getdate())
--WHERE base.DataRef_Des >= DATEADD(MONTH,-6,GETDATE())

GROUP BY 
	BASE.Empresa_des,
	BASE.Obra_des,
	--BASE.NumProc_des,
	--BASE.NumParc_des,
	BASE.ItemProc_des,                                                                               
	BASE.DescItemProc_Des,
	BASE.CompPL_des,
	BASE.DescCompPl_Des,
	BASE.CodForn_Des, 
	P.nome_pes,
	BASE.UnidItemProc_Des,
	BASE.QtdeItemProc_des,
	BASE.ValorUnitItem_des,
	BASE.ValorTotalItem_des


--ORDER BY 4,9,1,2


/*

-- IMPOSTOS
union all


SELECT
Empresa_itsi AS Empresa_des,
Obra_itsi AS Obra_des,
--NumProc_itsi AS NumProc_des,
CodInsProc_item AS ItemProc_des,
CASE 
	WHEN ContasPagas.TipoProc_pag = 7 THEN Composicoes.Descr_comp 
	ELSE InsumosGeral.Descr_ins END AS DescItemProc_Des,
ItemProcSI.Comp_itsi AS CompPL_des,
PlanTotal.Descr_plt AS DescCompPl_Des,
ContasPagas.CodForn_Pag AS CodForn_Des, 
ItemProcSI.PLMes_itsi AS PlMes_des,
ContasPagas.DataAprovEmissao_pag AS DataAprovEmissao,
Itens_Proc.UnidProc_Item AS UnidItemProc_Des,
     , 0                                                                                               AS QtdeItem_des
0 AS ValorTotalItem_des

FROM UAU.dbo.Itens_Proc
    INNER JOIN
    (
        SELECT Empresa_itsi
             , Obra_itsi
             , NumProcVinc_PrVinc AS NumProc_itsi
             , SUM(Porc_itsi)     AS Porc_itsi
             , Contrato_itsi
             , Prod_itsi
             , Item_itsi
             , Comp_itsi
             , PLMes_itsi
             , InsumoPL_itsi
        FROM
        (
            SELECT DISTINCT
                Empresa_pag
              , ObraProc_pag
              , NumProc_pag
              , IntExt_Pag
            FROM UAU.dbo.ContasPagas
        ) AS ContasPagas
            INNER JOIN UAU.dbo.ProcVinc
                ON ContasPagas.Empresa_pag = ProcVinc.Empresa_PrVinc
                   AND ContasPagas.ObraProc_Pag = ProcVinc.Obra_PrVinc
                   AND ContasPagas.NumProc_Pag = ProcVinc.NumProcVinc_PrVinc
            INNER JOIN UAU.dbo.ItemProcSI
                ON ProcVinc.Empresa_PrVinc = ItemProcSI.Empresa_itsi
                   AND ProcVinc.Obra_PrVinc = ItemProcSI.Obra_itsi
                   AND ProcVinc.InsumoProc_PrVinc = ItemProcSI.InsumoProc_itsi
                   AND ProcVinc.Item_PrVinc = ItemProcSI.Item_itsi
                   AND ProcVinc.Prod_PrVinc = ItemProcSI.Prod_itsi
                   AND ProcVinc.Contrato_PrVinc = ItemProcSI.Contrato_itsi
                   AND ProcVinc.Comp_PrVinc = ItemProcSI.Comp_itsi
                   AND ProcVinc.InsumoPL_PrVinc = ItemProcSI.InsumoPL_itsi
                   AND ProcVinc.PLMes_PrVinc = ItemProcSI.PLMes_itsi
                   AND ProcVinc.NumProc_PrVinc = ItemProcSI.NumProc_itsi

        GROUP BY Empresa_itsi
               , Obra_itsi
               , NumProcVinc_PrVinc
               , Contrato_itsi
               , Item_itsi
               , Comp_itsi
               , PLMes_itsi
               , InsumoPL_itsi
               , Prod_itsi
    ) AS ItemProcSIVinc
        ON Itens_Proc.Empresa_item = Empresa_itsi
           AND Itens_Proc.NumProc_Item = NumProc_itsi
           AND Itens_Proc.ObraProc_Item = Obra_itsi
    INNER JOIN UAU.dbo.ContasPagas
        ON Itens_Proc.Empresa_item = ContasPagas.Empresa_pag
           AND Itens_Proc.NumProc_Item = ContasPagas.NumProc_Pag
           AND Itens_Proc.ObraProc_Item = ContasPagas.ObraProc_Pag
    LEFT JOIN UAU.dbo.Composicoes
        ON Itens_Proc.CodInsProc_Item = Composicoes.Cod_comp
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins
        ON AplicacaoInsumoPisCofins.Num_aipc = Composicoes.NumApi_comp
    LEFT JOIN UAU.dbo.InsumosGeral
        ON Itens_Proc.CodInsProc_Item = InsumosGeral.Cod_ins
    LEFT JOIN UAU.dbo.AplicacaoInsumoPisCofins insumo
        ON insumo.Num_aipc = InsumosGeral.NumApi_ins
    INNER JOIN UAU.dbo.CAP WITH (NOLOCK)
         ON ContasPagas.CAP_Pag = CAP.Codigo_cger
    LEFT OUTER JOIN UAU.dbo.PlanTotal
        ON PlanTotal.Empresa_plt = ItemProcSIVinc.Empresa_itsi
            AND PlanTotal.Obra_plt = ItemProcSIVinc.Obra_itsi
            AND PlanTotal.Item_plt = ItemProcSIVinc.Item_itsi
            AND PlanTotal.Serv_plt = ItemProcSIVinc.Comp_itsi
            AND PlanTotal.Prod_plt = ItemProcSIVinc.Prod_itsi
            AND PlanTotal.Contrato_plt = ItemProcSIVinc.Contrato_itsi
	LEFT OUTER JOIN UAU.dbo.CategoriasDeInsumo 
	RIGHT OUTER JOIN UAU.dbo.Insumos as AA
		ON CategoriasDeInsumo.Codigo_cger = AA.CatIns_ins 
		ON Empresa_itsi = AA.Empresa_ins 
			AND Obra_itsi = AA.Obra_ins 
			AND InsumoPL_itsi = AA.Cod_ins 
	LEFT JOIN UAU.dbo.Extrato 
		ON Empresa_itsi = Empresa_Doc
		AND Conta_Pag = Conta_Doc
		AND NumChq_Pag = Numero_Doc
		AND BancoProc_Pag = Banco_Doc


select dateadd(year,-3,getdate()), dateadd(month,-6,getdate())

*/
go

