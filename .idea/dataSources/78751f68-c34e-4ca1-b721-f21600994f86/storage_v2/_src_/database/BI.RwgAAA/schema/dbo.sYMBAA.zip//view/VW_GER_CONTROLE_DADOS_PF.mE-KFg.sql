
CREATE VIEW [dbo].[VW_GER_CONTROLE_DADOS_PF] AS 

SELECT Vendas.Empresa_ven,
       Vendas.Obra_Ven,
       Vendas.Num_Ven,
       Vendas.Data_Ven,
       Vendas.ValorTot_Ven + Vendas.Acrescimo_Ven - Vendas.Desconto_Ven AS VlrLiquido_ven,
       (Vendas.ValorTot_Ven + Vendas.Acrescimo_Ven - Vendas.Desconto_Ven) * 0.2 AS VlrLiqFracaoIdeal,
       (Vendas.ValorTot_Ven + Vendas.Acrescimo_Ven - Vendas.Desconto_Ven) * 0.8 AS VlrAcessoes,
       ItensVenda.Produto_Itv,
       ItensVenda.CodPerson_Itv,
       Pessoas.nome_pes,
       Pessoas.Email_pes,
       Pessoas.cpf_pes,
       Pessoas.dtnasc_pes,
       EndPrincipal.Endereco_pend + ' ' + ISNULL(EndPrincipal.ComplEndereco_pend, '') AS ender_pes,
       EndPrincipal.Bairro_pend AS setor_pes,
       EndPrincipal.Cidade_pend AS cidade_pes,
       EndPrincipal.UF_pend AS uf_pes,
       EndPrincipal.CEP_pend AS cep_pes,
       COALESCE(Profissao.Descr_pro, '') AS profis_pf,
       CASE PesFis.EstCiv_pf
           WHEN 0 THEN
               'Separado'
           WHEN 1 THEN
               'Solteiro'
           WHEN 2 THEN
               'Casado'
           WHEN 3 THEN
               'Desquitado'
           WHEN 4 THEN
               'Viúvo'
           WHEN 5 THEN
               'Divorciado'
           WHEN 6 THEN
               'Outros'
       END AS estciv_pf,
       PesFis.nacion_pf,
       PesFis.naturalid_pf,
       RG.Registro_Doc AS ci_pf,
       RG.OrgaoEmissor_Doc AS orgexp_pf,
       RG.DataEmissao_Doc AS dataemisci_pf,
       PES1.nome_pes AS Conjuge,
       Dependente.DataCasam_Dep,
       PES2.Endereco_pend + ' ' + ISNULL(PES2.ComplEndereco_pend, '') AS EnderCom,
       PES2.Bairro_pend AS SetorCom,
       PES2.Cidade_pend AS CidadeCom,
       PES2.UF_pend AS UFCom,
       PES2.CEP_pend AS CepCom,
       CASE
           WHEN PesFis.corresp_pf = 1 THEN
               PES2.Endereco_pend + ' ' + ISNULL(PES2.ComplEndereco_pend, '')
           ELSE
               EndPrincipal.Endereco_pend + ' ' + ISNULL(EndPrincipal.ComplEndereco_pend, '')
       END AS EnderCorr,
       CASE
           WHEN PesFis.corresp_pf = 1 THEN
               PES2.Bairro_pend
           ELSE
               EndPrincipal.Bairro_pend
       END AS SetorCorr,
       CASE
           WHEN PesFis.corresp_pf = 1 THEN
               PES2.Cidade_pend
           ELSE
               EndPrincipal.Cidade_pend
       END AS CidadeCorr,
       CASE
           WHEN PesFis.corresp_pf = 1 THEN
               PES2.UF_pend
           ELSE
               EndPrincipal.UF_pend
       END AS UFCorr,
       CASE
           WHEN PesFis.corresp_pf = 1 THEN
               PES2.CEP_pend
           ELSE
               EndPrincipal.CEP_pend
       END AS CepCorr,
       (
           SELECT TOP (1)
               '(' + ddd_tel + ')' + fone_tel AS Expr1
           FROM UAU.dbo.PesTel
           WHERE (pes_tel = Vendas.Cliente_Ven)
                 AND (tipo_tel = 0)
       ) AS TelRes,
       (
           SELECT TOP (1)
               '(' + ddd_tel + ')' + fone_tel AS Expr1
           FROM UAU.dbo.PesTel
           WHERE (pes_tel = Vendas.Cliente_Ven)
                 AND (tipo_tel = 1)
       ) AS TelCom,
       (
           SELECT TOP (1)
               '(' + ddd_tel + ')' + fone_tel AS Expr1
           FROM UAU.dbo.PesTel
           WHERE (pes_tel = Vendas.Cliente_Ven)
                 AND (tipo_tel = 2)
       ) AS TelCel,
       Empresas.Codigo_emp,
       Empresas.Desc_emp,
       Empresas.CGC_emp,
       Empresas.IE_emp,
       Empresas.Endereco_emp,
       Empresas.Setor_emp,
       Empresas.Cidade_emp,
       Empresas.UF_emp,
       Empresas.CEP_emp,
       Empresas.Fone_emp,
       Empresas.Fax_emp,
       Empresas.RedIcms_emp,
       Empresas.IpiIsenta_emp,
       Empresas.AtInat_emp,
       Empresas.CodEmPresaNet_emp,
       Empresas.Anexos_Emp,
       Empresas.InscrMunic_emp,
       Empresas.EmpresaFolha_emp,
       Empresas.NumCid_emp,
       Empresas.email_emp,
       Empresas.TipoInsc_emp,
       Empresas.NumEnd_emp,
       Empresas.OptSimples_emp,
       Empresas.QtdeSocio_Emp,
       Empresas.DDDFone_Emp,
       Empresas.DDDFax_Emp,
       Empresas.IncetivadorCultural_emp,
       Empresas.CodIdxCorrPat_Emp,
       Empresas.CodIdxIndPat_Emp,
       Empresas.DataSimples_emp,
       Empresas.InsNIRE_emp,
       Empresas.InsSuframa_emp,
       Empresas.NumBrr_emp,
       Empresas.NumLogr_emp,
       Obras.descr_obr,
       PrdSrv.Descricao_psc,
       UnidadePer.Empresa_unid,
       UnidadePer.Prod_unid,
       UnidadePer.NumPer_unid,
       UnidadePer.Obra_unid,
       UnidadePer.Qtde_unid,
       UnidadePer.Vendido_unid,
       UnidadePer.Codigo_Unid,
       UnidadePer.PorcentPr_Unid,
       UnidadePer.C1_unid,
       UnidadePer.C2_unid,
       UnidadePer.C3_unid,
       UnidadePer.C4_unid,
       UnidadePer.C5_unid,
       UnidadePer.C6_unid,
       UnidadePer.C7_unid,
       UnidadePer.C8_unid,
       UnidadePer.C9_unid,
       UnidadePer.C10_unid,
       UnidadePer.C11_unid,
       UnidadePer.C12_unid,
       UnidadePer.C13_unid,
       UnidadePer.C14_unid,
       UnidadePer.C15_unid,
       UnidadePer.C16_unid,
       UnidadePer.C17_unid,
       UnidadePer.C18_unid,
       UnidadePer.C19_unid,
       UnidadePer.C20_unid,
       UnidadePer.C21_unid,
       UnidadePer.C22_unid,
       UnidadePer.C23_unid,
       UnidadePer.C24_unid,
       UnidadePer.C25_unid,
       UnidadePer.C26_unid,
       UnidadePer.C27_unid,
       UnidadePer.C28_unid,
       UnidadePer.C29_unid,
       UnidadePer.C30_unid,
       UnidadePer.C31_unid,
       UnidadePer.C32_unid,
       UnidadePer.C33_unid,
       UnidadePer.C34_unid,
       UnidadePer.C35_unid,
       UnidadePer.C36_unid,
       UnidadePer.C37_unid,
       UnidadePer.C38_unid,
       UnidadePer.C39_unid,
       UnidadePer.C40_unid,
       UnidadePer.C41_unid,
       UnidadePer.C42_unid,
       UnidadePer.C43_unid,
       UnidadePer.C44_unid,
       UnidadePer.C45_unid,
       UnidadePer.anexos_unid,
       UnidadePer.Identificador_unid,
       UnidadePer.UsrCad_unid,
       UnidadePer.DataCad_unid,
       UnidadePer.ValPreco_unid,
       UnidadePer.FracaoIdeal_unid,
       UnidadePer.NumObe_unid,
       UnidadePer.ObjEspelhoTop_unid,
       UnidadePer.ObjEspelhoLeft_unid,
       UnidadePer.PorcentComissao_unid,
       UnidadePer.CodTipProd_unid,
       UnidadePer.NumCategStatus_unid,
       UnidadePer.FracaoIdealDecimal_unid,
       UnidadePer.DataEntregaChaves_unid,
       UnidadePer.DataReconhecimentoReceitaMapa_unid,
       PES1.nome_pes AS NomePes1,
       PES1.Email_pes AS EmailPes1,
       PES1.cpf_pes AS CPFPes1,
       PES1.dtnasc_pes AS DtNascPes1,
       EndPrincipal1.Endereco_pend + ' ' + ISNULL(EndPrincipal1.ComplEndereco_pend, '') AS EnderPes1,
       EndPrincipal1.Bairro_pend AS SetorPes1,
       EndPrincipal1.Cidade_pend AS CidadePes1,
       EndPrincipal1.UF_pend AS UFPes1,
       EndPrincipal1.CEP_pend AS CEPPes1,
       COALESCE(Prof1.Descr_pro, '') AS ProfConj,
       PF1.nacion_pf AS NacionConj,
       PF1.naturalid_pf AS NaturConj,
       RG1.Registro_Doc AS CiConj,
       RG1.OrgaoEmissor_Doc AS OrgexpConj,
       RG1.DataEmissao_Doc AS DataEmisConj,
       (
           SELECT TOP (1)
               '(' + ddd_tel + ')' + fone_tel AS Expr1
           FROM UAU.dbo.PesTel
           WHERE (pes_tel = Vendas.Cliente_Ven)
                 AND (tipo_tel = 1)
       ) AS TelComConj,
       (
           SELECT TOP (1)
               '(' + ddd_tel + ')' + fone_tel AS Expr1
           FROM UAU.dbo.PesTel
           WHERE (pes_tel = Vendas.Cliente_Ven)
                 AND (tipo_tel = 2)
       ) AS TelCelConj,
       PES3.Endereco_pend + ' ' + ISNULL(PES3.ComplEndereco_pend, '') AS EnderCom3,
       PES3.Bairro_pend AS SetorCom3,
       PES3.Cidade_pend AS CidadeCom3,
       PES3.UF_pend AS UFCom3,
       PES3.CEP_pend AS CepCom3,
       CASE
           WHEN PF1.corresp_pf = 1 THEN
               PES3.Endereco_pend + ' ' + ISNULL(PES3.ComplEndereco_pend, '')
           ELSE
               EndPrincipal1.Endereco_pend + ' ' + ISNULL(EndPrincipal1.ComplEndereco_pend, '')
       END AS EnderCorr3,
       CASE
           WHEN PF1.corresp_pf = 1 THEN
               PES3.Bairro_pend
           ELSE
               EndPrincipal1.Bairro_pend
       END AS SetorCorr3,
       CASE
           WHEN PF1.corresp_pf = 1 THEN
               PES3.Cidade_pend
           ELSE
               EndPrincipal1.Cidade_pend
       END AS CidadeCorr3,
       CASE
           WHEN PF1.corresp_pf = 1 THEN
               PES3.UF_pend
           ELSE
               EndPrincipal1.UF_pend
       END AS UFCorr3,
       CASE
           WHEN PF1.corresp_pf = 1 THEN
               PES3.CEP_pend
           ELSE
               EndPrincipal1.CEP_pend
       END AS CepCorr3,
       (
       (
           SELECT SUM(ValJurosComp_crc) AS ValComJuros
           FROM UAU.dbo.ContasReceberCalc
           WHERE (Empresa_crc = Vendas.Empresa_ven)
                 AND (Obra_crc = Vendas.Obra_Ven)
                 AND (NumVend_crc = Vendas.Num_Ven)
       ) +
       (
           SELECT SUM(VlJurosParc_Rec + VlJurosParcConf_Rec) AS ValComJuros
           FROM UAU.dbo.Recebidas
           WHERE (Empresa_rec = Vendas.Empresa_ven)
                 AND (Obra_Rec = Vendas.Obra_Ven)
                 AND (NumVend_Rec = Vendas.Num_Ven)
       )
       ) + (Vendas.ValorTot_Ven + Vendas.Acrescimo_Ven - Vendas.Desconto_Ven) AS ValorComJuros,
       Vendas.DataBaseResiduo_Ven,
       CAST(Vendas.Empresa_ven AS VARCHAR) + '|' + Vendas.Obra_Ven AS EmpObra
FROM UAU.dbo.Vendas
    INNER JOIN UAU.dbo.ItensVenda
        ON Vendas.Empresa_ven = ItensVenda.Empresa_itv
           AND Vendas.Obra_Ven = ItensVenda.Obra_Itv
           AND Vendas.Num_Ven = ItensVenda.NumVend_Itv
    LEFT OUTER JOIN UAU.dbo.Empresas
        ON Vendas.Empresa_ven = Empresas.Codigo_emp
    LEFT OUTER JOIN UAU.dbo.Obras
        ON Vendas.Empresa_ven = Obras.Empresa_obr
           AND Vendas.Obra_Ven = Obras.cod_obr
    LEFT OUTER JOIN UAU.dbo.PrdSrv
        ON ItensVenda.Produto_Itv = PrdSrv.NumProd_psc
    LEFT OUTER JOIN UAU.dbo.Pessoas
        ON Vendas.Cliente_Ven = Pessoas.cod_pes
    LEFT OUTER JOIN UAU.dbo.PesEndereco AS EndPrincipal
        ON EndPrincipal.CodPes_pend = Pessoas.cod_pes
           AND EndPrincipal.Tipo_pend = 0
    LEFT OUTER JOIN UAU.dbo.PesEndereco AS EndComercial
        ON EndComercial.CodPes_pend = Pessoas.cod_pes
           AND EndComercial.Tipo_pend = 2
    LEFT OUTER JOIN UAU.dbo.PesFis
        ON PesFis.cod_pf = Pessoas.cod_pes
    LEFT OUTER JOIN UAU.dbo.PessoasDoc AS RG
        ON RG.CodPes_Doc = PesFis.cod_pf
           AND RG.Tipo_Doc = 1
    LEFT OUTER JOIN UAU.dbo.Profissao
        ON PesFis.NumPro_pf = Profissao.Num_pro
    LEFT OUTER JOIN UAU.dbo.PesEndereco AS PES2
        ON PES2.CodPes_pend = EndComercial.CodEmp_pend
    LEFT OUTER JOIN UAU.dbo.Dependente
        ON Dependente.CodFunc_Dep = Vendas.Cliente_Ven
           AND Dependente.NumGPar_Dep = 1
    LEFT OUTER JOIN UAU.dbo.Pessoas AS PES1
        ON PES1.cod_pes = Dependente.CodDepCad_Dep
    LEFT OUTER JOIN UAU.dbo.PesEndereco AS EndPrincipal1
        ON EndPrincipal1.CodPes_pend = PES1.cod_pes
           AND EndPrincipal1.Tipo_pend = 0
    LEFT OUTER JOIN UAU.dbo.PesEndereco AS EndComercial1
        ON EndComercial1.CodPes_pend = PES1.cod_pes
           AND EndComercial1.Tipo_pend = 2
    LEFT OUTER JOIN UAU.dbo.PesFis AS PF1
        ON PF1.cod_pf = PES1.cod_pes
    LEFT OUTER JOIN UAU.dbo.PessoasDoc AS RG1
        ON RG1.CodPes_Doc = PF1.cod_pf
           AND RG1.Tipo_Doc = 1
    LEFT OUTER JOIN UAU.dbo.Profissao AS Prof1
        ON PF1.NumPro_pf = Prof1.Num_pro
    LEFT OUTER JOIN UAU.dbo.PesEndereco AS PES3
        ON PES3.CodPes_pend = EndComercial1.CodEmp_pend
           AND PES3.Tipo_pend = 0
    LEFT OUTER JOIN UAU.dbo.UnidadePer
        ON UnidadePer.Empresa_unid = Vendas.Empresa_ven
           AND UnidadePer.Prod_unid = ItensVenda.Produto_Itv
           AND UnidadePer.NumPer_unid = ItensVenda.CodPerson_Itv
go

