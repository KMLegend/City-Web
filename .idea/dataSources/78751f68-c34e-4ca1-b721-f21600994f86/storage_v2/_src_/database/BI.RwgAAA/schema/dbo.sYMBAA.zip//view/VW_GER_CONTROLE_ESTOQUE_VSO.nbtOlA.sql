



CREATE VIEW [dbo].[VW_GER_CONTROLE_ESTOQUE_VSO] AS 

SELECT *  
FROM (  
	SELECT    
		UP.anexos_unid,                   
		UP.prod_unid,                   
		UP.empresa_unid,                   
		UP.numper_unid,                  
		UP.obra_unid,                   
		UP.numobe_unid,                   
		OE.cod_obe,                   
		UP.fracaoideal_unid,                   
		UP.fracaoidealdecimal_unid,                  
		UP.identificador_unid,                   
		UP.qtde_unid,                   
		UP.codigo_unid,                   
		UP.porcentpr_unid,                   
		UP.vendido_unid,                   
		UD.tipocontrato_udt,                   
		UP.numcategstatus_unid,                   
		C.desc_csup,                  
		UP.codtipprod_unid,                   
		TP.descricao_tipprod,                   
		UD.reterprimaluguel_udt,                  
		UP.porcentcomissao_unid,                   
		UP.datareconhecimentoreceitamapa_unid,                   
		UP.dataentregachaves_unid,                   
		UP.datacad_unid,                   
		UP.usrcad_unid, 
        --COALESCE(UD.TipoUnidMultipropriedade_udt, 0) AS TipoUnidMultipropriedade_udt,
        --UD.NumUnidFisica_udt,                  
		UP.c1_unid,                   
		UP.c2_unid,                   
		UP.c3_unid,                   
		UP.c4_unid,                   
		UP.c5_unid,                   
		UP.c6_unid,                   
		UP.c7_unid,                   
		UP.c8_unid,                   
		UP.c9_unid,                   
		UP.c10_unid,                   
		UP.c11_unid,                   
		UP.c12_unid,                   
		UP.c13_unid,                   
		UP.c14_unid,                   
		UP.c15_unid,                   
		UP.c16_unid,                   
		UP.c17_unid,                   
		UP.c18_unid,                   
		UP.valpreco_unid AS PrecoMin,                   
		CASE                      
			WHEN UP.vendido_unid = 0 THEN 'Disponível'                      
			WHEN UP.vendido_unid = 1 THEN                         
				(CASE WHEN UD.tipocontrato_udt IN( 1, 2, 5 ) THEN 'Locada' ELSE 'Vendida' END)    
			WHEN UP.vendido_unid = 2 THEN 'Reservado'                      
			WHEN UP.vendido_unid = 3 THEN 'Proposta'                     
			WHEN UP.vendido_unid = 4 THEN 'Quitado'                      
			WHEN UP.vendido_unid = 5 THEN 'Escriturado'                      
			WHEN UP.vendido_unid = 6 THEN 'Em venda'                      
			WHEN UP.vendido_unid = 7 THEN 'Suspenso'                      
			WHEN UP.vendido_unid = 8 THEN 'Fora de venda'                      
			WHEN UP.vendido_unid = 9 THEN 'Em acerto'                      
			WHEN UP.vendido_unid = 10 THEN 'Dação' END AS Descr_status,   
		CASE                      
			WHEN UP.unidadevendidadacao_unid = 1 THEN 1 
			ELSE 0  END AS UnidadeVendidaDacao_unid,   
		UP.objespelhotop_unid,    
		UP.objespelholeft_unid,    
		OB.usr_uo             
	FROM  UAU.dbo.UnidadePer AS UP        

	LEFT JOIN UAU.dbo.obrusr AS OB      
		ON UP.empresa_unid = OB.emp_uo     
		AND UP.obra_unid = OB.obr_uo    

	LEFT JOIN UAU.dbo.UnidadeDetalhe AS UD     
		ON UP.empresa_unid = UD.empresa_udt     
		AND UP.prod_unid = UD.prod_udt     
		AND UP.numper_unid = UD.numper_udt     

	LEFT JOIN UAU.dbo.obrablocoetapa AS OE      
		ON OE.empresa_obe = UP.empresa_unid    
		AND OE.obra_obe = UP.obra_unid    
		AND OE.num_obe = UP.numobe_unid    

	LEFT JOIN UAU.dbo.tipologiaproducao AS TP     
		ON TP.codigo_tipprod = UP.codtipprod_unid      

	LEFT JOIN UAU.dbo.categoriastatusUnidadePer AS C       
		ON UP.numcategstatus_unid =  C.num_csup

)  AS TotalPerson   

--WHERE  ( TotalPerson.prod_unid IN ( 61, 66, 68 ) )  
--AND ( TotalPerson.empresa_unid IN ( 10, 12, 13, 23, 26, 27, 28, 29, 34, 47, 52, 53,54, 55,76,61 ) )  
--AND ( ( TotalPerson.usr_uo = 'LUCASTRO' ) OR ( TotalPerson.usr_uo IS NULL ))   

go

