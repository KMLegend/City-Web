




CREATE VIEW [dbo].[VW_GER_CONTROLE_SEG_TRAB_ASO] AS 

SELECT Aso.*,
       Empresa_CapRH,
       Obra_CapRH,
       CodPes_CapRH,
       CodSitF_CapRH,
       MatFunc_CapRh,
       Nome_pes,
       Dtnasc_pes,
       Descr_obr,
       Desc_emp,
       CadastroMedico.Nome_cMed,
       CadastroMedico.CRM_cMed,
       CadastroMedico.UF_cMed,
       CadastroMedico.OrgClasse_cMed,
       CadastroMedicoResp.Nome_cMed AS Nome_cMedResp,
       CadastroMedicoResp.CRM_cMed AS CRM_cMedResp,
       CadastroMedicoResp.UF_cMed AS UF_cMedResp,
       CadastroMedicoResp.OrgClasse_cMed AS OrgClasse_cMedResp
FROM UAU.dbo.Aso
    INNER JOIN UAU.dbo.CapacitacaoRH
        ON Aso.NumCapRH_Aso = CapacitacaoRH.Num_CapRH
           AND Funcionario_CapRH = 1
    INNER JOIN UAU.dbo.Empresas
        ON CapacitacaoRH.Empresa_CapRH = Empresas.Codigo_emp
    INNER JOIN UAU.dbo.Obras
        ON CapacitacaoRH.Obra_CapRH = Obras.Cod_obr
           AND Empresas.Codigo_emp = Obras.Empresa_obr
    INNER JOIN UAU.dbo.Pessoas
        ON CapacitacaoRH.CodPes_CapRH = Pessoas.Cod_pes
    LEFT JOIN UAU.dbo.CadastroMedico
        ON Aso.CRMMedico_Aso = CadastroMedico.CRM_cMed
           AND Aso.UFMedico_Aso = CadastroMedico.UF_cMed
    LEFT JOIN UAU.dbo.CadastroMedico AS CadastroMedicoResp
        ON Aso.CRMRespPCMSO_Aso = CadastroMedicoResp.CRM_cMed
           AND Aso.UFRespPCMSO_Aso = CadastroMedicoResp.UF_cMed


      --WHERE [CapacitacaoRH].[Empresa_CapRH] = 53
      --AND [CapacitacaoRH].[Obra_CapRH] = '5301C'

--ORDER BY Pessoas.Nome_pes,Aso.Num_Aso
go

