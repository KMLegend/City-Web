
CREATE VIEW [dbo].[VW_GER_CONTROLE_DGA_REALIZADO] AS (
SELECT SAIDAS.EmpObr,
       SAIDAS.GRUPO,
       SAIDAS.Tipo,
       SAIDAS.Empresa_des,
       SAIDAS.Obra_des,
       SAIDAS.NumProc_des,
       SAIDAS.NumParc_des,
       SAIDAS.ItemProc_des,
       SAIDAS.DtPgto_des,
       SAIDAS.Acrescimo_des,
       SAIDAS.Desconto_des,
       SAIDAS.TotalLiq_des,
       SAIDAS.TotalBruto_des,
       SAIDAS.Banco_des,
       SAIDAS.ContaCorr_des,
       SAIDAS.Cap_des,
       SAIDAS.CategMovFin_Des,
       SAIDAS.Desc_cmf,
       SAIDAS.ChqNome_Des,
       SAIDAS.NumChq_Des,
       SAIDAS.DataVencParc_Des,
       SAIDAS.DATADOC,
       SAIDAS.InsumoPL_des,
       InsumosGeral_1.Descr_ins AS [Insumo Pago],
       InsumosGeral.Descr_ins AS [Insumo PL],
       SAIDAS.CompPL_des
FROM
(
    SELECT CAST(VwDesembolsoPago.Empresa_des AS VARCHAR) + '-' + VwDesembolsoPago.Obra_des AS EmpObr,
           'SAÍDAS' AS GRUPO,
           'CONTAS PAGAS' AS Tipo,
           VwDesembolsoPago.Empresa_des,
           VwDesembolsoPago.Obra_des,
           VwDesembolsoPago.NumProc_des,
           VwDesembolsoPago.NumParc_des,
           VwDesembolsoPago.ItemProc_des,
           VwDesembolsoPago.DtPgto_des,
           VwDesembolsoPago.Acrescimo_des,
           VwDesembolsoPago.Desconto_des,
           VwDesembolsoPago.TotalLiq_des,
           VwDesembolsoPago.TotalBruto_des,
           VwDesembolsoPago.Banco_des,
           VwDesembolsoPago.ContaCorr_des,
           VwDesembolsoPago.Cap_des,
           VwDesembolsoPago.CategMovFin_Des,
           CategoriasDeMovFin.Desc_cmf,
           VwDesembolsoPago.ChqNome_Des,
           VwDesembolsoPago.NumChq_Des,
           VwDesembolsoPago.DataVencParc_Des,
           Extrato.Data_doc AS DATADOC,
           VwDesembolsoPago.InsumoPL_des,
           VwDesembolsoPago.CompPL_des
    FROM UAU.dbo.VwDesembolsoPago
        INNER JOIN UAU.dbo.Extrato
            ON VwDesembolsoPago.Empresa_des = Extrato.Empresa_doc
               AND VwDesembolsoPago.Banco_des = Extrato.Banco_doc
               AND VwDesembolsoPago.ContaCorr_des = Extrato.Conta_doc
               AND VwDesembolsoPago.NumChq_Des = Extrato.Numero_doc
        LEFT OUTER JOIN UAU.dbo.CategoriasDeMovFin
            ON VwDesembolsoPago.CategMovFin_Des = CategoriasDeMovFin.Codigo_cmf
) AS SAIDAS
    LEFT OUTER JOIN UAU.dbo.InsumosGeral
        ON SAIDAS.InsumoPL_des = InsumosGeral.Cod_ins
    LEFT OUTER JOIN UAU.dbo.InsumosGeral AS InsumosGeral_1
        ON SAIDAS.ItemProc_des = InsumosGeral_1.Cod_ins
WHERE Empresa_des IN ( 1, 4, 62, 91 )
)
go

