

CREATE VIEW [dbo].[VW_GER_CONTROLE_FISCAL_LANCAMENTOS_CONTABIL] AS 

-- VISUALIZAÇÃO DE LANÇAMENTO CONTABEIS DO MODULO FISCAL DO UAU.
-- DATA CRIACAO: 19/11/2024.
-- CRIADO POR: KEICY SIMAO

-- Razão Contabil

SELECT 
	LancFiscal.*, 
	PlanoContas.Desc_plc, 
	EmpresaInvestida.Desc_emp AS DescricaoEmpresaInvestida,
	PlanoContas.ContaReduz_plc, 
	PlanoContas.Anexos_plc, 
	CategoriasDeMovFin.Desc_cmf, 
	Empresas.Desc_emp, 
	MascaraPlcEmp.MostrarContaReduzida_msc
FROM UAU.dbo.LancFiscal

LEFT JOIN UAU.dbo.CategoriasDeMovFin
	ON LancFiscal.CategMovFin_lf = CategoriasDeMovFin.Codigo_cmf
LEFT JOIN UAU.dbo.PlanoContas
	ON PlanoContas.NumMsc_plc = LancFiscal.NumMsc_lf
		AND PlanoContas.Ano_plc = LancFiscal.Ano_lf
		AND PlanoContas.Conta_plc = LancFiscal.Conta_lf
INNER JOIN UAU.dbo.Empresas 
	ON LancFiscal.Empresa_lf = Empresas.Codigo_emp 
INNER JOIN UAU.dbo.MascaraPlcEmp 
	ON MascaraPlcEmp.Num_msc = LancFiscal.NumMsc_lf
		AND MascaraPlcEmp.Ano_msc = LancFiscal.Ano_lf
LEFT JOIN UAU.dbo.Empresas AS EmpresaInvestida 
	ON LancFiscal.EmpresaInvestida_lf = EmpresaInvestida.Codigo_emp 

--WHERE LancFiscal.Empresa_lf IN (23)
--AND LancFiscal.NumMsc_lf = 6
--AND LancFiscal.Ano_lf = 2024
--AND LancFiscal.Data_lf BETWEEN '01/01/2024'   AND '01/31/2024'

go

