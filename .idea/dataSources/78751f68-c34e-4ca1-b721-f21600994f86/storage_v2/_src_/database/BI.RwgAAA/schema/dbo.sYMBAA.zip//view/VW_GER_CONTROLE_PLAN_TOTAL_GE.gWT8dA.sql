


--planejamento total geral

CREATE VIEW [dbo].[VW_GER_CONTROLE_PLAN_TOTAL_GE] AS 

select distinct
	c.Empresa_cins , 
	c.Obra_cins , 
	c.Item_cins , 
	null Mes, 
	c.Comp_cins , 
	c.Ins_cins , 
	ig.Descr_ins ,  
	p.Descr_pltg ,
	c.Prod_cins ,
	null   Total,
	null tipo,
	c.Contrato_cins ,
	c.NumGestao_cins,
	p.Obra_pltg,
	p.NumGestao_pltg,
	c.Mes_cins,
	c.coef_cins,
	c.preco_cins
/*
	,psg.Obra_pls,
	psg.NumGestao_pls,
	p.Empresa_pltg,
	p.Contrato_pltg ,

	c.coef_cins,
	c.preco_cins,
	psg.Empresa_pls,
	psg.qdade_pls
	--sum(c.coef_cins*c.preco_cins * psg.qdade_pls)   TotalGestao
	*/
	from UAU.dbo.CompInsGe c
	left join UAU.dbo.PlanTotalGe p 
		on  c.Empresa_cins  = p.Empresa_pltg 
			and c.Prod_cins  = p.Prod_pltg 
			and c.Obra_cins  = p.Obra_pltg 
			and c.Contrato_cins  = p.Contrato_pltg 
			and c.Item_cins  = p.Item_pltg 
			and c.Comp_cins  = p.Serv_pltg 
	--LEFT JOIN UAU.dbo.PlanServGe psg 
	--	on c.Empresa_cins  = psg.Empresa_pls 
	--		and c.Obra_cins = psg.Obra_pls 
	--		and c.Contrato_cins  = psg.Contrato_pls 
	--		and c.Item_cins  = psg.Item_pls  
	--		and c.Prod_cins  = psg.Prod_pls 
	--		and c.Mes_cins  = psg.Mes_pls 
	left join UAU.dbo.InsumosGeral ig 
		on c.Comp_cins  = ig.Cod_ins 


	--where c.Obra_cins = '2801C'--:obraUAU
	--	AND c.NumGestao_cins  = 1 --:gestao
	--	and psg.Obra_pls  = '2801C'--:obraUAU
	--	and psg.NumGestao_pls  = 1 --:gestao
	--	and p.NumGestao_pltg  = 1 --:gestao
	--	and p.Obra_pltg  = '2801C'--:obraUAU
	--	and c.Empresa_cins = 28 --:empresa
	--	and p.Empresa_pltg  = 28 --:empresa
	--	and psg.Empresa_pls = 28 --:empresa
	--group by 
	--	c.Empresa_cins, 
	--	c.Obra_cins , 
	--	c.Item_cins , 
	--	c.Comp_cins , 
	--	c.Ins_cins , 
	--	c.Prod_cins,
	--	c.NumGestao_cins,
	--	psg.Obra_pls,
	--	psg.NumGestao_pls,
	--	p.Obra_pltg,
	--	p.Contrato_pltg

where c.Empresa_cins in
('2','10','11','12','13','23','26','27','28','29','33','34','42','47','48','51','52','53','54','55',
'56','57','58','61','64','65','69','74','75','76','77','79','81','82','83','85','89','90','91','92',
'93','94','95','96','100','101','102','103','104','105')
and c.Obra_cins like ('%C')
go

