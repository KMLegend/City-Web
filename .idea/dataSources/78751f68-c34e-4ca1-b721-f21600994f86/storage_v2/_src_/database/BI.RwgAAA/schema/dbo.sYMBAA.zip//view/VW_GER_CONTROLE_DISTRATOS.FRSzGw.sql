


CREATE VIEW [dbo].[VW_GER_CONTROLE_DISTRATOS] AS 

SELECT DISTINCT
	CAST(VD.Empresa_vdd AS VARCHAR) + '-' + VD.Obra_vdd AS CHAVE,
	CAST(VD.Empresa_vdd AS VARCHAR) + '-' + CAST(VD.Obra_vdd AS VARCHAR) + '-' + CAST(VD.NumVend_vdd AS VARCHAR) AS CHAVE_VENDA,
	CAST(VD.Empresa_vdd AS VARCHAR) + '-' + CAST(VD.Obra_vdd AS VARCHAR) + '-' + CAST(UP.Prod_unid AS VARCHAR) AS CHAVE_PROD,
	SUM((R.ValorConf_Rec + R.Valor_Rec + R.VlCorrecao_Rec
		+ R.VlCorrecaoAtr_Rec + R.VlTaxaBol_Rec + R.VlJurosParc_Rec
		+ R.VlJurosParcConf_Rec + R.VlMulta_Rec + R.VlJuros_Rec
		+ R.VlAcres_Rec + R.VlCorrecaoConf_Rec + R.VlCorrecaoAtrConf_Rec
		+ R.VlTaxaBolConf_Rec + R.VlMultaConf_Rec + R.VlJurosConf_Rec
		+ R.VlAcresConf_Rec
		)
		- (R.VlDescontoConf_Rec + R.VlDesconto_Rec + R.ValDescontoCusta_rec
			+ R.ValDescontoCustaConf_rec + R.ValDescontoImposto_rec
			+ R.ValDescontoImpostoConf_rec
			)
		) AS TotParcel,
	VD.Empresa_vdd,
	VD.Obra_vdd,
	VD.NumVend_vdd,
	VD.NumVhist_vdd,
	VD.StatusAprov_vdd,
	VD.EmpresaProc_vdd,
	VD.ObraProc_vdd,
	VD.NumProc_vdd,
	VD.ValTotDistrato_vdd,
	VD.TipoDistrato_vdd,
	VD.ValTotDistrato_vdd / VD.NumParcDev_vdd AS ValParcelas,
	VR.ValorTot_VRec,
	P.nome_pes,
	UP.Identificador_unid,
	UP.Prod_unid,
	VD.DataAprov_vdd,
	CD.Desc_cd

FROM UAU.dbo.VendaDistrato AS VD
INNER JOIN UAU.dbo.VendasRecebidas AS VR
    ON VD.Empresa_vdd = VR.Empresa_vrec
        AND VD.NumVend_vdd = VR.Num_VRec
        AND VD.Obra_vdd = VR.Obra_VRec
INNER JOIN UAU.dbo.Pessoas AS P
    ON VR.Cliente_VRec = P.cod_pes
LEFT JOIN UAU.dbo.CategoriasDeDistrato AS CD
    ON VD.CategDistrato_vdd = CD.Codigo_cd
LEFT JOIN UAU.dbo.Recebidas AS R
    ON VR.Empresa_vrec = R.Empresa_rec
        AND VR.Num_VRec = R.NumVend_Rec
        AND VR.Obra_VRec = R.Obra_Rec
        AND P.cod_pes = R.Cliente_Rec
LEFT JOIN UAU.dbo.UnidadePer AS UP
    INNER JOIN UAU.dbo.ItensRecebidas AS IR
        ON UP.Empresa_unid = IR.Empresa_itr
            AND UP.Obra_unid = IR.Obra_Itr
            AND UP.Prod_unid = IR.Produto_Itr
            AND UP.NumPer_unid = IR.CodPerson_Itr
    ON VR.Empresa_vrec = IR.Empresa_itr
        AND VR.Num_VRec = IR.NumVend_Itr
        AND VR.Obra_VRec = IR.Obra_Itr

GROUP BY 
	VD.Empresa_vdd,
	VD.Obra_vdd,
	VD.NumVend_vdd,
	VD.NumVhist_vdd,
	VD.StatusAprov_vdd,
	VD.EmpresaProc_vdd,
	VD.ObraProc_vdd,
	VD.NumProc_vdd,
	VD.ValTotDistrato_vdd,
	VD.TipoDistrato_vdd,
	VD.ValTotDistrato_vdd / VD.NumParcDev_vdd,
	CAST(VD.Empresa_vdd AS VARCHAR) + '|' + VD.Obra_vdd,
	VR.ValorTot_VRec,
	P.nome_pes,
	UP.Identificador_unid,
	CAST(VD.Empresa_vdd AS VARCHAR) + '-' + 'dbo.VendaDistrato.Obra_vdd	CHAVE		Checked			Expression',
	UP.Prod_unid,
	VD.DataAprov_vdd,
	CD.Desc_cd
go

