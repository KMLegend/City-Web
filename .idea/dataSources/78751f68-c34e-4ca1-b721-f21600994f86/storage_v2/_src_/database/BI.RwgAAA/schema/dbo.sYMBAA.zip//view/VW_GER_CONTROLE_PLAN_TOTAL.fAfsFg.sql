
--planejamento total
 CREATE VIEW [dbo].[VW_GER_CONTROLE_PLAN_TOTAL]
AS 


SELECT distinct
	cie.Empresa_cins, 
	cie.Obra_cins , 
	cie.Item_cins , 
	null Mes, 
	cie.Comp_cins , 
	cie.Ins_cins  , 
	ig.Descr_ins ,  
	pt.Descr_plt  , 
	cie.Prod_cins ,
	null  Total,
	null tipo,
	cie.Contrato_cins 
FROM UAU.dbo.CompIns cie 
LEFT JOIN UAU.dbo.PlanTotal pt 
	ON cie.Empresa_cins  = pt.Empresa_plt  
		AND cie.Prod_cins = pt.Prod_plt 
		AND cie.Obra_cins  = pt.Obra_plt  
		AND cie.Contrato_cins  = pt.Contrato_plt 
		AND cie.Item_cins  = pt.Item_plt 
		AND cie.Comp_cins =pt.Serv_plt 
left join UAU.dbo.InsumosGeral ig 
	on cie.Ins_cins  = ig.Cod_ins 
--where cie.Obra_cins = '2801C'--:obraUAU
--	AND cie.Empresa_cins  = 28 --:empresa
go

