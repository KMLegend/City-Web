


CREATE VIEW [dbo].[VW_GER_CONTROLE_ITENS_INSUMOS_PLANEJADO] AS

--Mostra serviço/insumo planejado e seus processos de pagamentos vinculados quebrando por Fornecedor.
/* Variaveis:
EmpresaObra - Empresa(s) e Obra(s)  -- numerico
Insumo - Código do Insumo  -- texto
MesInicial - Mês PL inicial  -- date
MesTerm - Mês PL final  -- date
Servico - Código do Serviço  -- texto
*/

SELECT
    --CAST(<MesInicial> AS DATETIME) AS MesInicial,
    --CAST(<MesTerm> AS DATETIME) AS MesFim,
    CAST(VwDesembolso.Empresa_Des AS VARCHAR) + ' - ' + Empresas.Desc_emp AS Empresa,
    VwDesembolso.Obra_Des + ' - ' + Obras.descr_obr AS Obra,
    VwDesembolso.DtPgto_Des,
    VwDesembolso.CompPl_Des + ' - ' + Composicoes.Descr_comp AS Servico,
    VwDesembolso.InsumoPl_Des + ' - ' + Insumos.Descr_ins AS Insumo,
    CAST(VwDesembolso.CodForn_Des AS VARCHAR) + ' - ' + Pessoas.nome_pes AS Fornecedor,
    VwDesembolso.NumProc_Des AS Processo,
    VwDesembolso.NumParc_Des AS Parcela,
    VwDesembolso.PlMes_Des,
    VwDesembolso.ItemProc_Des + ' - ' + CASE
                                            WHEN VwDesembolso.TipoProc_Des = 7 THEN
                                                ItensContrato.Descr_itens
                                            ELSE
                                                InsumosGeral.Descr_ins
                                        END AS Item,
    CAST(VwDesembolso.CodForn_Des AS VARCHAR) + ' - ' + CAST(VwDesembolso.NumProc_Des AS VARCHAR) + ' - '
    + CAST(VwDesembolso.NumParc_Des AS VARCHAR) AS Chave1,
    NotasFiscaisEnt.NumNfAux_nfe AS DocFiscal_Des,
    MIN(VwDesembolso.DtPgto_Des) AS DataPagto,
    VwDesembolso.QtdeItem_Des AS QtdeProc_item,
    VwDesembolso.ValorUnitItem_Des AS ValUnitProc_Item,
    (VwDesembolso.QtdeItem_Des * VwDesembolso.ValorUnitItem_Des) AS Total,
    VwDesembolso.TotalLiq_des,
    CASE
        WHEN VwDesembolso.TipoProc_Des = 4
             OR VwDesembolso.TipoProc_Des = 3 THEN
            SUM(VwDesembolso.TotalLiq_des)
        ELSE
            VwDesembolso.ValorUnitItem_Des
    END AS PrecoUnit,
    CASE
        WHEN VwDesembolso.TipoProc_Des = 4
             OR VwDesembolso.TipoProc_Des = 3 THEN
            1
        ELSE
            VwDesembolso.QtdeItem_Des
    END AS Qtde_itsi
FROM
(
    SELECT VwDesembolsoAPagar.Empresa_Des,
           VwDesembolsoAPagar.Obra_Des,
           VwDesembolsoAPagar.InsumoPl_Des,
           VwDesembolsoAPagar.ItemProc_Des,
           VwDesembolsoAPagar.CompPl_Des,
           VwDesembolsoAPagar.CodForn_Des,
           VwDesembolsoAPagar.NumProc_Des,
           VwDesembolsoAPagar.NumParc_Des,
           VwDesembolsoAPagar.PlMes_Des,
           VwDesembolsoAPagar.DtPgto_Des,
           VwDesembolsoAPagar.QtdeItem_Des,
           VwDesembolsoAPagar.ValorUnitItem_Des,
           VwDesembolsoAPagar.TotalLiq_des,
           VwDesembolsoAPagar.TipoProc_Des
    FROM UAU.dbo.VwDesembolsoAPagar
    UNION ALL
    SELECT VwDesembolsoPago.Empresa_Des,
           VwDesembolsoPago.Obra_Des,
           VwDesembolsoPago.InsumoPl_Des,
           VwDesembolsoPago.ItemProc_Des,
           VwDesembolsoPago.CompPl_Des,
           VwDesembolsoPago.CodForn_Des,
           VwDesembolsoPago.NumProc_Des,
           VwDesembolsoPago.NumParc_Des,
           VwDesembolsoPago.PlMes_Des,
           VwDesembolsoPago.DtPgto_Des,
           VwDesembolsoPago.QtdeItem_Des,
           VwDesembolsoPago.ValorUnitItem_Des,
           VwDesembolsoPago.TotalLiq_des,
           VwDesembolsoPago.TipoProc_Des
    FROM UAU.dbo.VwDesembolsoPago
) AS VwDesembolso
    INNER JOIN UAU.dbo.Obras
        ON Obras.cod_obr = VwDesembolso.Obra_Des
           AND Obras.Empresa_obr = VwDesembolso.Empresa_Des
    INNER JOIN UAU.dbo.Empresas
        ON Empresas.Codigo_emp = Obras.Empresa_obr
    INNER JOIN UAU.dbo.Pessoas
        ON Pessoas.cod_pes = VwDesembolso.CodForn_Des
    LEFT JOIN UAU.dbo.Notfisc_Proc
        ON Notfisc_Proc.Empresa_proc = VwDesembolso.Empresa_Des
           AND Notfisc_Proc.Obra_Proc = VwDesembolso.Obra_Des
           AND Notfisc_Proc.Num_Proc = VwDesembolso.NumProc_Des
           AND Notfisc_Proc.NumParc_Proc = VwDesembolso.NumParc_Des
    LEFT JOIN UAU.dbo.NotasFiscaisEnt
        ON NotasFiscaisEnt.Empresa_nfe = Notfisc_Proc.Empresa_proc
           AND NotasFiscaisEnt.Num_nfe = Notfisc_Proc.NumNfe_Proc
    INNER JOIN
    (
        SELECT InsumosGeral.Cod_ins,
               InsumosGeral.Descr_ins
        FROM UAU.dbo.InsumosGeral
        UNION
        SELECT Composicoes.Cod_comp,
               Composicoes.Descr_comp
        FROM UAU.dbo.Composicoes
    ) AS InsumosGeral
        ON InsumosGeral.Cod_ins = VwDesembolso.ItemProc_Des
    INNER JOIN UAU.dbo.Composicoes
        ON Composicoes.Cod_comp = VwDesembolso.CompPl_Des
    INNER JOIN UAU.dbo.Insumos
        ON Insumos.Empresa_ins = VwDesembolso.Empresa_Des
           AND Insumos.Obra_ins = VwDesembolso.Obra_Des
           AND Insumos.Cod_ins = VwDesembolso.InsumoPl_Des
    OUTER APPLY
(
    SELECT Dados_Proc.Contrato_Proc AS ContratoServ_des
    FROM UAU.dbo.Dados_Proc
    WHERE Dados_Proc.Empresa_proc = VwDesembolso.Empresa_Des
          AND Dados_Proc.Obra_Proc = VwDesembolso.Obra_Des
          AND Dados_Proc.Num_Proc = VwDesembolso.NumProc_Des
    UNION
    SELECT ContasPagas.Contrato_Pag AS ContratoServ_des
    FROM UAU.dbo.ContasPagas
    WHERE ContasPagas.Empresa_pag = VwDesembolso.Empresa_Des
          AND ContasPagas.ObraProc_Pag = VwDesembolso.Obra_Des
          AND ContasPagas.NumProc_Pag = VwDesembolso.NumProc_Des
) AS DadosProc
    LEFT JOIN UAU.dbo.ItensContrato
        ON ItensContrato.Empresa_itens = VwDesembolso.Empresa_Des
           AND ItensContrato.Contrato_itens = DadosProc.ContratoServ_des
           AND ItensContrato.Serv_itens = VwDesembolso.ItemProc_Des
--WHERE VwDesembolso.Obra_Des in ('3401C')--,'5501C','4701C','7601C')
--	AND VwDesembolso.Empresa_Des = 34
--	AND VwDesembolso.PlMes_Des BETWEEN <MesInicial> AND <MesTerm>
--	AND VwDesembolso.InsumoPl_Des LIKE (<Insumo>)
--	AND VwDesembolso.CompPl_Des IN ('C02000')

GROUP BY VwDesembolso.Empresa_Des,
         Empresas.Desc_emp,
         VwDesembolso.Obra_Des,
         Obras.descr_obr,
         VwDesembolso.DtPgto_Des,
         VwDesembolso.CompPl_Des,
         Composicoes.Descr_comp,
         VwDesembolso.InsumoPl_Des,
         Insumos.Descr_ins,
         VwDesembolso.CodForn_Des,
         Pessoas.nome_pes,
         VwDesembolso.NumProc_Des,
         VwDesembolso.NumParc_Des,
         VwDesembolso.PlMes_Des,
         VwDesembolso.ItemProc_Des,
         VwDesembolso.TipoProc_Des,
         ItensContrato.Descr_itens,
         InsumosGeral.Descr_ins,
         NotasFiscaisEnt.NumNfAux_nfe,
         VwDesembolso.QtdeItem_Des,
         VwDesembolso.ValorUnitItem_Des,
         VwDesembolso.TotalLiq_des
--ORDER BY VwDesembolso.PlMes_Des,
--         VwDesembolso.Empresa_Des,
--         VwDesembolso.Obra_Des,
--         VwDesembolso.CompPl_Des,
--         VwDesembolso.InsumoPl_Des,
--         VwDesembolso.CodForn_Des
go

