
create view [dbo].[VW_GER_CONTROLE_ORDEM_COMPRAS] as (

SELECT *
FROM
(
    SELECT 
           Empresa_Ocp,
           CodForn_Ocp,
           Anexos_Ocp,
           Usuario_Ocp,
           NumeroOC_Ocp,
           DataGer_Ocp,
           Obra_Ocp,
           Tipo_Ocp,
           EmpPaga_Ocp,
           EmpFatura_Ocp,
           NumCot_Ocp,
           Empresas.desc_emp,
           Origem_Ocp,
           TransfCusto_OCp,
           Pessoas.Nome_pes AS 'PessoasNome_pes',
           (CAST(OrdemCompra.EmpPaga_Ocp AS varchar) + ' ' + (Pessoas1.Nome_pes)) AS 'Pessoas1EmpPaga',
           (CAST(OrdemCompra.EmpFatura_Ocp AS varchar) + ' ' + (Pessoas2.Nome_pes)) AS 'Pessoas2EmpFatura',
           CasaDecQtde_Ocp,
           CasaDecPreco_Ocp,
           Contrato_ocp,
           CASE
               WHEN vwDadosProc.Empresa_dproc IS NULL THEN
                   1
               ELSE
                   0
           END Excluida_Ocp,
           ISNULL(Desc_Ocp, 0) + ISNULL(DescontoMed, 0) AS Desconto,
           ISNULL(Total - (ISNULL(Desc_Ocp, 0) + ISNULL(DescontoMed, 0)), 0) AS TotalLiquido,
           CASE
               WHEN NumAc_Ocp IS NOT NULL THEN
                   1
               ELSE
                   0
           END AS OcpAcordoCorp,
           NumAc_Ocp,
           OrdemCompra.StatusEnvio_Ocp,
           Cotacao.Tipo_cot,
		   Total
    FROM UAU.dbo.OrdemCompra
        INNER JOIN
        (
            SELECT Empresa_Ioc,
                   Obra_Ioc,
                   NumeroOC_Ioc,
                   SUM(ROUND((Qtde_Ioc + QtdeAMais_Ioc) * Preco_Ioc, 2)) AS Total,
                   SUM(ROUND(Qtde_Ioc * Preco_Ioc, 2)) AS TotalOrigItens
            FROM UAU.dbo.ItensOrdemCompra WITH (NOLOCK)
            GROUP BY Empresa_Ioc,
                     Obra_Ioc,
                     NumeroOC_Ioc
        ) AS TabTotal
            ON TabTotal.Empresa_Ioc = Empresa_Ocp
               AND TabTotal.Obra_Ioc = Obra_Ocp
               AND TabTotal.NumeroOC_Ioc = NumeroOC_Ocp
        INNER JOIN UAU.dbo.Empresas AS Empresas
            ON Empresas.codigo_emp = Empresa_Ocp
        LEFT JOIN UAU.dbo.Pessoas
            ON OrdemCompra.CodForn_Ocp = Pessoas.Cod_pes
        LEFT JOIN UAU.dbo.Pessoas AS Pessoas1
            ON OrdemCompra.EmpPaga_Ocp = Pessoas1.Cod_pes
        LEFT JOIN UAU.dbo.Pessoas AS Pessoas2
            ON OrdemCompra.EmpFatura_Ocp = Pessoas2.Cod_pes
        LEFT JOIN UAU.dbo.vwDadosProc
            ON vwDadosProc.Empresa_dproc = OrdemCompra.Empresa_Ocp
               AND vwDadosProc.Obra_dproc = OrdemCompra.Obra_Ocp
               AND vwdadosproc.NumOc_dproc = OrdemCompra.NumeroOC_Ocp
        LEFT JOIN
        (
            SELECT Empresa_proc,
                   Obra_proc,
                   OrdemCompra_proc,
                   COALESCE(MAX(COALESCE(Contrato_adcont, Contrato_proc)), 0) AS Contrato_ocp,
                   ISNULL(MAX(Dados_proc.CodMed_Proc), 0) AS CodMed_Proc
            FROM UAU.dbo.Dados_proc WITH (NOLOCK)
                LEFT JOIN UAU.dbo.AdiantamentoContrato WITH (NOLOCK)
                    ON Dados_proc.Empresa_proc = AdiantamentoContrato.Empresa_AdCont
                       AND Dados_proc.Num_proc = AdiantamentoContrato.NumProc_AdCont
                       AND Dados_proc.Obra_proc = AdiantamentoContrato.Obra_AdCont
            WHERE COALESCE(COALESCE(Contrato_adcont, Contrato_proc), 0) <> 0
            GROUP BY Empresa_proc,
                     Obra_proc,
                     OrdemCompra_proc
            UNION
            SELECT Empresa_pag,
                   ObraProc_pag,
                   OrdemCompra_pag,
                   COALESCE(MAX(COALESCE(Contrato_adcont, Contrato_pag)), 0) AS Contrato_ocp,
                   ISNULL(MAX(CodMed_Pag), 0) AS CodMed_Proc
            FROM UAU.dbo.ContasPagas WITH (NOLOCK)
                LEFT JOIN UAU.dbo.AdiantamentoContrato WITH (NOLOCK)
                    ON ContasPagas.Empresa_pag = AdiantamentoContrato.Empresa_AdCont
                       AND ContasPagas.NumProc_pag = AdiantamentoContrato.NumProc_AdCont
                       AND ContasPagas.ObraProc_pag = AdiantamentoContrato.Obra_AdCont
            WHERE COALESCE(COALESCE(Contrato_adcont, Contrato_pag), 0) <> 0
            GROUP BY Empresa_pag,
                     ObraProc_pag,
                     OrdemCompra_pag
        ) AS TabContrato
            ON TabContrato.Empresa_proc = Empresa_ocp
               AND TabContrato.Obra_Proc = Obra_ocp
               AND TabContrato.OrdemCompra_proc = NumeroOC_ocp
               AND COALESCE(Contrato_ocp, 0) <> 0
        OUTER APPLY
    (
        SELECT SUM(ItensMedicao.Qtde_Item * ItensMedicao.PrecoUnit_Item) TotalMed
        FROM UAU.dbo.ItensMedicao
        WHERE Empresa_item = tabContrato.Empresa_Proc
              AND Contrato_Item = TabContrato.Contrato_ocp
              AND CodMed_Item = TabContrato.CodMed_Proc
    ) TotalMedicao
        OUTER APPLY
    (
        SELECT CAST((TotalOrigItens / CASE
                                          WHEN ISNULL(TotalMed, 0) = 0 THEN
                                              1
                                          ELSE
                                              TotalMed
                                      END
                    ) * ISNULL(SUM(Valor_DescM), 0) AS NUMERIC(18, 2)) AS DescontoMed
        FROM UAU.dbo.DescMedicao
        WHERE Empresa_DescM = tabContrato.Empresa_Proc
              AND Contrato_DescM = TabContrato.Contrato_ocp
              AND CodMed_DescM = tabContrato.CodMed_Proc
              AND Tipo_DescM = 0
    ) DescontoMedicao
        LEFT JOIN UAU.dbo.Cotacao
            ON Cotacao.Empresa_cot = ordemcompra.Empresa_Ocp
               AND Cotacao.Num_cot = ordemcompra.NumCot_Ocp
               AND ordemcompra.NumCot_Ocp <> 0
    --WHERE DataGer_Ocp BETWEEN '01/01/2024' AND '12/31/2024'
    GROUP BY Empresa_Ocp,
             CodForn_Ocp,
             Usuario_Ocp,
             NumeroOC_Ocp,
             DataGer_Ocp,
             Obra_Ocp,
             Tipo_Ocp,
             EmpPaga_Ocp,
             EmpFatura_Ocp,
             NumCot_Ocp,
             Empresas.desc_emp,
             Origem_Ocp,
             TransfCusto_OCp,
             Pessoas.Nome_pes,
             (CAST(OrdemCompra.EmpPaga_Ocp AS varchar) + ' ' + (Pessoas1.Nome_pes)),
             (CAST(OrdemCompra.EmpFatura_Ocp AS varchar) + ' ' + (Pessoas2.Nome_pes)),
             CasaDecQtde_Ocp,
             CasaDecPreco_Ocp,
             Total,
             Anexos_Ocp,
             CasaDecPreco_Ocp,
             Contrato_ocp,
             vwDadosProc.Empresa_dproc,
             Desc_Ocp,
             DescontoMed,
             NumAc_Ocp,
             OrdemCompra.StatusEnvio_Ocp,
             Cotacao.Tipo_cot
) AS TabAux
WHERE Excluida_Ocp IN ( 0 )
--ORDER BY NumeroOC_Ocp DESC,
--         DataGer_Ocp DESC

)
go

