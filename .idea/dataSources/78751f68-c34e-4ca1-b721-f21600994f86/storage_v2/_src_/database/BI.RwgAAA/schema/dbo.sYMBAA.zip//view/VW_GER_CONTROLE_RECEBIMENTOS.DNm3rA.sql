CREATE VIEW [dbo].[VW_GER_CONTROLE_RECEBIMENTOS] AS 

SELECT *
FROM
(
    SELECT RecebePgto.*
         , RecebePgtoDiv.PercentValor_Rpd
         , (CASE 
                WHEN VendasRecebidas.AniversarioContr_VRec = 0 THEN (RecebePgtoDiv.PercentPrinc_Rpd)
                ELSE (RecebePgtoDiv.PercentPrinc_Rpd + RecebePgtoDiv.PercentJurCompEmb_Rpd + RecebePgtoDiv.PercentCorrEmb_Rpd)
            END) AS PercentPrinc_Rpd
         , RecebePgtoDiv.Cap_Rpd
         , RecebePgtoDiv.CapCorrecaoAtr_Rpd
         , RecebePgtoDiv.CapJuros_Rpd
         , RecebePgtoDiv.CapCorrecao_Rpd
         , RecebePgtoDiv.CapMulta_Rpd
         , RecebePgtoDiv.CapJurosAtr_Rpd
         , RecebePgtoDiv.CapAcrescimo_Rpd
         , RecebePgtoDiv.CapDesconto_Rpd
         , RecebePgtoDiv.CapDescontoAntec_Rpd
         , RecebePgtoDiv.CapTaxaBol_Rpd
         , RecebePgtoDiv.CapDescontoCusta_Rpd
         , CapRepasse_Rpd
         , RecebePgtoDiv.PercentDescontoCusta_Rpd
         , RecebePgtoDiv.PercentDescontoImposto_Rpd
         , RecebePgtoDiv.TipoRpg_Rpd
         , RecebePgtoDiv.NumParc_Rpd
         , RecebePgtoDiv.NumVend_Rpd
         , RecebePgtoDiv.Obra_Rpd
         , RecebePgtoDiv.Tipo_rpd
         , RecebePgtoDiv.NumParcGer_Rpd
         , RecebePgtoDiv.NumReceb_rpd
         , RecebePgtoDiv.NumMdr_Rpd
         , CASE
               WHEN RecebePgto.Status_Rpg = 2 THEN null
               ELSE Recebidas.Data_Rec
           END AS Data_rec
         , CASE
               WHEN RecebePgto.Status_Rpg = 2 THEN null
               ELSE Recebidas.DataVenci_Rec
           END AS DataVenci_Rec
         , CASE
               WHEN Extrato.Data_doc IS NULL THEN '0'
               ELSE '1'
           END AS Conciliado
         , Extrato.UsrCad_doc
         , Extrato.Data_doc
         , CapDescontoCondicional_Rpd
         , Recebidas.DataIniPeriodoAluguel_rec
         , RecebePgtoCartao.NumTerminal_rpc
         , RecebePgtoCartao.NSU_rpc
         , RecebePgtoCartao.NumReferencia_rpc
         , RecebePgtoCartao.CodAutorizacao_rpc
         , RecebePgtoCartao.ValorTaxaCartao_rpc
         , RecebePgtoCartao.Modalidade_rpc
    FROM UAU.dbo.RecebePgtoDiv WITH (NOLOCK)
        INNER JOIN UAU.dbo.RecebePgto WITH (NOLOCK)
            ON RecebePgtoDiv.Empresa_Rpd = RecebePgto.Empresa_rpg
               AND RecebePgtoDiv.NumReceb_Rpd = RecebePgto.NumReceb_Rpg
               AND RecebePgtoDiv.TipoRpg_Rpd = RecebePgto.Tipo_Rpg
               AND RecebePgtoDiv.NumCont_Rpd = RecebePgto.NumCont_Rpg
        LEFT JOIN UAU.dbo.Extrato WITH (NOLOCK)
            ON RecebePgto.Empresa_Rpg = Extrato.Empresa_doc
               AND RecebePgto.ContaDep_Rpg = Extrato.Conta_doc
               AND RecebePgto.BancoDep_Rpg = Extrato.Banco_doc
               AND CAST(RecebePgto.NumDep_Rpg AS VARCHAR) = Extrato.Numero_doc
               AND Extrato.Tipo_doc = 1
        LEFT JOIN UAU.dbo.VendasRecebidas WITH (NOLOCK)
            ON RecebePgtoDiv.Empresa_Rpd = Empresa_VRec
               AND RecebePgtoDiv.Obra_Rpd = Obra_VRec
               AND RecebePgtoDiv.NumVend_Rpd = Num_VRec
        LEFT JOIN UAU.dbo.Recebidas WITH (NOLOCK)
            ON RecebePgtoDiv.Empresa_Rpd = Recebidas.Empresa_Rec
               AND RecebePgtoDiv.NumVend_Rpd = Recebidas.NumVend_Rec
               AND RecebePgtoDiv.Obra_Rpd = Recebidas.Obra_Rec
               AND RecebePgtoDiv.NumParc_Rpd = Recebidas.NumParc_Rec
               AND RecebePgtoDiv.ParcType_Rpd = Recebidas.ParcType_Rec
               AND RecebePgtoDiv.Tipo_Rpd = Recebidas.Tipo_Rec
               AND RecebePgtoDiv.NumParcGer_Rpd = Recebidas.NumParcGer_Rec
        LEFT JOIN UAU.dbo.RecebePgtoCartao WITH (NOLOCK)
            ON RecebePgtoCartao.Empresa_rpc = RecebePgto.Empresa_rpg
               AND RecebePgtoCartao.NumReceb_rpc = RecebePgto.NumReceb_Rpg
               AND RecebePgtoCartao.Tipo_rpc = RecebePgto.Tipo_Rpg
               AND RecebePgtoCartao.NumCont_rpc = RecebePgto.NumCont_Rpg
    --WHERE RecebePgtoDiv.Empresa_Rpd = 54
          --AND RecebePgtoDiv.Obra_Rpd = '5401I'
          --AND RecebePgtoDiv.NumVend_Rpd = 3
) as Recebe
--ORDER BY NumReceb_Rpg DESC
go

