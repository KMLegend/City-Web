


CREATE VIEW [dbo].[VW_GER_CONTROLE_ITENS_COMPRADOS] AS

--Mostra relação de itens comprados 
/* Variaveis:
Empresa - Código da(s) empresa(s).  -- numerico
Insumos - Código do(s) insumo(s).  -- texto
*/

SELECT 
	Empresa_Item
	, UPPER(Desc_Emp) AS [Desc_Emp]
	, UPPER(CAST(Empresa_Item AS VARCHAR) + ' - ' + Desc_Emp) AS [Empresa]
	, ObraProc_Item
	, UPPER(Descr_Obr) AS [Descr_Obr]
	, UPPER(ObraProc_Item + ' - ' + Descr_Obr) AS [Obra]
	, NumProc_Item
	, CodInsProc_Item
	, UPPER(Descr_ins) AS [Descr_Ins]
	, UPPER(CodInsProc_Item + ' - ' + Descr_Ins) AS [Insumo]
	, UnidProc_Item
	, QtdeProc_Item
	, ValUnitProc_Item
	, SubTotal_Item
	, Total_Item
	, UPPER(ChqNome_Pag) AS [Fornecedor]
FROM UAU.dbo.Itens_Proc
INNER JOIN UAU.dbo.ContasPagas
	ON Empresa_Item = Empresa_Pag
		AND NumProc_Item = NumProc_Pag
		AND ObraProc_Item = ObraProc_Pag
INNER JOIN UAU.dbo.InsumosGeral
	ON CodInsProc_Item = Cod_Ins
INNER JOIN UAU.dbo.Obras
	ON Empresa_Item = Empresa_Obr
		AND ObraProc_Item = Cod_Obr
INNER JOIN UAU.dbo.Empresas
	ON Empresa_Item = Codigo_Emp
INNER JOIN UAU.dbo.Pessoas
	ON CodForn_Pag = Cod_Pes

--WHERE ObraProc_Item in ('3401C')--,'5501C','4701C','7601C')

--WHERE	Empresa_item IN (34)--55,47,76) 
	--AND CodInsProc_Item IN ('4444444444') --(SELECT * FROM fn_SplitForTable(<Insumos>,',')) 

GROUP BY 
	Empresa_item
	, ObraProc_Item
	, NumProc_Item
	, CodInsProc_Item
	, Descr_ins
	, UnidProc_Item
	, QtdeProc_Item
	, ValUnitProc_Item
	, SubTotal_Item
	, Total_Item
	, ChqNome_Pag
	, NumProc_Pag
	, Desc_emp
	, Descr_obr
--ORDER BY 
--	Desc_Emp
--	, Descr_Obr
--	, NumProc_Pag
--	, Descr_Ins
go

