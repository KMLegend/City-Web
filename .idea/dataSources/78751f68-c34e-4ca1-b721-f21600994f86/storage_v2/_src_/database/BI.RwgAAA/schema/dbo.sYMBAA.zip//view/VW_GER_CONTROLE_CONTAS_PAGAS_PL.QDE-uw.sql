

CREATE VIEW [dbo].[VW_GER_CONTROLE_CONTAS_PAGAS_PL] AS

--Contas A Pagar e Pagas com vínculo PL, totalizando por insumo.
/* Variaveis:
Data Inicio - data inicial da busca - datetime
Data Termino - data inicial da busca - datetime
Empresa e Obra - busca emp e obra -- texto/numerico
Insumo - codigo do insumo(s) -- numerico
Status - Status do contrato (0 -  A pagar, 1 - Em emissão, 2 - Pago e 3 - Enviado para Banco. Para selecionar vários separe por vírgula, Ex.: 0,1,2,3.).  -- numerico
*/
-- AND Obra_Cont in ('3401C','5501C','4701C','7601C')

SELECT VwDesembolso.*,
       CASE
           WHEN (StatusParc_des <> 2) THEN 'A Pagar'
       ELSE 'Pago'  END [StatusParcProc],
       CASE 
           WHEN TipoProc_des = 0 THEN 'Cotação'
           WHEN TipoProc_des = 1 THEN 'Processo de Pagamento'
           WHEN TipoProc_des = 2 THEN 'Compra Rápida'
           WHEN TipoProc_des = 3 THEN 'Proc. Vinculado'
           WHEN TipoProc_des = 4 THEN 'Proc. Transporte'
           WHEN TipoProc_des = 5 THEN 'Proc. Interno'
           WHEN TipoProc_des = 6 THEN 'Folha'
           WHEN TipoProc_des = 7 THEN 'Medição'
           WHEN TipoProc_des = 8 THEN 'Cotação sem Estoque'
           WHEN TipoProc_des = 9 THEN 'Inicialização de Estoque'
           WHEN TipoProc_des = 10 THEN 'Acomp. Entr. s/ Estoque'
           WHEN TipoProc_des = 11 THEN 'Compra de Patrimônio'
           WHEN TipoProc_des = 12 THEN 'Manutenção de Patrimônio'
           WHEN TipoProc_des = 13 THEN 'Adiantamento de Caixa de Obra'
           WHEN TipoProc_des = 14 THEN 'Repasse de Aluguel'
           WHEN TipoProc_des = 15 THEN 'Comissão'
           WHEN TipoProc_des = 16 THEN 'Retenção Contratual'
           WHEN TipoProc_des = 17 THEN 'Distrato de Venda'
           WHEN TipoProc_des = 18 THEN 'Módulo Folha de Pagamento'
       ELSE '' END [Tipo],
       --CAST(<DataInicio> AS DATETIME) [DataInicio], 
       --CAST(<DataTermino> AS DATETIME) [DataTermino],
       (
           SELECT TOP 1
               DataEmis_nfe
           FROM UAU.dbo.NotasFiscaisEnt with (nolock)
               INNER JOIN UAU.dbo.NotFisc_proc with (nolock)
                   ON Empresa_proc = Empresa_nfe
                      AND NumNfe_Proc = Num_nfe
           WHERE Empresa_proc = Empresa_des
                 AND Num_Proc = NumProc_des
                 AND NumParc_Proc = NumParc_des
                 AND Obra_Proc = Obra_des
       ) [DataEmissaoNF],
       case
           WHEN CAST(oc.Obs_Ocp AS VARCHAR(400)) <> '' then
               CAST(oc.Obs_Ocp AS VARCHAR(400))
           ELSE
               VwDesembolso.HistContab_Des
       END [ObservacaoGeral]
FROM UAU.dbo.vwDesembolso with (nolock)
    LEFT JOIN UAU.dbo.OrdemCompra AS oc with (nolock)
        ON vwDesembolso.Empresa_Des = oc.Empresa_Ocp
           AND vwDesembolso.Obra_Des = oc.Obra_Ocp
           AND vwDesembolso.NumOc_Des = oc.NumeroOC_Ocp
WHERE StatusParc_Des IN (0,1,2,3)
-- AND Obra_Des in ('3401C','5501C','4701C','7601C')
-- AND InsumoPl_des IN (SELECT * FROM fn_SplitForTable(<Insumo>,',')) 
-- AND DtPgto_des BETWEEN <DataInicio> AND <DataTermino>
--ORDER BY Empresa_des,
--         Obra_des,
--         InsumoPL_des,
--         DtPgto_des
go

