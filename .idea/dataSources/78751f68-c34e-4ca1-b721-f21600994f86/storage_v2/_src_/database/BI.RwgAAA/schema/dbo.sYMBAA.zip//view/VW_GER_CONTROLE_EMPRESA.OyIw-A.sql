

CREATE VIEW [dbo].[VW_GER_CONTROLE_EMPRESA] AS 

SELECT 
	Codigo_emp,
	Desc_emp,
	CGC_emp,
	NomeFantasia_emp,
	Endereco_emp,
	Setor_emp,
	Cidade_emp,
	UF_emp
FROM UAU.dbo.Empresas

go

