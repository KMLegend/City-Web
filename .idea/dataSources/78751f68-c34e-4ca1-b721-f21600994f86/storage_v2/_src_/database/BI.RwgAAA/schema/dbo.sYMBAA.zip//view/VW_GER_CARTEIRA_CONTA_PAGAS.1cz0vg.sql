

CREATE VIEW [dbo].[VW_GER_CARTEIRA_CONTA_PAGAS] AS (

SELECT BASE.*
FROM (
SELECT
	[CODEMP] -- codigo da empresa 
	,[CODOBR] -- codigo da obra
	,[NUMPROC_DES] -- codigo do contrato de compra
	,[NUMPARC_DES] --qual de parcela da compra
	--,[COD_COMP]
	--,[DESCR_COMP]
	--,[ITEMPROC_DES]
	--,[DESCR_INS]
	--,[CONTRATOPL_DES]
	,[PRODUTOPL_DES] -- codigo da produto
	--,[ITEMPL_DES]
	,[COMPPL_DES] -- codigo da composicao
	,[INSUMOPL_DES] -- codigo da insumo
	--,[STATUSPARC_DES]
	--,[PLMES_DES] -- mes de referencia de planejamento da compra
	,[DTPGTO_DES] -- data do pagamento da compra
	--,[QTDEITEM_DES]
	--,[VALORUNITITEM_DES]
	--,[ACRESCIMO_DES]
	--,[DESCONTO_DES]
	,CAST([TOTALLIQ_DES]AS FLOAT) AS [TOTALLIQ_DES]
	,CAST([TOTALBRUTO_DES]AS FLOAT) AS [TOTALBRUTO_DES]
	--,[PORC_DES]
	,'CONTA EM ABERTO' AS [STATUS]
  FROM [BI].[dbo].[TB_GER_CONTROLE_CONTA_A_PAGAR]

 --WHERE CODEMP = 1
  --AND CODOBR = '01NOV'
  --AND [NUMPROC_DES] = 140
  --AND [INSUMOPL_DES] = 1140400096
  --AND [COMPPL_DES] = 'C42626'
  --AND [PRODUTOPL_DES] = 68


UNION ALL

SELECT
	[CODEMP] -- codigo da empresa 
	,[CODOBR] -- codigo da obra
	,[NUMPROC_DES] -- codigo do contrato de compra
	,[NUMPARC_DES] --qual de parcela da compra
	--,[COD_COMP]
	--,[DESCR_COMP]
	--,[ITEMPROC_DES]
	--,[DESCR_INS]
	--,[CONTRATOPL_DES]
	,[PRODUTOPL_DES] -- codigo da produto
	--,[ITEMPL_DES]
	,[COMPPL_DES] -- codigo da composicao
	,[INSUMOPL_DES] -- codigo da insumo
	--,[STATUSPARC_DES]
	--,[PLMES_DES] -- mes de referencia de planejamento da compra
	,[DTPGTO_DES] -- data do pagamento da compra
	--,[QTDEITEM_DES]
	--,[VALORUNITITEM_DES]
	--,[ACRESCIMO_DES]
	--,[DESCONTO_DES]
	,CAST([TOTALLIQ_DES]AS FLOAT) AS [TOTALLIQ_DES]
	,CAST([TOTALBRUTO_DES]AS FLOAT) AS [TOTALBRUTO_DES]
	--,[PORC_DES]
	,'CONTA PAGA' AS [STATUS]
  FROM [BI].[dbo].[TB_GER_CONTROLE_CONTA_PAGO]


  --WHERE CODEMP = 1
  --AND CODOBR = '01NOV'
  --AND [NUMPROC_DES] = 140
  --AND [INSUMOPL_DES] = 1140400096
  --AND [COMPPL_DES] = 'C42626'
  --AND [PRODUTOPL_DES] = 68




) AS BASE

--WHERE [DTPGTO_DES] >= '2024-01-01'

--ORDER BY 1,2,3,4
)
go

