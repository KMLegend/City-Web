
create view [dbo].[VW_GER_CONTROLE_VALOR_INDICES] as 

SELECT 
	   [Idx_vi]
      ,[Data_vi]
      ,[Valor_vi]
      ,[DataFim_vi]
      ,[Anexos_vi]
      ,[DataCad_vi]
      ,[UsrCad_vi]
      ,[TipoCadastro_vi]
FROM UAU.dbo.ValIdx  
--WHERE idx_vi = 'INCCD' 
--ORDER BY Data_vi DESC


go

