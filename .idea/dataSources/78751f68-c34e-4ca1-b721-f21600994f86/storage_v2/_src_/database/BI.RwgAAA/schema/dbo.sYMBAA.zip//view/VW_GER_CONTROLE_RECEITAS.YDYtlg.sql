CREATE VIEW dbo.VW_GER_CONTROLE_RECEITAS AS 

WITH 
BDContasRecebidas AS (
	SELECT 
			RecebePgtoDiv.Empresa_Rpd,
			RecebePgtoDiv.Obra_Rpd,
			ItensRecebidas.Produto_Itr,
			RecebePgtoDiv.NumVend_Rpd,
			RecebePgtoDiv.NumParc_Rpd,
			ISNULL(Extrato.Data_Doc, Recebidas.Data_Rec) [DataP],
			RecebePgto.Cliente_Rpg,
			SUM((CASE WHEN(RecebePgtoDiv.PercentValor_Rpd *((ItensRecebidas.PrecoProc_Itr * ItensRecebidas.Qtde_Itr) - ItensRecebidas.ValComissaoDir_Itr)) = 0 THEN 1 ELSE (RecebePgtoDiv.PercentValor_Rpd *((ItensRecebidas.PrecoProc_Itr * ItensRecebidas.Qtde_Itr) - ItensRecebidas.ValComissaoDir_Itr)) END) / (CASE WHEN VendasRecebidas.ValorTot_VRec = 0 THEN (CASE WHEN(RecebePgtoDiv.PercentValor_Rpd *((ItensRecebidas.PrecoProc_Itr * ItensRecebidas.Qtde_Itr) - ItensRecebidas.ValComissaoDir_Itr)) = 0 THEN 1 ELSE (RecebePgtoDiv.PercentValor_Rpd *((ItensRecebidas.PrecoProc_Itr * ItensRecebidas.Qtde_Itr) - ItensRecebidas.ValComissaoDir_Itr)) END) ELSE VendasRecebidas.ValorTot_VRec END)) [VlRec],
			'Recebido' [Status],
			RecebePgto.BancoChq_Rpg,
			RecebePgto.ContaChq_Rpg
		FROM UAU.dbo.RecebePgto
		INNER JOIN UAU.dbo.RecebePgtoDiv 
			ON RecebePgto.Empresa_Rpg = RecebePgtoDiv.Empresa_Rpd
			AND RecebePgto.NumReceb_Rpg = RecebePgtoDiv.NumReceb_Rpd
			AND RecebePgto.Tipo_Rpg = RecebePgtoDiv.TipoRpg_Rpd
			AND RecebePgto.NumCont_Rpg = RecebePgtoDiv.NumCont_Rpd
		INNER JOIN UAU.dbo.VendasRecebidas 
			ON RecebePgtoDiv.Empresa_Rpd = VendasRecebidas.Empresa_VRec
			AND RecebePgtoDiv.NumVend_Rpd = VendasRecebidas.Num_VRec
			AND RecebePgtoDiv.Obra_Rpd = VendasRecebidas.Obra_VRec
		INNER JOIN UAU.dbo.ItensRecebidas 
			ON VendasRecebidas.Empresa_VRec = ItensRecebidas.Empresa_Itr
			AND VendasRecebidas.Num_VRec = ItensRecebidas.NumVend_Itr
			AND VendasRecebidas.Obra_VRec = ItensRecebidas.Obra_Itr
		INNER JOIN UAU.dbo.Recebidas 
			ON RecebePgtoDiv.Empresa_Rpd = Recebidas.Empresa_Rec
			AND RecebePgtoDiv.NumVend_Rpd = Recebidas.NumVend_Rec
			AND RecebePgtoDiv.Obra_Rpd = Recebidas.Obra_Rec
			AND RecebePgtoDiv.NumParc_Rpd = Recebidas.NumParc_Rec
			AND RecebePgtoDiv.ParcType_Rpd = Recebidas.ParcType_Rec
			AND RecebePgtoDiv.Tipo_Rpd = Recebidas.Tipo_Rec
			AND RecebePgtoDiv.NumParcGer_Rpd = Recebidas.NumParcGer_Rec
		INNER JOIN UAU.dbo.Extrato 
			ON RecebePgto.BancoDep_Rpg = Extrato.Banco_Doc
			AND RecebePgto.Empresa_Rpg = Extrato.Empresa_Doc
			AND RecebePgto.ContaDep_Rpg = Extrato.Conta_Doc
			AND CAST(RecebePgto.NumDep_Rpg AS VARCHAR) = Extrato.Numero_Doc
		WHERE 
			RecebePgto.Status_Rpg <> 2
			AND VendasRecebidas.TipoVenda_VRec IN (0,1,2,3,4)
		GROUP BY 
			RecebePgtoDiv.Empresa_Rpd,
			RecebePgtoDiv.Obra_Rpd,
			ItensRecebidas.Produto_Itr,
			RecebePgtoDiv.NumVend_Rpd,
			RecebePgtoDiv.NumParc_Rpd,
			ISNULL(Extrato.Data_Doc, Recebidas.Data_Rec),
			RecebePgto.Cliente_Rpg,
			RecebePgto.BancoChq_Rpg,
			RecebePgto.ContaChq_Rpg
)

,BDContasReceber AS (
	SELECT * 
	FROM UAU.dbo.ContasReceber 
	INNER JOIN UAU.dbo.ContasReceberCalc 
		ON ContasReceber.Empresa_Prc = ContasReceberCalc.Empresa_Crc
		AND ContasReceber.Obra_Prc = ContasReceberCalc.Obra_Crc
		AND ContasReceber.NumVend_Prc = ContasReceberCalc.NumVend_Crc
		AND ContasReceber.NumParc_Prc = ContasReceberCalc.NumParc_Crc
		AND ContasReceber.Tipo_Prc = ContasReceberCalc.Tipo_Crc
		AND ContasReceber.NumParcGer_Prc = ContasReceberCalc.NumParcGer_Crc
)
		
,BDUnidades AS (
	SELECT 
		ItensVenda.Empresa_Itv,
		ItensVenda.Obra_Itv,
		ItensVenda.NumVend_Itv,
		ItensVenda.Produto_Itv,
		MAX(ItensVenda.CodPerson_Itv) AS [Personalizao]
	FROM UAU.dbo.ItensVenda
	GROUP BY 
		ItensVenda.Empresa_Itv,
		ItensVenda.Obra_Itv,
		ItensVenda.NumVend_Itv,
		ItensVenda.Produto_Itv

	UNION 
				
	SELECT 
		ItensRecebidas.Empresa_Itr,
		ItensRecebidas.Obra_Itr,
		ItensRecebidas.NumVend_Itr,
		ItensRecebidas.Produto_Itr,
		MAX(ItensRecebidas.CodPerson_Itr) AS [Personalizao]
	FROM UAU.dbo.ItensRecebidas
	GROUP BY 
		ItensRecebidas.Empresa_Itr,
		ItensRecebidas.Obra_Itr,
		ItensRecebidas.NumVend_Itr,
		ItensRecebidas.Produto_Itr
		
)

,BDPorcentagemPorProduto AS (
	SELECT 
		Vendas.Empresa_Ven,
		Vendas.Obra_Ven,
		Vendas.Num_Ven,
		ItensVenda.Produto_Itv,
		((ItensVenda.PrecoProc_Itv * ItensVenda.Qtde_Itv) - ItensVenda.ValComissaoDir_Itv) / Vendas.ValorTot_Ven AS [PorcentagemPorProduto]
	FROM UAU.dbo.Vendas 
	INNER JOIN UAU.dbo.ItensVenda 
		ON Vendas.Empresa_Ven = ItensVenda.Empresa_Itv
		AND Vendas.Obra_Ven = ItensVenda.Obra_Itv
		AND Vendas.Num_Ven = ItensVenda.NumVend_Itv
	WHERE Vendas.TipoVenda_Ven IN (0,1,2,3,4)
	
)

,BDVinculoNotaVenda AS (
	SELECT 
		VinculoNotaVenda.EmpresaNf_Vnv,
		VinculoNotaVenda.ObraVen_Vnv,
		VinculoNotaVenda.NumVen_Vnv,
		MAX(NotasFiscais.NumNfAux_Nf) AS [NumNfAux_Nf]
	FROM UAU.dbo.VinculoNotaVenda
	INNER JOIN UAU.dbo.NotasFiscais 
		ON VinculoNotaVenda.EmpresaNf_Vnv = NotasFiscais.Empresa_Nf
		AND VinculoNotaVenda.NumNf_Vnv = NotasFiscais.Num_Nf
	GROUP BY 
		VinculoNotaVenda.EmpresaNf_Vnv,
		VinculoNotaVenda.ObraVen_Vnv,
		VinculoNotaVenda.NumVen_Vnv
		
) 
	
,BDTotRec AS (
	SELECT 
			Empresa_Rpd AS Empresa_Rpd,
			Obra_Rpd AS Obra_Rpd,
			Produto_Itr AS Produto_Itr,
			NumVend_Rpd AS NumVend_Rpd,
			NumParc_Rpd AS NumParc_Rpd,
			[DataP] AS DataP,
			Cliente_Rpg AS Cliente_Rpg,
			[VlRec] AS VlRec,
			[Status] AS Status,
			BancoChq_Rpg AS BancoChq_Rpg,
			ContaChq_Rpg AS ContaChq_Rpg
	FROM BDContasRecebidas
	
	UNION 
	
	SELECT 
		Empresa_Ven AS Empresa_Rpd,
		Obra_Ven AS Obra_Rpd,
		Produto_Itv AS Produto_Itr,
		Num_Ven AS NumVend_Rpd,
		NumParcGer_Prc AS NumParc_Rpd,
		DataPror_Prc AS DataP,
		Cliente_Prc AS Cliente_Rpg,
		ValParcela_Crc * PorcentagemPorProduto AS VlRec,
		'Receber' AS Status,
		-1 AS BancoChq_Rpg,
		'1-1' AS ContaChq_Rpg
	FROM BDPorcentagemPorProduto
	INNER JOIN BDContasReceber
		ON Empresa_Ven = Empresa_Prc
		AND Obra_Ven = Obra_Prc
		AND Num_Ven = NumVend_Prc

)


--SELECT 
--	BASE.DataP AS DataMovimento,
--	BASE.Empresa_Rpd AS Cod_Emp,
--	BASE.Obra_Rpd AS Obra,
--	CAST(BASE.Produto_Itr AS VARCHAR) AS Insumo,
--	BASE.DescrInsumo AS DescrInsumo,
--	BASE.Cliente AS Cliente,
--	BASE.NumProc AS NumProcesso,
--	BASE.[Doc Fiscal] AS [Doc Fiscal],
--	BASE.VlrItemReceber + BASE.Recebido AS TotalReceita,
--	'R' AS Tipo,
--	'Receitas' AS TipoControle
--FROM (
	SELECT 
		A.Empresa_Rpd,
		A.Obra_Rpd,
		CAST(A.NumVend_Rpd AS VARCHAR) + '/' + CAST(A.NumParc_Rpd AS VARCHAR) AS [Parcela],
		CAST(A.Produto_Itr AS VARCHAR) AS [Produto],
		'' [Servico],
		PrdSrv.Descricao_Psc [DescrInsumo],
		PrdSrv.Descricao_Psc [DescrServico],
		UnidadePer.Identificador_Unid [NumProc],
		CAST(B.NumNfAux_Nf AS VARCHAR) [Doc Fiscal],
		A.DataP,
		ISNULL((CASE WHEN Status = 'Receber' THEN A.VlRec ELSE 0 END),0) [VlrItemReceber],
		ISNULL((CASE WHEN Status = 'Recebido' THEN A.VlRec ELSE 0 END),0) [Recebido],
		'0' [VlrComp],
		CAST(A.Cliente_Rpg AS VARCHAR) + ' - ' + Pessoas.Nome_Pes [Cliente],
		A.BancoChq_Rpg,
		A.ContaChq_Rpg,
		A.Produto_Itr
	FROM BDTotRec AS A
	LEFT JOIN BDVinculoNotaVenda AS B
		ON A.Empresa_Rpd = B.EmpresaNf_Vnv
		AND A.Obra_Rpd = B.ObraVen_Vnv
		AND A.NumVend_Rpd = B.NumVen_Vnv
	LEFT JOIN UAU.dbo.PrdSrv 
		ON A.Produto_Itr = PrdSrv.NumProd_Psc
	LEFT JOIN BDUnidades AS C
		ON A.Empresa_Rpd = C.Empresa_Itv
		AND A.Produto_Itr = C.Produto_Itv
		AND A.Obra_Rpd = C.Obra_Itv
		AND A.NumVend_Rpd = C.NumVend_Itv
	LEFT JOIN UAU.dbo.UnidadePer 
		ON C.Empresa_Itv = UnidadePer.Empresa_Unid
		AND C.Produto_Itv = UnidadePer.Prod_Unid
		AND C.Personalizao = UnidadePer.NumPer_Unid
	LEFT JOIN UAU.dbo.Pessoas 
		ON A.Cliente_Rpg = Pessoas.Cod_Pes
	WHERE 
		CASE 
			WHEN A.Status = 'Receber' THEN 1 
			WHEN A.Status = 'Recebido' THEN 2 
			END IN (1,2,3)
--) AS BASE

--WHERE BASE.Produto_Itr IS NOT NULL 
--	AND BASE.NumProc NOT LIKE '%PERMUTA%'	
--		OR ISNULL(BASE.NumProc, '') = ''
go

